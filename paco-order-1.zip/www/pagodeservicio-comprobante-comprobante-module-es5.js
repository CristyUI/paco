function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pagodeservicio-comprobante-comprobante-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/comprobante/comprobante.page.html":
  /*!********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/comprobante/comprobante.page.html ***!
    \********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagodeservicioComprobanteComprobantePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"comprob-wrap\">\n    <h4>Comprobante de pago</h4>\n    <table>\n      <thead>\n        <tr>\n          <th>Fecha de pago</th>\n          <th>No. de Operación</th>\n        </tr>\n      </thead>\n      <tbody>\n        <tr>\n          <td>18:24  2 de octubre, 2019</td>\n          <td>#2788-2039</td>\n        </tr>\n      </tbody>\n    </table>\n    <h5>Desglose</h5>\n    <ul>\n      <li>Sub total<span>$ 999.00</span></li>\n      <li>Comisión<span>+ $ 10.00</span></li>\n      <li>Total<span>$ 1,009.00</span></li>\n    </ul>\n    <p>Si tienes alguna duda, contáctanos por correo en\n      <span>ayuda@paco.com</span> o llámanos a <span>55 9807 4539</span>.</p>\n    <div class=\"btn-bottom\">\n      <ion-button class=\"full-btn\" (click)=\"messagenotify()\">Compartir</ion-button>\n    </div>\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pagodeservicio/comprobante/comprobante-routing.module.ts":
  /*!**************************************************************************!*\
    !*** ./src/app/pagodeservicio/comprobante/comprobante-routing.module.ts ***!
    \**************************************************************************/

  /*! exports provided: ComprobantePageRoutingModule */

  /***/
  function srcAppPagodeservicioComprobanteComprobanteRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ComprobantePageRoutingModule", function () {
      return ComprobantePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _comprobante_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./comprobante.page */
    "./src/app/pagodeservicio/comprobante/comprobante.page.ts");

    var routes = [{
      path: '',
      component: _comprobante_page__WEBPACK_IMPORTED_MODULE_3__["ComprobantePage"]
    }];

    var ComprobantePageRoutingModule = function ComprobantePageRoutingModule() {
      _classCallCheck(this, ComprobantePageRoutingModule);
    };

    ComprobantePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ComprobantePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pagodeservicio/comprobante/comprobante.module.ts":
  /*!******************************************************************!*\
    !*** ./src/app/pagodeservicio/comprobante/comprobante.module.ts ***!
    \******************************************************************/

  /*! exports provided: ComprobantePageModule */

  /***/
  function srcAppPagodeservicioComprobanteComprobanteModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ComprobantePageModule", function () {
      return ComprobantePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _comprobante_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./comprobante-routing.module */
    "./src/app/pagodeservicio/comprobante/comprobante-routing.module.ts");
    /* harmony import */


    var _comprobante_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./comprobante.page */
    "./src/app/pagodeservicio/comprobante/comprobante.page.ts");

    var ComprobantePageModule = function ComprobantePageModule() {
      _classCallCheck(this, ComprobantePageModule);
    };

    ComprobantePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _comprobante_routing_module__WEBPACK_IMPORTED_MODULE_5__["ComprobantePageRoutingModule"]],
      declarations: [_comprobante_page__WEBPACK_IMPORTED_MODULE_6__["ComprobantePage"]]
    })], ComprobantePageModule);
    /***/
  },

  /***/
  "./src/app/pagodeservicio/comprobante/comprobante.page.scss":
  /*!******************************************************************!*\
    !*** ./src/app/pagodeservicio/comprobante/comprobante.page.scss ***!
    \******************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagodeservicioComprobanteComprobantePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-content {\n  --background: #5176f3;\n}\nion-content .comprob-wrap {\n  background: #fff;\n  padding: 10px 20px 20px 20px;\n  position: absolute;\n  bottom: 0;\n  border-radius: 30px 30px 0 0;\n}\nion-content .comprob-wrap:before {\n  content: \"\";\n  background: rgba(255, 255, 255, 0.58);\n  top: -30px;\n  display: block;\n  height: 9px;\n  width: 60px;\n  position: relative;\n  text-align: center;\n  margin: 0 auto;\n  border-radius: 30px;\n}\nion-content .comprob-wrap h4 {\n  font-size: 18px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n  margin-bottom: 40px;\n}\nion-content .comprob-wrap table {\n  width: 100%;\n}\nion-content .comprob-wrap table thead tr th {\n  color: #777;\n  font-weight: 100;\n  font-size: 15px;\n}\nion-content .comprob-wrap table thead tr th:nth-child(1) {\n  text-align: left;\n}\nion-content .comprob-wrap table thead tr th:nth-child(2) {\n  text-align: right;\n}\nion-content .comprob-wrap table tbody tr td {\n  padding: 7px 0;\n}\nion-content .comprob-wrap table tbody tr td:nth-child(1) {\n  text-align: left;\n}\nion-content .comprob-wrap table tbody tr td:nth-child(2) {\n  text-align: right;\n}\nion-content .comprob-wrap h5 {\n  font-size: 17px;\n  font-weight: 700;\n}\nion-content .comprob-wrap ul {\n  padding-left: 0;\n}\nion-content .comprob-wrap ul li {\n  list-style-type: none;\n  padding: 5px 0;\n}\nion-content .comprob-wrap ul li span {\n  float: right;\n}\nion-content .comprob-wrap ul li:nth-child(1) span {\n  background: #5176f3;\n  color: #fff;\n  padding: 3px 13px;\n  border-radius: 30px;\n}\nion-content .comprob-wrap ul li:nth-child(3) span {\n  color: #2246bf;\n}\nion-content .comprob-wrap p {\n  color: #949494;\n  margin-bottom: 5px;\n}\nion-content .comprob-wrap p span {\n  color: #5176f3;\n}\nion-content .comprob-wrap .btn-bottom {\n  padding-top: 12px;\n  text-align: right;\n}\nion-content .comprob-wrap .btn-bottom .full-btn {\n  margin-top: 5px;\n  height: 3.2rem;\n  width: 44% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnb2Rlc2VydmljaW8vY29tcHJvYmFudGUvRzpcXGlvbmljXFxGSVZFUlJcXHBhbnRhbGxhcy1wYWNvL3NyY1xcYXBwXFxwYWdvZGVzZXJ2aWNpb1xcY29tcHJvYmFudGVcXGNvbXByb2JhbnRlLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnb2Rlc2VydmljaW8vY29tcHJvYmFudGUvY29tcHJvYmFudGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQUE7QUNDRjtBREFFO0VBQ0UsZ0JBQUE7RUFDQSw0QkFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLDRCQUFBO0FDRUo7QURESTtFQUNFLFdBQUE7RUFDQSxxQ0FBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0FDR047QURESTtFQUNFLGVBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUNHTjtBRERJO0VBQ0UsV0FBQTtBQ0dOO0FEQVU7RUFDRSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDRVo7QUREVztFQUNFLGdCQUFBO0FDR2I7QUREWTtFQUNFLGlCQUFBO0FDR2Q7QURJVTtFQUNFLGNBQUE7QUNGWjtBREdZO0VBQ0UsZ0JBQUE7QUNEZDtBREdZO0VBQ0UsaUJBQUE7QUNEZDtBRE9JO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FDTE47QURPSTtFQUNFLGVBQUE7QUNMTjtBRE1NO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0FDSlI7QURLUTtFQUNFLFlBQUE7QUNIVjtBRE1VO0VBQ0UsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQ0paO0FEUVU7RUFDRSxjQUFBO0FDTlo7QURXSTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtBQ1ROO0FEVU07RUFDRSxjQUFBO0FDUlI7QURXSTtFQUNFLGlCQUFBO0VBQ0EsaUJBQUE7QUNUTjtBRFVNO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxxQkFBQTtBQ1JSIiwiZmlsZSI6InNyYy9hcHAvcGFnb2Rlc2VydmljaW8vY29tcHJvYmFudGUvY29tcHJvYmFudGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcclxuICAuY29tcHJvYi13cmFwIHtcclxuICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICBwYWRkaW5nOiAxMHB4IDIwcHggMjBweCAyMHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweCAzMHB4IDAgMDtcclxuICAgICY6YmVmb3JlIHtcclxuICAgICAgY29udGVudDogXCJcIjtcclxuICAgICAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjU4KTtcclxuICAgICAgdG9wOiAtMzBweDtcclxuICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgIGhlaWdodDogOXB4O1xyXG4gICAgICB3aWR0aDogNjBweDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgfVxyXG4gICAgaDQge1xyXG4gICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDZweDtcclxuICAgICAgY29sb3I6ICMyYzU1ZTA7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDQwcHg7XHJcbiAgICB9XHJcbiAgICB0YWJsZSB7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICB0aGVhZCB7XHJcbiAgICAgICAgdHIge1xyXG4gICAgICAgICAgdGgge1xyXG4gICAgICAgICAgICBjb2xvcjogIzc3NztcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDEwMDtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgICAgICY6bnRoLWNoaWxkKDEpIHtcclxuICAgICAgICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAmOm50aC1jaGlsZCgyKSB7XHJcbiAgICAgICAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgdGJvZHkge1xyXG4gICAgICAgIHRyIHtcclxuICAgICAgICAgIHRkIHtcclxuICAgICAgICAgICAgcGFkZGluZzogN3B4IDA7XHJcbiAgICAgICAgICAgICY6bnRoLWNoaWxkKDEpIHtcclxuICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICY6bnRoLWNoaWxkKDIpIHtcclxuICAgICAgICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaDUge1xyXG4gICAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICB9XHJcbiAgICB1bCB7XHJcbiAgICAgIHBhZGRpbmctbGVmdDogMDtcclxuICAgICAgbGkge1xyXG4gICAgICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcclxuICAgICAgICBwYWRkaW5nOiA1cHggMDtcclxuICAgICAgICBzcGFuIHtcclxuICAgICAgICAgIGZsb2F0OiByaWdodDtcclxuICAgICAgICB9XHJcbiAgICAgICAgJjpudGgtY2hpbGQoMSkge1xyXG4gICAgICAgICAgc3BhbiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICM1MTc2ZjM7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAzcHggMTNweDtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgJjpudGgtY2hpbGQoMykge1xyXG4gICAgICAgICAgc3BhbiB7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjMjI0NmJmO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcCB7XHJcbiAgICAgIGNvbG9yOiAjOTQ5NDk0O1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiA1cHg7XHJcbiAgICAgIHNwYW4ge1xyXG4gICAgICAgIGNvbG9yOiAjNTE3NmYzO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAuYnRuLWJvdHRvbSB7XHJcbiAgICAgIHBhZGRpbmctdG9wOiAxMnB4O1xyXG4gICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgICAgLmZ1bGwtYnRuIHtcclxuICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICAgICAgaGVpZ2h0OiAzLjJyZW07XHJcbiAgICAgICAgd2lkdGg6IDQ0JSFpbXBvcnRhbnQ7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn0iLCJpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBwYWRkaW5nOiAxMHB4IDIwcHggMjBweCAyMHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMDtcbiAgYm9yZGVyLXJhZGl1czogMzBweCAzMHB4IDAgMDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXA6YmVmb3JlIHtcbiAgY29udGVudDogXCJcIjtcbiAgYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjU4KTtcbiAgdG9wOiAtMzBweDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGhlaWdodDogOXB4O1xuICB3aWR0aDogNjBweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbjogMCBhdXRvO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xufVxuaW9uLWNvbnRlbnQgLmNvbXByb2Itd3JhcCBoNCB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBjb2xvcjogIzJjNTVlMDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgbWFyZ2luLWJvdHRvbTogNDBweDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgdGFibGUge1xuICB3aWR0aDogMTAwJTtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgdGFibGUgdGhlYWQgdHIgdGgge1xuICBjb2xvcjogIzc3NztcbiAgZm9udC13ZWlnaHQ6IDEwMDtcbiAgZm9udC1zaXplOiAxNXB4O1xufVxuaW9uLWNvbnRlbnQgLmNvbXByb2Itd3JhcCB0YWJsZSB0aGVhZCB0ciB0aDpudGgtY2hpbGQoMSkge1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xufVxuaW9uLWNvbnRlbnQgLmNvbXByb2Itd3JhcCB0YWJsZSB0aGVhZCB0ciB0aDpudGgtY2hpbGQoMikge1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgdGFibGUgdGJvZHkgdHIgdGQge1xuICBwYWRkaW5nOiA3cHggMDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgdGFibGUgdGJvZHkgdHIgdGQ6bnRoLWNoaWxkKDEpIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgdGFibGUgdGJvZHkgdHIgdGQ6bnRoLWNoaWxkKDIpIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwIGg1IHtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBmb250LXdlaWdodDogNzAwO1xufVxuaW9uLWNvbnRlbnQgLmNvbXByb2Itd3JhcCB1bCB7XG4gIHBhZGRpbmctbGVmdDogMDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgdWwgbGkge1xuICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XG4gIHBhZGRpbmc6IDVweCAwO1xufVxuaW9uLWNvbnRlbnQgLmNvbXByb2Itd3JhcCB1bCBsaSBzcGFuIHtcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuaW9uLWNvbnRlbnQgLmNvbXByb2Itd3JhcCB1bCBsaTpudGgtY2hpbGQoMSkgc3BhbiB7XG4gIGJhY2tncm91bmQ6ICM1MTc2ZjM7XG4gIGNvbG9yOiAjZmZmO1xuICBwYWRkaW5nOiAzcHggMTNweDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgdWwgbGk6bnRoLWNoaWxkKDMpIHNwYW4ge1xuICBjb2xvcjogIzIyNDZiZjtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgcCB7XG4gIGNvbG9yOiAjOTQ5NDk0O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwIHAgc3BhbiB7XG4gIGNvbG9yOiAjNTE3NmYzO1xufVxuaW9uLWNvbnRlbnQgLmNvbXByb2Itd3JhcCAuYnRuLWJvdHRvbSB7XG4gIHBhZGRpbmctdG9wOiAxMnB4O1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgLmJ0bi1ib3R0b20gLmZ1bGwtYnRuIHtcbiAgbWFyZ2luLXRvcDogNXB4O1xuICBoZWlnaHQ6IDMuMnJlbTtcbiAgd2lkdGg6IDQ0JSAhaW1wb3J0YW50O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pagodeservicio/comprobante/comprobante.page.ts":
  /*!****************************************************************!*\
    !*** ./src/app/pagodeservicio/comprobante/comprobante.page.ts ***!
    \****************************************************************/

  /*! exports provided: ComprobantePage */

  /***/
  function srcAppPagodeservicioComprobanteComprobantePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ComprobantePage", function () {
      return ComprobantePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var ComprobantePage = /*#__PURE__*/function () {
      function ComprobantePage(router, menuCtrl) {
        _classCallCheck(this, ComprobantePage);

        this.router = router;
        this.menuCtrl = menuCtrl;
      }

      _createClass(ComprobantePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "messagenotify",
        value: function messagenotify() {
          this.router.navigateByUrl('/messagenotify');
        }
      }]);

      return ComprobantePage;
    }();

    ComprobantePage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    ComprobantePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-comprobante',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./comprobante.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/comprobante/comprobante.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./comprobante.page.scss */
      "./src/app/pagodeservicio/comprobante/comprobante.page.scss"))["default"]]
    })], ComprobantePage);
    /***/
  }
}]);
//# sourceMappingURL=pagodeservicio-comprobante-comprobante-module-es5.js.map