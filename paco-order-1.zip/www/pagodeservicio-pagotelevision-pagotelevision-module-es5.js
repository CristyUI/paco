function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pagodeservicio-pagotelevision-pagotelevision-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/pagotelevision/pagotelevision.page.html":
  /*!**************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/pagotelevision/pagotelevision.page.html ***!
    \**************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagodeservicioPagotelevisionPagotelevisionPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"secondary\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Televisión, telefonía e internet</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n <div class=\"ion-padding\">\n\n   <div class=\"search-area\">\n     <div class=\"content-search\">\n       <span>Buscar<img src=\"assets/imgs/search-icon.png\" alt=\"\"></span>\n     </div>\n   </div>\n\n   <div class=\"tab-list\">\n     <ul>\n       <li *ngIf=\"tab1\" (click)=\"showgrid()\"><img src=\"assets/imgs/pagodeservicio/tab-1-dark.png\" alt=\"\"></li>\n       <li *ngIf=\"tab2\" (click)=\"showgrid()\"><img src=\"assets/imgs/pagodeservicio/tab-1-light.png\" alt=\"\"></li>\n       <li *ngIf=\"tab3\" (click)=\"showlist()\"><img src=\"assets/imgs/pagodeservicio/tab-2-light.png\" alt=\"\"></li>\n       <li *ngIf=\"tab4\" (click)=\"showlist()\"><img src=\"assets/imgs/pagodeservicio/tab-2-dark.png\" alt=\"\"></li>\n     </ul>\n   </div>\n\n   <div class=\"block-category\" *ngIf=\"catGrid\">\n     <ion-row>\n       <ion-col size=\"4\">\n         <div class=\"wrapper\" (click)=\"PageRoute('telmex')\">\n           <img src=\"assets/imgs/pagodeservicio/tv-1.png\">\n           <p>Axtel</p>\n         </div>\n       </ion-col>\n       <ion-col size=\"4\">\n         <div class=\"wrapper\" (click)=\"PageRoute('telmex')\">\n           <img src=\"assets/imgs/pagodeservicio/tv-2.png\">\n           <p>Cablemas</p>\n         </div>\n       </ion-col>\n       <ion-col size=\"4\">\n         <div class=\"wrapper\" (click)=\"PageRoute('telmex')\">\n           <img src=\"assets/imgs/pagodeservicio/tv-3.png\">\n           <p>Dish</p>\n         </div>\n       </ion-col>\n       <ion-col size=\"4\">\n         <div class=\"wrapper\" (click)=\"PageRoute('telmex')\">\n           <img src=\"assets/imgs/pagodeservicio/tv-4.png\">\n           <p>Megacable</p>\n         </div>\n       </ion-col>\n       <ion-col size=\"4\">\n         <div class=\"wrapper\" (click)=\"PageRoute('telmex')\">\n           <img src=\"assets/imgs/pagodeservicio/tv-5.png\">\n           <p>SKY</p>\n         </div>\n       </ion-col>\n       <ion-col size=\"4\">\n         <div class=\"wrapper\" (click)=\"PageRoute('telmex')\">\n           <img src=\"assets/imgs/pagodeservicio/tv-6.png\">\n           <p>Telmex</p>\n         </div>\n       </ion-col>\n     </ion-row>\n   </div>\n\n   <div class=\"list-category\" *ngIf=\"catList\">\n      <div class=\"list-item\" (click)=\"PageRoute('telmex')\">\n         <h6><img src=\"assets/imgs/pagodeservicio/tv-1.png\">Axtel <span><ion-icon name=\"chevron-forward-outline\"></ion-icon></span></h6>\n      </div>\n     <div class=\"list-item\" (click)=\"PageRoute('telmex')\">\n       <h6><img src=\"assets/imgs/pagodeservicio/tv-2.png\">Cablemas <span><ion-icon name=\"chevron-forward-outline\"></ion-icon></span></h6>\n     </div>\n     <div class=\"list-item\" (click)=\"PageRoute('telmex')\">\n       <h6><img src=\"assets/imgs/pagodeservicio/tv-3.png\">Dish <span><ion-icon name=\"chevron-forward-outline\"></ion-icon></span></h6>\n     </div>\n     <div class=\"list-item\" (click)=\"PageRoute('telmex')\">\n       <h6><img src=\"assets/imgs/pagodeservicio/tv-4.png\">Megacable <span><ion-icon name=\"chevron-forward-outline\"></ion-icon></span></h6>\n     </div>\n     <div class=\"list-item\" (click)=\"PageRoute('telmex')\">\n       <h6><img src=\"assets/imgs/pagodeservicio/tv-5.png\">SKY <span><ion-icon name=\"chevron-forward-outline\"></ion-icon></span></h6>\n     </div>\n     <div class=\"list-item\" (click)=\"PageRoute('telmex')\">\n       <h6><img src=\"assets/imgs/pagodeservicio/tv-6.png\">Telmex <span><ion-icon name=\"chevron-forward-outline\"></ion-icon></span></h6>\n     </div>\n   </div>\n\n </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pagodeservicio/pagotelevision/pagotelevision-routing.module.ts":
  /*!********************************************************************************!*\
    !*** ./src/app/pagodeservicio/pagotelevision/pagotelevision-routing.module.ts ***!
    \********************************************************************************/

  /*! exports provided: PagotelevisionPageRoutingModule */

  /***/
  function srcAppPagodeservicioPagotelevisionPagotelevisionRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PagotelevisionPageRoutingModule", function () {
      return PagotelevisionPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _pagotelevision_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./pagotelevision.page */
    "./src/app/pagodeservicio/pagotelevision/pagotelevision.page.ts");

    var routes = [{
      path: '',
      component: _pagotelevision_page__WEBPACK_IMPORTED_MODULE_3__["PagotelevisionPage"]
    }];

    var PagotelevisionPageRoutingModule = function PagotelevisionPageRoutingModule() {
      _classCallCheck(this, PagotelevisionPageRoutingModule);
    };

    PagotelevisionPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], PagotelevisionPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pagodeservicio/pagotelevision/pagotelevision.module.ts":
  /*!************************************************************************!*\
    !*** ./src/app/pagodeservicio/pagotelevision/pagotelevision.module.ts ***!
    \************************************************************************/

  /*! exports provided: PagotelevisionPageModule */

  /***/
  function srcAppPagodeservicioPagotelevisionPagotelevisionModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PagotelevisionPageModule", function () {
      return PagotelevisionPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _pagotelevision_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./pagotelevision-routing.module */
    "./src/app/pagodeservicio/pagotelevision/pagotelevision-routing.module.ts");
    /* harmony import */


    var _pagotelevision_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./pagotelevision.page */
    "./src/app/pagodeservicio/pagotelevision/pagotelevision.page.ts");

    var PagotelevisionPageModule = function PagotelevisionPageModule() {
      _classCallCheck(this, PagotelevisionPageModule);
    };

    PagotelevisionPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _pagotelevision_routing_module__WEBPACK_IMPORTED_MODULE_5__["PagotelevisionPageRoutingModule"]],
      declarations: [_pagotelevision_page__WEBPACK_IMPORTED_MODULE_6__["PagotelevisionPage"]]
    })], PagotelevisionPageModule);
    /***/
  },

  /***/
  "./src/app/pagodeservicio/pagotelevision/pagotelevision.page.scss":
  /*!************************************************************************!*\
    !*** ./src/app/pagodeservicio/pagotelevision/pagotelevision.page.scss ***!
    \************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagodeservicioPagotelevisionPagotelevisionPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header ion-title {\n  font-weight: 600;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.search-area .content-search {\n  box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.2588235294);\n  border-radius: 30px;\n  padding: 15px 22px;\n}\n.search-area .content-search span {\n  color: #8c8b8b;\n}\n.search-area .content-search span img {\n  width: 20px;\n  vertical-align: bottom;\n  float: right;\n}\n.tab-list {\n  text-align: right;\n}\n.tab-list ul {\n  padding-left: 0;\n  margin-bottom: 0;\n}\n.tab-list ul li {\n  list-style-type: none;\n  display: inline-flex;\n  margin-left: 12px;\n}\n.tab-list ul li img {\n  width: 30px;\n}\n.block-category {\n  padding-top: 10px;\n}\n.block-category .wrapper {\n  text-align: center;\n  border-radius: 20px;\n  padding: 7px;\n  height: 100px;\n  position: relative;\n  box-shadow: -1px 4px 12px -6px rgba(0, 0, 0, 0.38);\n  margin-bottom: 4px;\n}\n.block-category .wrapper img {\n  width: 50px;\n  margin-top: 4px;\n}\n.block-category .wrapper p {\n  margin-bottom: 4px;\n  margin-top: 0;\n  font-weight: 600;\n  color: #8a8989;\n}\n.list-category {\n  padding-top: 12px;\n}\n.list-category .list-item {\n  position: relative;\n  box-shadow: -1px 4px 12px -6px rgba(0, 0, 0, 0.38);\n  border-radius: 30px;\n  padding: 0 20px;\n  margin-bottom: 15px;\n}\n.list-category .list-item h6 {\n  margin: 0;\n  color: #8a8989;\n}\n.list-category .list-item h6 img {\n  width: 50px;\n  vertical-align: middle;\n  margin-right: 24px;\n  position: relative;\n  top: -3px;\n}\n.list-category .list-item h6 span {\n  position: absolute;\n  right: 10px;\n  bottom: 10px;\n  font-size: 20px;\n  color: #5176f3;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnb2Rlc2VydmljaW8vcGFnb3RlbGV2aXNpb24vRzpcXGlvbmljXFxGSVZFUlJcXHBhbnRhbGxhcy1wYWNvL3NyY1xcYXBwXFxwYWdvZGVzZXJ2aWNpb1xccGFnb3RlbGV2aXNpb25cXHBhZ290ZWxldmlzaW9uLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnb2Rlc2VydmljaW8vcGFnb3RlbGV2aXNpb24vcGFnb3RlbGV2aXNpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UsZ0JBQUE7QUNBSjtBREdJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNETjtBRE9FO0VBQ0Usd0RBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FDSko7QURLSTtFQUNFLGNBQUE7QUNITjtBRElNO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQ0ZSO0FET0E7RUFDRSxpQkFBQTtBQ0pGO0FES0U7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7QUNISjtBRElJO0VBQ0UscUJBQUE7RUFDQSxvQkFBQTtFQUNBLGlCQUFBO0FDRk47QURHTTtFQUNFLFdBQUE7QUNEUjtBRE1BO0VBQ0UsaUJBQUE7QUNIRjtBRElFO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxrREFBQTtFQUNBLGtCQUFBO0FDRko7QURHSTtFQUNFLFdBQUE7RUFDQSxlQUFBO0FDRE47QURHSTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQ0ROO0FES0E7RUFDRSxpQkFBQTtBQ0ZGO0FER0U7RUFDRSxrQkFBQTtFQUNBLGtEQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7QUNESjtBREVJO0VBQ0UsU0FBQTtFQUNBLGNBQUE7QUNBTjtBRENNO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7QUNDUjtBRENNO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FDQ1IiLCJmaWxlIjoic3JjL2FwcC9wYWdvZGVzZXJ2aWNpby9wYWdvdGVsZXZpc2lvbi9wYWdvdGVsZXZpc2lvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tdGl0bGUge1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB9XHJcbiAgLmJ0bi1yaWdodCB7XHJcbiAgICAuYWxlcnQtdGFnIHtcclxuICAgICAgd2lkdGg6IDEycHg7XHJcbiAgICAgIGhlaWdodDogMTJweDtcclxuICAgICAgYmFja2dyb3VuZDogI2ZiNGYzMztcclxuICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICByaWdodDogLTNweDtcclxuICAgICAgYm90dG9tOiAtMnB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuLnNlYXJjaC1hcmVhe1xyXG4gIC5jb250ZW50LXNlYXJjaCB7XHJcbiAgICBib3gtc2hhZG93OiBpbnNldCAwIDJweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yNTg4MjM1Mjk0MTE3NjQ3Myk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgcGFkZGluZzogMTVweCAyMnB4O1xyXG4gICAgc3BhbiB7XHJcbiAgICAgIGNvbG9yOiAjOGM4YjhiO1xyXG4gICAgICBpbWcge1xyXG4gICAgICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiBib3R0b207XHJcbiAgICAgICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbi50YWItbGlzdCB7XHJcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgdWwge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAwO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgIGxpIHtcclxuICAgICAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xyXG4gICAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICAgICAgbWFyZ2luLWxlZnQ6IDEycHg7XHJcbiAgICAgIGltZyB7XHJcbiAgICAgICAgd2lkdGg6IDMwcHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuLmJsb2NrLWNhdGVnb3J5IHtcclxuICBwYWRkaW5nLXRvcDogMTBweDtcclxuICAud3JhcHBlciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgcGFkZGluZzogN3B4O1xyXG4gICAgaGVpZ2h0OiAxMDBweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGJveC1zaGFkb3c6IC0xcHggNHB4IDEycHggLTZweCByZ2JhKDAsIDAsIDAsIDAuMzgpO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG4gICAgaW1nIHtcclxuICAgICAgd2lkdGg6IDUwcHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDRweDtcclxuICAgIH1cclxuICAgIHAge1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiA0cHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDA7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgIGNvbG9yOiAjOGE4OTg5O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4ubGlzdC1jYXRlZ29yeSB7XHJcbiAgcGFkZGluZy10b3A6IDEycHg7XHJcbiAgLmxpc3QtaXRlbSB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBib3gtc2hhZG93OiAtMXB4IDRweCAxMnB4IC02cHggcmdiYSgwLCAwLCAwLCAwLjM4KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICBwYWRkaW5nOiAwIDIwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG4gICAgaDYge1xyXG4gICAgICBtYXJnaW46IDA7XHJcbiAgICAgIGNvbG9yOiAjOGE4OTg5O1xyXG4gICAgICBpbWcge1xyXG4gICAgICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAyNHB4O1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICB0b3A6IC0zcHg7XHJcbiAgICAgIH1cclxuICAgICAgc3BhbiB7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIHJpZ2h0OiAxMHB4O1xyXG4gICAgICAgIGJvdHRvbTogMTBweDtcclxuICAgICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgICAgY29sb3I6ICM1MTc2ZjM7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn0iLCJpb24taGVhZGVyIGlvbi10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5pb24taGVhZGVyIC5idG4tcmlnaHQgLmFsZXJ0LXRhZyB7XG4gIHdpZHRoOiAxMnB4O1xuICBoZWlnaHQ6IDEycHg7XG4gIGJhY2tncm91bmQ6ICNmYjRmMzM7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IC0zcHg7XG4gIGJvdHRvbTogLTJweDtcbn1cblxuLnNlYXJjaC1hcmVhIC5jb250ZW50LXNlYXJjaCB7XG4gIGJveC1zaGFkb3c6IGluc2V0IDAgMnB4IDEwcHggcmdiYSgwLCAwLCAwLCAwLjI1ODgyMzUyOTQpO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBwYWRkaW5nOiAxNXB4IDIycHg7XG59XG4uc2VhcmNoLWFyZWEgLmNvbnRlbnQtc2VhcmNoIHNwYW4ge1xuICBjb2xvcjogIzhjOGI4Yjtcbn1cbi5zZWFyY2gtYXJlYSAuY29udGVudC1zZWFyY2ggc3BhbiBpbWcge1xuICB3aWR0aDogMjBweDtcbiAgdmVydGljYWwtYWxpZ246IGJvdHRvbTtcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuXG4udGFiLWxpc3Qge1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cbi50YWItbGlzdCB1bCB7XG4gIHBhZGRpbmctbGVmdDogMDtcbiAgbWFyZ2luLWJvdHRvbTogMDtcbn1cbi50YWItbGlzdCB1bCBsaSB7XG4gIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XG4gIG1hcmdpbi1sZWZ0OiAxMnB4O1xufVxuLnRhYi1saXN0IHVsIGxpIGltZyB7XG4gIHdpZHRoOiAzMHB4O1xufVxuXG4uYmxvY2stY2F0ZWdvcnkge1xuICBwYWRkaW5nLXRvcDogMTBweDtcbn1cbi5ibG9jay1jYXRlZ29yeSAud3JhcHBlciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcbiAgcGFkZGluZzogN3B4O1xuICBoZWlnaHQ6IDEwMHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJveC1zaGFkb3c6IC0xcHggNHB4IDEycHggLTZweCByZ2JhKDAsIDAsIDAsIDAuMzgpO1xuICBtYXJnaW4tYm90dG9tOiA0cHg7XG59XG4uYmxvY2stY2F0ZWdvcnkgLndyYXBwZXIgaW1nIHtcbiAgd2lkdGg6IDUwcHg7XG4gIG1hcmdpbi10b3A6IDRweDtcbn1cbi5ibG9jay1jYXRlZ29yeSAud3JhcHBlciBwIHtcbiAgbWFyZ2luLWJvdHRvbTogNHB4O1xuICBtYXJnaW4tdG9wOiAwO1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogIzhhODk4OTtcbn1cblxuLmxpc3QtY2F0ZWdvcnkge1xuICBwYWRkaW5nLXRvcDogMTJweDtcbn1cbi5saXN0LWNhdGVnb3J5IC5saXN0LWl0ZW0ge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJveC1zaGFkb3c6IC0xcHggNHB4IDEycHggLTZweCByZ2JhKDAsIDAsIDAsIDAuMzgpO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBwYWRkaW5nOiAwIDIwcHg7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG59XG4ubGlzdC1jYXRlZ29yeSAubGlzdC1pdGVtIGg2IHtcbiAgbWFyZ2luOiAwO1xuICBjb2xvcjogIzhhODk4OTtcbn1cbi5saXN0LWNhdGVnb3J5IC5saXN0LWl0ZW0gaDYgaW1nIHtcbiAgd2lkdGg6IDUwcHg7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIG1hcmdpbi1yaWdodDogMjRweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IC0zcHg7XG59XG4ubGlzdC1jYXRlZ29yeSAubGlzdC1pdGVtIGg2IHNwYW4ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAxMHB4O1xuICBib3R0b206IDEwcHg7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgY29sb3I6ICM1MTc2ZjM7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pagodeservicio/pagotelevision/pagotelevision.page.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/pagodeservicio/pagotelevision/pagotelevision.page.ts ***!
    \**********************************************************************/

  /*! exports provided: PagotelevisionPage */

  /***/
  function srcAppPagodeservicioPagotelevisionPagotelevisionPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PagotelevisionPage", function () {
      return PagotelevisionPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var PagotelevisionPage = /*#__PURE__*/function () {
      function PagotelevisionPage(router, menuCtrl) {
        _classCallCheck(this, PagotelevisionPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
        this.tab1 = true;
        this.tab2 = false;
        this.tab3 = true;
        this.tab4 = false;
        this.catList = false;
        this.catGrid = true;
      }

      _createClass(PagotelevisionPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "showlist",
        value: function showlist() {
          this.catList = true;
          this.catGrid = false;
          this.tab1 = false;
          this.tab2 = true;
          this.tab3 = false;
          this.tab4 = true;
        }
      }, {
        key: "showgrid",
        value: function showgrid() {
          this.catGrid = true;
          this.catList = false;
          this.tab3 = true;
          this.tab4 = false;
          this.tab1 = true;
          this.tab2 = false;
        }
      }, {
        key: "PageRoute",
        value: function PageRoute(urlSlug) {
          this.router.navigateByUrl('/' + urlSlug);
        }
      }]);

      return PagotelevisionPage;
    }();

    PagotelevisionPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    PagotelevisionPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-pagotelevision',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./pagotelevision.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/pagotelevision/pagotelevision.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./pagotelevision.page.scss */
      "./src/app/pagodeservicio/pagotelevision/pagotelevision.page.scss"))["default"]]
    })], PagotelevisionPage);
    /***/
  }
}]);
//# sourceMappingURL=pagodeservicio-pagotelevision-pagotelevision-module-es5.js.map