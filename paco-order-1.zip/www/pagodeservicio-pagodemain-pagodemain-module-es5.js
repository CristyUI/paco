function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pagodeservicio-pagodemain-pagodemain-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/pagodemain/pagodemain.page.html":
  /*!******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/pagodemain/pagodemain.page.html ***!
    \******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagodeservicioPagodemainPagodemainPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"secondary\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Pago de servicio</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"list-category\">\n    <h4>Los más usados</h4>\n    <ion-slides [options]=\"slidecat\">\n      <ion-slide>\n        <div class=\"cat-single\">\n          <img src=\"assets/imgs/pagodeservicio/cat_1.png\">\n        </div>\n      </ion-slide>\n      <ion-slide>\n        <div class=\"cat-single\">\n          <img src=\"assets/imgs/pagodeservicio/cat_2.png\">\n        </div>\n      </ion-slide>\n      <ion-slide>\n        <div class=\"cat-single\">\n          <img src=\"assets/imgs/pagodeservicio/cat_3.png\">\n        </div>\n      </ion-slide>\n      <ion-slide>\n        <div class=\"cat-single\">\n          <img src=\"assets/imgs/pagodeservicio/cat_4.png\">\n        </div>\n      </ion-slide>\n      <ion-slide>\n        <div class=\"cat-single\">\n          <img src=\"assets/imgs/pagodeservicio/cat_5.png\">\n        </div>\n      </ion-slide>\n    </ion-slides>\n  </div>\n  <div class=\"block-category\">\n    <div class=\"ion-padding\">\n      <h4>Servicios</h4>\n      <ion-row>\n        <ion-col size=\"6\">\n          <div class=\"wrapper\" (click)=\"PageRoute('pagotelevision')\">\n            <img src=\"assets/imgs/pagodeservicio/b-1.png\">\n            <p>Televisión, telefonía e internet</p>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\">\n          <div class=\"wrapper\">\n            <img src=\"assets/imgs/pagodeservicio/b-2.png\">\n            <p>Luz y gas</p>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\">\n          <div class=\"wrapper\">\n            <img src=\"assets/imgs/pagodeservicio/b-3.png\">\n            <p>Telepeaje</p>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\">\n          <div class=\"wrapper\">\n            <img src=\"assets/imgs/pagodeservicio/b-4.png\">\n            <p>Entretenimiento</p>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\">\n          <div class=\"wrapper\">\n            <img src=\"assets/imgs/pagodeservicio/b-5.png\">\n            <p>Pagos de gobierno</p>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\">\n          <div class=\"wrapper\">\n            <img src=\"assets/imgs/pagodeservicio/b-6.png\">\n            <p>Ventas por catálogo</p>\n          </div>\n        </ion-col>\n      </ion-row>\n    </div>\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pagodeservicio/pagodemain/pagodemain-routing.module.ts":
  /*!************************************************************************!*\
    !*** ./src/app/pagodeservicio/pagodemain/pagodemain-routing.module.ts ***!
    \************************************************************************/

  /*! exports provided: PagodemainPageRoutingModule */

  /***/
  function srcAppPagodeservicioPagodemainPagodemainRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PagodemainPageRoutingModule", function () {
      return PagodemainPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _pagodemain_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./pagodemain.page */
    "./src/app/pagodeservicio/pagodemain/pagodemain.page.ts");

    var routes = [{
      path: '',
      component: _pagodemain_page__WEBPACK_IMPORTED_MODULE_3__["PagodemainPage"]
    }];

    var PagodemainPageRoutingModule = function PagodemainPageRoutingModule() {
      _classCallCheck(this, PagodemainPageRoutingModule);
    };

    PagodemainPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], PagodemainPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pagodeservicio/pagodemain/pagodemain.module.ts":
  /*!****************************************************************!*\
    !*** ./src/app/pagodeservicio/pagodemain/pagodemain.module.ts ***!
    \****************************************************************/

  /*! exports provided: PagodemainPageModule */

  /***/
  function srcAppPagodeservicioPagodemainPagodemainModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PagodemainPageModule", function () {
      return PagodemainPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _pagodemain_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./pagodemain-routing.module */
    "./src/app/pagodeservicio/pagodemain/pagodemain-routing.module.ts");
    /* harmony import */


    var _pagodemain_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./pagodemain.page */
    "./src/app/pagodeservicio/pagodemain/pagodemain.page.ts");

    var PagodemainPageModule = function PagodemainPageModule() {
      _classCallCheck(this, PagodemainPageModule);
    };

    PagodemainPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _pagodemain_routing_module__WEBPACK_IMPORTED_MODULE_5__["PagodemainPageRoutingModule"]],
      declarations: [_pagodemain_page__WEBPACK_IMPORTED_MODULE_6__["PagodemainPage"]]
    })], PagodemainPageModule);
    /***/
  },

  /***/
  "./src/app/pagodeservicio/pagodemain/pagodemain.page.scss":
  /*!****************************************************************!*\
    !*** ./src/app/pagodeservicio/pagodemain/pagodemain.page.scss ***!
    \****************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagodeservicioPagodemainPagodemainPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header ion-title {\n  font-weight: 600;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.list-category {\n  text-align: center;\n  padding: 10px 0 5px 10px;\n}\n.list-category h4 {\n  margin: 7px 0 20px 10px;\n  text-align: left;\n  font-size: 17px;\n  font-weight: 700;\n}\n.list-category .cat-single {\n  position: relative;\n}\n.list-category .cat-single img {\n  width: 120px;\n  height: auto;\n}\n.block-category h4 {\n  margin: 0 0 18px 9px;\n  text-align: left;\n  font-size: 17px;\n  font-weight: 700;\n}\n.block-category .wrapper {\n  text-align: center;\n  border-radius: 20px;\n  padding: 7px;\n  height: 125px;\n  position: relative;\n  box-shadow: -1px 4px 12px -6px rgba(0, 0, 0, 0.38);\n  margin-bottom: 4px;\n}\n.block-category .wrapper img {\n  width: 58px;\n  margin-top: 4px;\n}\n.block-category .wrapper p {\n  margin-bottom: 4px;\n  margin-top: 0;\n  font-weight: 700;\n  color: #1f1f1f;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnb2Rlc2VydmljaW8vcGFnb2RlbWFpbi9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXHBhZ29kZXNlcnZpY2lvXFxwYWdvZGVtYWluXFxwYWdvZGVtYWluLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnb2Rlc2VydmljaW8vcGFnb2RlbWFpbi9wYWdvZGVtYWluLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGdCQUFBO0FDQUo7QURHSTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDRE47QURLQTtFQUNFLGtCQUFBO0VBQ0Esd0JBQUE7QUNGRjtBREdFO0VBQ0UsdUJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ0RKO0FER0U7RUFDRSxrQkFBQTtBQ0RKO0FERUk7RUFDRSxZQUFBO0VBQ0EsWUFBQTtBQ0FOO0FES0U7RUFDRSxvQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDRko7QURJRTtFQUNFLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0RBQUE7RUFDQSxrQkFBQTtBQ0ZKO0FER0k7RUFDRSxXQUFBO0VBQ0EsZUFBQTtBQ0ROO0FER0k7RUFDRSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNETiIsImZpbGUiOiJzcmMvYXBwL3BhZ29kZXNlcnZpY2lvL3BhZ29kZW1haW4vcGFnb2RlbWFpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tdGl0bGUge1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB9XHJcbiAgLmJ0bi1yaWdodCB7XHJcbiAgICAuYWxlcnQtdGFnIHtcclxuICAgICAgd2lkdGg6IDEycHg7XHJcbiAgICAgIGhlaWdodDogMTJweDtcclxuICAgICAgYmFja2dyb3VuZDogI2ZiNGYzMztcclxuICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICByaWdodDogLTNweDtcclxuICAgICAgYm90dG9tOiAtMnB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4ubGlzdC1jYXRlZ29yeSB7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIHBhZGRpbmc6IDEwcHggIDAgNXB4IDEwcHg7XHJcbiAgaDQge1xyXG4gICAgbWFyZ2luOiA3cHggMCAyMHB4IDEwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICB9XHJcbiAgLmNhdC1zaW5nbGUge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgaW1nIHtcclxuICAgICAgd2lkdGg6IDEyMHB4O1xyXG4gICAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbi5ibG9jay1jYXRlZ29yeSB7XHJcbiAgaDQge1xyXG4gICAgbWFyZ2luOiAwIDAgMThweCA5cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICB9XHJcbiAgLndyYXBwZXIge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgIHBhZGRpbmc6IDdweDtcclxuICAgIGhlaWdodDogMTI1cHg7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBib3gtc2hhZG93OiAtMXB4IDRweCAxMnB4IC02cHggcmdiYSgwLCAwLCAwLCAwLjM4KTtcclxuICAgIG1hcmdpbi1ib3R0b206IDRweDtcclxuICAgIGltZyB7XHJcbiAgICAgIHdpZHRoOiA1OHB4O1xyXG4gICAgICBtYXJnaW4tdG9wOiA0cHg7XHJcbiAgICB9XHJcbiAgICBwIHtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG4gICAgICBtYXJnaW4tdG9wOiAwO1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICBjb2xvcjogIzFmMWYxZjtcclxuICAgIH1cclxuICB9XHJcbn0iLCJpb24taGVhZGVyIGlvbi10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5pb24taGVhZGVyIC5idG4tcmlnaHQgLmFsZXJ0LXRhZyB7XG4gIHdpZHRoOiAxMnB4O1xuICBoZWlnaHQ6IDEycHg7XG4gIGJhY2tncm91bmQ6ICNmYjRmMzM7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IC0zcHg7XG4gIGJvdHRvbTogLTJweDtcbn1cblxuLmxpc3QtY2F0ZWdvcnkge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDEwcHggMCA1cHggMTBweDtcbn1cbi5saXN0LWNhdGVnb3J5IGg0IHtcbiAgbWFyZ2luOiA3cHggMCAyMHB4IDEwcHg7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cbi5saXN0LWNhdGVnb3J5IC5jYXQtc2luZ2xlIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLmxpc3QtY2F0ZWdvcnkgLmNhdC1zaW5nbGUgaW1nIHtcbiAgd2lkdGg6IDEyMHB4O1xuICBoZWlnaHQ6IGF1dG87XG59XG5cbi5ibG9jay1jYXRlZ29yeSBoNCB7XG4gIG1hcmdpbjogMCAwIDE4cHggOXB4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LXNpemU6IDE3cHg7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG4uYmxvY2stY2F0ZWdvcnkgLndyYXBwZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIHBhZGRpbmc6IDdweDtcbiAgaGVpZ2h0OiAxMjVweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBib3gtc2hhZG93OiAtMXB4IDRweCAxMnB4IC02cHggcmdiYSgwLCAwLCAwLCAwLjM4KTtcbiAgbWFyZ2luLWJvdHRvbTogNHB4O1xufVxuLmJsb2NrLWNhdGVnb3J5IC53cmFwcGVyIGltZyB7XG4gIHdpZHRoOiA1OHB4O1xuICBtYXJnaW4tdG9wOiA0cHg7XG59XG4uYmxvY2stY2F0ZWdvcnkgLndyYXBwZXIgcCB7XG4gIG1hcmdpbi1ib3R0b206IDRweDtcbiAgbWFyZ2luLXRvcDogMDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgY29sb3I6ICMxZjFmMWY7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pagodeservicio/pagodemain/pagodemain.page.ts":
  /*!**************************************************************!*\
    !*** ./src/app/pagodeservicio/pagodemain/pagodemain.page.ts ***!
    \**************************************************************/

  /*! exports provided: PagodemainPage */

  /***/
  function srcAppPagodeservicioPagodemainPagodemainPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PagodemainPage", function () {
      return PagodemainPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var PagodemainPage = /*#__PURE__*/function () {
      function PagodemainPage(router, menuCtrl) {
        _classCallCheck(this, PagodemainPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
        this.slidecat = {
          initialSlide: 0,
          speed: 400,
          slidesPerView: 5,
          spaceBetween: 0
        };
      }

      _createClass(PagodemainPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "PageRoute",
        value: function PageRoute(urlSlug) {
          this.router.navigateByUrl('/' + urlSlug);
        }
      }]);

      return PagodemainPage;
    }();

    PagodemainPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    PagodemainPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-pagodemain',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./pagodemain.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/pagodemain/pagodemain.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./pagodemain.page.scss */
      "./src/app/pagodeservicio/pagodemain/pagodemain.page.scss"))["default"]]
    })], PagodemainPage);
    /***/
  }
}]);
//# sourceMappingURL=pagodeservicio-pagodemain-pagodemain-module-es5.js.map