(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pagodeservicio-messagenotify-messagenotify-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/messagenotify/messagenotify.page.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/messagenotify/messagenotify.page.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"term-content\">\n    <img src=\"assets/imgs/pagodeservicio/message.png\" alt=\"\">\n    <h5>Recibo enviado</h5>\n    <p>Pharetra vulputate morbi eget dignissim nisi id arcu posuere ac. Mi et tincidunt massa sit vitae. </p>\n    <div class=\"btn-wrap\">\n      <ion-button (click)=\"home()\">Continuar</ion-button>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pagodeservicio/messagenotify/messagenotify-routing.module.ts":
/*!******************************************************************************!*\
  !*** ./src/app/pagodeservicio/messagenotify/messagenotify-routing.module.ts ***!
  \******************************************************************************/
/*! exports provided: MessagenotifyPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagenotifyPageRoutingModule", function() { return MessagenotifyPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _messagenotify_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./messagenotify.page */ "./src/app/pagodeservicio/messagenotify/messagenotify.page.ts");




const routes = [
    {
        path: '',
        component: _messagenotify_page__WEBPACK_IMPORTED_MODULE_3__["MessagenotifyPage"]
    }
];
let MessagenotifyPageRoutingModule = class MessagenotifyPageRoutingModule {
};
MessagenotifyPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MessagenotifyPageRoutingModule);



/***/ }),

/***/ "./src/app/pagodeservicio/messagenotify/messagenotify.module.ts":
/*!**********************************************************************!*\
  !*** ./src/app/pagodeservicio/messagenotify/messagenotify.module.ts ***!
  \**********************************************************************/
/*! exports provided: MessagenotifyPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagenotifyPageModule", function() { return MessagenotifyPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _messagenotify_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./messagenotify-routing.module */ "./src/app/pagodeservicio/messagenotify/messagenotify-routing.module.ts");
/* harmony import */ var _messagenotify_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./messagenotify.page */ "./src/app/pagodeservicio/messagenotify/messagenotify.page.ts");







let MessagenotifyPageModule = class MessagenotifyPageModule {
};
MessagenotifyPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _messagenotify_routing_module__WEBPACK_IMPORTED_MODULE_5__["MessagenotifyPageRoutingModule"]
        ],
        declarations: [_messagenotify_page__WEBPACK_IMPORTED_MODULE_6__["MessagenotifyPage"]]
    })
], MessagenotifyPageModule);



/***/ }),

/***/ "./src/app/pagodeservicio/messagenotify/messagenotify.page.scss":
/*!**********************************************************************!*\
  !*** ./src/app/pagodeservicio/messagenotify/messagenotify.page.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #5176f3;\n}\nion-content .term-content {\n  background: #fff;\n  padding: 20px 25px;\n  margin: 20px;\n  text-align: center;\n  border-radius: 20px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\nion-content .term-content img {\n  width: 105px;\n  margin: 0 0 6px;\n}\nion-content .term-content h5 {\n  font-size: 17px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnb2Rlc2VydmljaW8vbWVzc2FnZW5vdGlmeS9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXHBhZ29kZXNlcnZpY2lvXFxtZXNzYWdlbm90aWZ5XFxtZXNzYWdlbm90aWZ5LnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnb2Rlc2VydmljaW8vbWVzc2FnZW5vdGlmeS9tZXNzYWdlbm90aWZ5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FDQ0Y7QURBRTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLCtDQUFBO0FDRUo7QURESTtFQUNFLFlBQUE7RUFDQSxlQUFBO0FDR047QURESTtFQUNFLGVBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDR04iLCJmaWxlIjoic3JjL2FwcC9wYWdvZGVzZXJ2aWNpby9tZXNzYWdlbm90aWZ5L21lc3NhZ2Vub3RpZnkucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcclxuICAudGVybS1jb250ZW50IHtcclxuICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICBwYWRkaW5nOiAyMHB4IDI1cHg7XHJcbiAgICBtYXJnaW46IDIwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgYm94LXNoYWRvdzogMCA3cHggMTZweCAtN3B4IHJnYmEoMCwgMCwgMCwgMC42OSk7XHJcbiAgICBpbWcge1xyXG4gICAgICB3aWR0aDogMTA1cHg7XHJcbiAgICAgIG1hcmdpbjogMCAwIDZweDtcclxuICAgIH1cclxuICAgIGg1IHtcclxuICAgICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgICBtYXJnaW4tdG9wOiA2cHg7XHJcbiAgICAgIGNvbG9yOiAjMmM1NWUwO1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgfVxyXG4gIH1cclxufSIsImlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHBhZGRpbmc6IDIwcHggMjVweDtcbiAgbWFyZ2luOiAyMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIGJveC1zaGFkb3c6IDAgN3B4IDE2cHggLTdweCByZ2JhKDAsIDAsIDAsIDAuNjkpO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBpbWcge1xuICB3aWR0aDogMTA1cHg7XG4gIG1hcmdpbjogMCAwIDZweDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaDUge1xuICBmb250LXNpemU6IDE3cHg7XG4gIG1hcmdpbi10b3A6IDZweDtcbiAgY29sb3I6ICMyYzU1ZTA7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59Il19 */");

/***/ }),

/***/ "./src/app/pagodeservicio/messagenotify/messagenotify.page.ts":
/*!********************************************************************!*\
  !*** ./src/app/pagodeservicio/messagenotify/messagenotify.page.ts ***!
  \********************************************************************/
/*! exports provided: MessagenotifyPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagenotifyPage", function() { return MessagenotifyPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let MessagenotifyPage = class MessagenotifyPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    home() {
        this.router.navigateByUrl('/home');
    }
};
MessagenotifyPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
MessagenotifyPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-messagenotify',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./messagenotify.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/messagenotify/messagenotify.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./messagenotify.page.scss */ "./src/app/pagodeservicio/messagenotify/messagenotify.page.scss")).default]
    })
], MessagenotifyPage);



/***/ })

}]);
//# sourceMappingURL=pagodeservicio-messagenotify-messagenotify-module-es2015.js.map