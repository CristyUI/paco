(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["loginconfirm-loginconfirm-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/loginconfirm/loginconfirm.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/loginconfirm/loginconfirm.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Confirmación</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n       <ion-icon name=\"help-circle-outline\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <img src=\"assets/imgs/login-confirm.png\" alt=\"\">\n    <h4>¿Eres Carla A. Dillard?</h4>\n    <p>Vivamus sit amet diam rhoncus, porttitor ex a, semper arcu. Pellentesque imperdiet turpis quis lectus gravida rutrum quis\n      sit amet leo. Etiam id tincidunt diam, eleifend pretium dolor. Cras sed tincidunt felis. </p>\n  </div>\n</ion-content>\n\n\n<ion-footer>\n  <ion-row>\n    <ion-col size=\"6\">\n      <ion-button class=\"btn-transparent\">No soy yo</ion-button>\n    </ion-col>\n    <ion-col size=\"6\">\n      <ion-button class=\"btn-register\">Continuar</ion-button>\n    </ion-col>\n  </ion-row>\n</ion-footer>\n");

/***/ }),

/***/ "./src/app/loginconfirm/loginconfirm-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/loginconfirm/loginconfirm-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: LoginconfirmPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginconfirmPageRoutingModule", function() { return LoginconfirmPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _loginconfirm_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./loginconfirm.page */ "./src/app/loginconfirm/loginconfirm.page.ts");




const routes = [
    {
        path: '',
        component: _loginconfirm_page__WEBPACK_IMPORTED_MODULE_3__["LoginconfirmPage"]
    }
];
let LoginconfirmPageRoutingModule = class LoginconfirmPageRoutingModule {
};
LoginconfirmPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LoginconfirmPageRoutingModule);



/***/ }),

/***/ "./src/app/loginconfirm/loginconfirm.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/loginconfirm/loginconfirm.module.ts ***!
  \*****************************************************/
/*! exports provided: LoginconfirmPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginconfirmPageModule", function() { return LoginconfirmPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _loginconfirm_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./loginconfirm-routing.module */ "./src/app/loginconfirm/loginconfirm-routing.module.ts");
/* harmony import */ var _loginconfirm_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./loginconfirm.page */ "./src/app/loginconfirm/loginconfirm.page.ts");







let LoginconfirmPageModule = class LoginconfirmPageModule {
};
LoginconfirmPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _loginconfirm_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginconfirmPageRoutingModule"]
        ],
        declarations: [_loginconfirm_page__WEBPACK_IMPORTED_MODULE_6__["LoginconfirmPage"]]
    })
], LoginconfirmPageModule);



/***/ }),

/***/ "./src/app/loginconfirm/loginconfirm.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/loginconfirm/loginconfirm.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header::after {\n  background-image: none !important;\n}\nion-header .btn-right ion-icon {\n  font-size: 24px;\n}\nion-content {\n  --background: #5176f3;\n}\nion-content .ion-padding {\n  text-align: center;\n}\nion-content .ion-padding img {\n  margin: 10px 0 26px;\n  width: 150px;\n}\nion-content .ion-padding h4 {\n  color: #fff;\n  font-size: 18px;\n  font-weight: 700;\n  margin: 5px 0 20px;\n}\nion-content .ion-padding p {\n  color: #fff;\n}\nion-footer {\n  text-align: center;\n  background: #5176f3;\n}\nion-footer::before {\n  background-image: none !important;\n}\nion-footer .btn-transparent {\n  color: #fff;\n  height: 1.4rem;\n  margin-bottom: 15px !important;\n  --box-shadow: none!important;\n  margin-top: 12px !important;\n  --padding-end: 4px;\n  font-weight: 400;\n  text-transform: capitalize;\n  --padding-start: 4px;\n  width: auto !important;\n  --border-radius: none!important;\n}\nion-footer .btn-register {\n  --background: #fff;\n  color: #2f57de;\n  margin-top: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW5jb25maXJtL0c6XFxpb25pY1xcRklWRVJSXFxwYW50YWxsYXMtcGFjby9zcmNcXGFwcFxcbG9naW5jb25maXJtXFxsb2dpbmNvbmZpcm0ucGFnZS5zY3NzIiwic3JjL2FwcC9sb2dpbmNvbmZpcm0vbG9naW5jb25maXJtLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGlDQUFBO0FDQUo7QURHSTtFQUNFLGVBQUE7QUNETjtBREtBO0VBQ0UscUJBQUE7QUNGRjtBREdFO0VBQ0Usa0JBQUE7QUNESjtBREVJO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0FDQU47QURFSTtFQUNFLFdBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQ0FOO0FERUk7RUFDRSxXQUFBO0FDQU47QURLQTtFQUlFLGtCQUFBO0VBQ0EsbUJBQUE7QUNMRjtBRENFO0VBQ0UsaUNBQUE7QUNDSjtBREdFO0VBQ0UsV0FBQTtFQUNBLGNBQUE7RUFDQSw4QkFBQTtFQUNBLDRCQUFBO0VBQ0EsMkJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsMEJBQUE7RUFDQSxvQkFBQTtFQUNBLHNCQUFBO0VBQ0EsK0JBQUE7QUNESjtBREdFO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQ0RKIiwiZmlsZSI6InNyYy9hcHAvbG9naW5jb25maXJtL2xvZ2luY29uZmlybS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICAmOjphZnRlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBub25lIWltcG9ydGFudDtcclxuICB9XHJcbiAgLmJ0bi1yaWdodCB7XHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMjRweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcclxuICAuaW9uLXBhZGRpbmcge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgaW1nIHtcclxuICAgICAgbWFyZ2luOiAxMHB4IDAgMjZweDtcclxuICAgICAgd2lkdGg6IDE1MHB4O1xyXG4gICAgfVxyXG4gICAgaDQge1xyXG4gICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICBtYXJnaW46IDVweCAwIDIwcHg7XHJcbiAgICB9XHJcbiAgICBwIHtcclxuICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5pb24tZm9vdGVyIHtcclxuICAmOjpiZWZvcmUge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogbm9uZSFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gIC5idG4tdHJhbnNwYXJlbnQge1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBoZWlnaHQ6IDEuNHJlbTtcclxuICAgIG1hcmdpbi1ib3R0b206IDE1cHghaW1wb3J0YW50O1xyXG4gICAgLS1ib3gtc2hhZG93OiBub25lIWltcG9ydGFudDtcclxuICAgIG1hcmdpbi10b3A6IDEycHghaW1wb3J0YW50O1xyXG4gICAgLS1wYWRkaW5nLWVuZDogNHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xyXG4gICAgLS1wYWRkaW5nLXN0YXJ0OiA0cHg7XHJcbiAgICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiBub25lIWltcG9ydGFudDtcclxuICB9XHJcbiAgLmJ0bi1yZWdpc3RlciB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICBjb2xvcjogIzJmNTdkZTtcclxuICAgIG1hcmdpbi10b3A6IDVweDtcclxuICB9XHJcbn0iLCJpb24taGVhZGVyOjphZnRlciB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmUgIWltcG9ydGFudDtcbn1cbmlvbi1oZWFkZXIgLmJ0bi1yaWdodCBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjRweDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgaW1nIHtcbiAgbWFyZ2luOiAxMHB4IDAgMjZweDtcbiAgd2lkdGg6IDE1MHB4O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIGg0IHtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgbWFyZ2luOiA1cHggMCAyMHB4O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIHAge1xuICBjb2xvcjogI2ZmZjtcbn1cblxuaW9uLWZvb3RlciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZDogIzUxNzZmMztcbn1cbmlvbi1mb290ZXI6OmJlZm9yZSB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmUgIWltcG9ydGFudDtcbn1cbmlvbi1mb290ZXIgLmJ0bi10cmFuc3BhcmVudCB7XG4gIGNvbG9yOiAjZmZmO1xuICBoZWlnaHQ6IDEuNHJlbTtcbiAgbWFyZ2luLWJvdHRvbTogMTVweCAhaW1wb3J0YW50O1xuICAtLWJveC1zaGFkb3c6IG5vbmUhaW1wb3J0YW50O1xuICBtYXJnaW4tdG9wOiAxMnB4ICFpbXBvcnRhbnQ7XG4gIC0tcGFkZGluZy1lbmQ6IDRweDtcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gIC0tcGFkZGluZy1zdGFydDogNHB4O1xuICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xuICAtLWJvcmRlci1yYWRpdXM6IG5vbmUhaW1wb3J0YW50O1xufVxuaW9uLWZvb3RlciAuYnRuLXJlZ2lzdGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xuICBjb2xvcjogIzJmNTdkZTtcbiAgbWFyZ2luLXRvcDogNXB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/loginconfirm/loginconfirm.page.ts":
/*!***************************************************!*\
  !*** ./src/app/loginconfirm/loginconfirm.page.ts ***!
  \***************************************************/
/*! exports provided: LoginconfirmPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginconfirmPage", function() { return LoginconfirmPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let LoginconfirmPage = class LoginconfirmPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
};
LoginconfirmPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
LoginconfirmPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-loginconfirm',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./loginconfirm.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/loginconfirm/loginconfirm.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./loginconfirm.page.scss */ "./src/app/loginconfirm/loginconfirm.page.scss")).default]
    })
], LoginconfirmPage);



/***/ })

}]);
//# sourceMappingURL=loginconfirm-loginconfirm-module-es2015.js.map