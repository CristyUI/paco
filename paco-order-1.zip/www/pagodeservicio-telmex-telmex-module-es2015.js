(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pagodeservicio-telmex-telmex-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/telmex/telmex.page.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/telmex/telmex.page.html ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"telmex-content\">\n    <div class=\"tv-logo\">\n      <img src=\"assets/imgs/pagodeservicio/tv-6.png\">\n    </div>\n    <h5>Monto a pagar</h5>\n    <h3>$ 999.00</h3>\n\n     <div class=\"receipt-tag wow fadeIn animated\" *ngIf=\"receiptCamera\">\n       <h4>Referencia <span> <img src=\"assets/imgs/pagodeservicio/camera.png\"></span></h4>\n       <ul class=\"reference-link\">\n         <li class=\"ref-btn-1\" (click)=\"viewRef()\" class=\"ref-btn-1\">¿Cuál es la referencia?</li>\n         <li class=\"ref-btn-2\" *ngIf=\"closeIc\" (click)=\"closeRef()\"><ion-icon name=\"close\"></ion-icon></li>\n       </ul>\n\n       <div class=\"ref-block wow fadeIn animated\" *ngIf=\"linkWrap\">\n         <p>Pharetra vulputate morbi eget dignissim nisi id arcu posuere ac. Mi et tincidunt massa sit vitae, </p>\n         <img src=\"assets/imgs/pagodeservicio/ast.png\" alt=\"\">\n       </div>\n\n       <h6>Saldo disponible <span>$ 3,600.00</span></h6>\n     </div>\n\n    <div class=\"content-receipt wow fadeIn animated\" *ngIf=\"receiptContent\">\n      <ul>\n        <li>Comisión<span>+ $ 10.00</span></li>\n        <li>Total<span>$ 1,009.00</span></li>\n        <li>Saldo restante<span>$ 2,591.00</span></li>\n      </ul>\n      <ion-list>\n        <ion-item>\n          <ion-checkbox></ion-checkbox>\n          <ion-label>He leído y acepto los términos y condiciones.</ion-label>\n        </ion-item>\n      </ion-list>\n      <p>Lorem ipsum dolor sit amet, consectetur 20% adipiscing elit. Mauris ultricies lacus ut turpis venenatis posuere.\n        Curabitur ullamcorper quam elementum hendrerit dignissim.</p>\n    </div>\n\n    <div class=\"btn-bottom-one\" *ngIf=\"btn1\">\n      <ion-button class=\"full-btn\" (click)=\"showreceipt()\">Continuar</ion-button>\n    </div>\n\n     <div class=\"btn-bottom-two\" *ngIf=\"btn2\">\n       <ion-row>\n         <ion-col size=\"6\">\n           <ion-button class=\"btn-transparent\" (click)=\"closereceipt()\">Anterior</ion-button>\n         </ion-col>\n         <ion-col size=\"6\">\n           <ion-button class=\"full-btn\" (click)=\"telmexconfirm()\">Continuar</ion-button>\n         </ion-col>\n       </ion-row>\n     </div>\n  </div>\n</ion-content>\n\n");

/***/ }),

/***/ "./src/app/pagodeservicio/telmex/telmex-routing.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/pagodeservicio/telmex/telmex-routing.module.ts ***!
  \****************************************************************/
/*! exports provided: TelmexPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TelmexPageRoutingModule", function() { return TelmexPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _telmex_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./telmex.page */ "./src/app/pagodeservicio/telmex/telmex.page.ts");




const routes = [
    {
        path: '',
        component: _telmex_page__WEBPACK_IMPORTED_MODULE_3__["TelmexPage"]
    }
];
let TelmexPageRoutingModule = class TelmexPageRoutingModule {
};
TelmexPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TelmexPageRoutingModule);



/***/ }),

/***/ "./src/app/pagodeservicio/telmex/telmex.module.ts":
/*!********************************************************!*\
  !*** ./src/app/pagodeservicio/telmex/telmex.module.ts ***!
  \********************************************************/
/*! exports provided: TelmexPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TelmexPageModule", function() { return TelmexPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _telmex_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./telmex-routing.module */ "./src/app/pagodeservicio/telmex/telmex-routing.module.ts");
/* harmony import */ var _telmex_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./telmex.page */ "./src/app/pagodeservicio/telmex/telmex.page.ts");







let TelmexPageModule = class TelmexPageModule {
};
TelmexPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _telmex_routing_module__WEBPACK_IMPORTED_MODULE_5__["TelmexPageRoutingModule"]
        ],
        declarations: [_telmex_page__WEBPACK_IMPORTED_MODULE_6__["TelmexPage"]]
    })
], TelmexPageModule);



/***/ }),

/***/ "./src/app/pagodeservicio/telmex/telmex.page.scss":
/*!********************************************************!*\
  !*** ./src/app/pagodeservicio/telmex/telmex.page.scss ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #5176f3;\n}\nion-content .telmex-content {\n  background: #fff;\n  padding: 20px 25px;\n  margin: 10px 20px 20px;\n  border-radius: 20px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\nion-content .telmex-content .tv-logo {\n  text-align: center;\n}\nion-content .telmex-content .tv-logo img {\n  width: 55px;\n}\nion-content .telmex-content h5 {\n  font-size: 17px;\n  margin-top: 6px;\n  font-weight: 700;\n}\nion-content .telmex-content h3 {\n  background: #5176f3;\n  text-align: center;\n  color: #fff;\n  font-weight: 700;\n  font-size: 29px;\n  border-radius: 30px;\n  padding: 10px;\n  letter-spacing: 2px;\n  margin-bottom: 14px;\n}\nion-content .telmex-content .receipt-tag h4 {\n  border: 2px solid #5176f3;\n  border-radius: 36px;\n  padding: 12px 18px;\n  font-size: 16px;\n  color: #5176f3;\n  font-weight: 600;\n}\nion-content .telmex-content .receipt-tag h4 span {\n  float: right;\n}\nion-content .telmex-content .receipt-tag h4 span img {\n  width: 25px;\n  vertical-align: sub;\n}\nion-content .telmex-content .receipt-tag .reference-link {\n  padding-left: 0;\n}\nion-content .telmex-content .receipt-tag .reference-link li {\n  list-style-type: none;\n  display: inline-block;\n}\nion-content .telmex-content .receipt-tag .reference-link .ref-btn-1 {\n  width: 70%;\n  color: #5176f3;\n  font-weight: 700;\n}\nion-content .telmex-content .receipt-tag .reference-link .ref-btn-2 {\n  width: 30%;\n  text-align: right;\n}\nion-content .telmex-content .receipt-tag .reference-link .ref-btn-2 ion-icon {\n  font-size: 28px;\n  color: #5176f3;\n  vertical-align: middle;\n}\nion-content .telmex-content .receipt-tag .ref-block p {\n  color: #949393;\n}\nion-content .telmex-content .receipt-tag h6 {\n  color: #949393;\n  font-size: 15px;\n  padding: 0 4px;\n}\nion-content .telmex-content .receipt-tag h6 span {\n  font-size: 16px;\n  color: #000;\n  float: right;\n}\nion-content .telmex-content .content-receipt ul {\n  padding-left: 0;\n}\nion-content .telmex-content .content-receipt ul li {\n  list-style-type: none;\n  padding: 5px 0;\n}\nion-content .telmex-content .content-receipt ul li span {\n  float: right;\n}\nion-content .telmex-content .content-receipt ul li:nth-child(2) span {\n  color: #2246bf;\n}\nion-content .telmex-content .content-receipt ion-list ion-item {\n  --border-color: #fff;\n  border: 1px solid #2246bf;\n  border-radius: 30px;\n  font-size: 14px;\n}\nion-content .telmex-content .content-receipt ion-list ion-item ion-checkbox {\n  --border-radius: 50%;\n  --size: 24px;\n  --border-color: #4d6fe0;\n  margin: 15px 0;\n}\nion-content .telmex-content .content-receipt ion-list ion-item ion-label {\n  white-space: normal;\n  margin: 0 10px;\n  color: #2246bf;\n}\nion-content .telmex-content .content-receipt p {\n  color: #949393;\n  margin-top: 5px;\n}\nion-content .telmex-content .btn-bottom-one {\n  padding-top: 12px;\n  text-align: right;\n}\nion-content .telmex-content .btn-bottom-one .full-btn {\n  margin-top: 5px;\n  height: 3rem;\n  width: 46% !important;\n}\nion-content .telmex-content .btn-bottom-two {\n  padding-top: 12px;\n  text-align: center;\n}\nion-content .telmex-content .btn-bottom-two .btn-transparent {\n  color: #2246bf;\n  height: 1.6rem;\n  margin-bottom: 15px !important;\n  --box-shadow: none!important;\n  margin-top: 12px !important;\n  --padding-end: 4px;\n  font-weight: 700;\n  text-transform: capitalize;\n  --padding-start: 4px;\n  width: auto !important;\n  --border-radius: none!important;\n}\nion-content .telmex-content .btn-bottom-two .full-btn {\n  margin-top: 5px;\n  height: 3rem;\n  width: 100% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnb2Rlc2VydmljaW8vdGVsbWV4L0c6XFxpb25pY1xcRklWRVJSXFxwYW50YWxsYXMtcGFjby9zcmNcXGFwcFxccGFnb2Rlc2VydmljaW9cXHRlbG1leFxcdGVsbWV4LnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnb2Rlc2VydmljaW8vdGVsbWV4L3RlbG1leC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtBQ0NGO0FEQUU7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLCtDQUFBO0FDRUo7QURESTtFQUNFLGtCQUFBO0FDR047QURGTTtFQUNFLFdBQUE7QUNJUjtBRERJO0VBQ0UsZUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ0dOO0FEREk7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUNHTjtBREFNO0VBQ0UseUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQ0VSO0FERFE7RUFDRSxZQUFBO0FDR1Y7QURGVTtFQUNFLFdBQUE7RUFDQSxtQkFBQTtBQ0laO0FEQU07RUFDRSxlQUFBO0FDRVI7QUREUTtFQUNFLHFCQUFBO0VBQ0EscUJBQUE7QUNHVjtBRERRO0VBQ0UsVUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQ0dWO0FERFE7RUFDRSxVQUFBO0VBQ0EsaUJBQUE7QUNHVjtBREZVO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxzQkFBQTtBQ0laO0FESVE7RUFDRSxjQUFBO0FDRlY7QURLTTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQ0hSO0FESVE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNGVjtBRE9NO0VBQ0UsZUFBQTtBQ0xSO0FETVE7RUFDRSxxQkFBQTtFQUNBLGNBQUE7QUNKVjtBREtVO0VBQ0MsWUFBQTtBQ0hYO0FETVk7RUFDRSxjQUFBO0FDSmQ7QURVUTtFQUNFLG9CQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7QUNSVjtBRFNVO0VBQ0Usb0JBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxjQUFBO0FDUFo7QURTVTtFQUNFLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7QUNQWjtBRFdNO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUNUUjtBRFlJO0VBQ0UsaUJBQUE7RUFDQSxpQkFBQTtBQ1ZOO0FEV007RUFDRSxlQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0FDVFI7QURZSTtFQUNFLGlCQUFBO0VBQ0Esa0JBQUE7QUNWTjtBRFdNO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSw4QkFBQTtFQUNBLDRCQUFBO0VBQ0EsMkJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsMEJBQUE7RUFDQSxvQkFBQTtFQUNBLHNCQUFBO0VBQ0EsK0JBQUE7QUNUUjtBRFdNO0VBQ0UsZUFBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtBQ1RSIiwiZmlsZSI6InNyYy9hcHAvcGFnb2Rlc2VydmljaW8vdGVsbWV4L3RlbG1leC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gIC50ZWxtZXgtY29udGVudCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgcGFkZGluZzogMjBweCAyNXB4O1xyXG4gICAgbWFyZ2luOiAxMHB4IDIwcHggMjBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcclxuICAgIC50di1sb2dvIHtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBpbWcge1xyXG4gICAgICAgIHdpZHRoOiA1NXB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBoNSB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTdweDtcclxuICAgICAgbWFyZ2luLXRvcDogNnB4O1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgfVxyXG4gICAgaDMge1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICBmb250LXNpemU6IDI5cHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICAgIGxldHRlci1zcGFjaW5nOiAycHg7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDE0cHg7XHJcbiAgICB9XHJcbiAgICAucmVjZWlwdC10YWcge1xyXG4gICAgICBoNCB7XHJcbiAgICAgICAgYm9yZGVyOiAycHggc29saWQgIzUxNzZmMztcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAzNnB4O1xyXG4gICAgICAgIHBhZGRpbmc6IDEycHggMThweDtcclxuICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgY29sb3I6ICM1MTc2ZjM7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICBzcGFuIHtcclxuICAgICAgICAgIGZsb2F0OiByaWdodDtcclxuICAgICAgICAgIGltZyB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAyNXB4O1xyXG4gICAgICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogc3ViO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAucmVmZXJlbmNlLWxpbmsge1xyXG4gICAgICAgIHBhZGRpbmctbGVmdDogMDtcclxuICAgICAgICBsaSB7XHJcbiAgICAgICAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XHJcbiAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5yZWYtYnRuLTEge1xyXG4gICAgICAgICAgd2lkdGg6IDcwJTtcclxuICAgICAgICAgIGNvbG9yOiAjNTE3NmYzO1xyXG4gICAgICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnJlZi1idG4tMiB7XHJcbiAgICAgICAgICB3aWR0aDogMzAlO1xyXG4gICAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjhweDtcclxuICAgICAgICAgICAgY29sb3I6ICM1MTc2ZjM7XHJcbiAgICAgICAgICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIC5yZWYtYmxvY2sge1xyXG4gICAgICAgIGltZyB7XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICBwIHtcclxuICAgICAgICAgIGNvbG9yOiAjOTQ5MzkzO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBoNiB7XHJcbiAgICAgICAgY29sb3I6ICM5NDkzOTM7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgIHBhZGRpbmc6IDAgNHB4O1xyXG4gICAgICAgIHNwYW4ge1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgY29sb3I6ICMwMDA7XHJcbiAgICAgICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAuY29udGVudC1yZWNlaXB0IHtcclxuICAgICAgdWwge1xyXG4gICAgICAgIHBhZGRpbmctbGVmdDogMDtcclxuICAgICAgICBsaSB7XHJcbiAgICAgICAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XHJcbiAgICAgICAgICBwYWRkaW5nOiA1cHggMDtcclxuICAgICAgICAgIHNwYW4ge1xyXG4gICAgICAgICAgIGZsb2F0OiByaWdodDtcclxuICAgICAgICAgfVxyXG4gICAgICAgICAgJjpudGgtY2hpbGQoMikge1xyXG4gICAgICAgICAgICBzcGFuIHtcclxuICAgICAgICAgICAgICBjb2xvcjogIzIyNDZiZjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBpb24tbGlzdCB7XHJcbiAgICAgICAgaW9uLWl0ZW0ge1xyXG4gICAgICAgICAgLS1ib3JkZXItY29sb3I6ICNmZmY7XHJcbiAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjMjI0NmJmO1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgIGlvbi1jaGVja2JveCB7XHJcbiAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgICAtLXNpemU6IDI0cHg7XHJcbiAgICAgICAgICAgIC0tYm9yZGVyLWNvbG9yOiAjNGQ2ZmUwO1xyXG4gICAgICAgICAgICBtYXJnaW46IDE1cHggMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3JtYWw7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMCAxMHB4O1xyXG4gICAgICAgICAgICBjb2xvcjogIzIyNDZiZjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgcCB7XHJcbiAgICAgICAgY29sb3I6ICM5NDkzOTM7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAuYnRuLWJvdHRvbS1vbmUge1xyXG4gICAgICBwYWRkaW5nLXRvcDogMTJweDtcclxuICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICAgIC5mdWxsLWJ0biB7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgICAgIGhlaWdodDogM3JlbTtcclxuICAgICAgICB3aWR0aDogNDYlIWltcG9ydGFudDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmJ0bi1ib3R0b20tdHdvIHtcclxuICAgICAgcGFkZGluZy10b3A6IDEycHg7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgLmJ0bi10cmFuc3BhcmVudCB7XHJcbiAgICAgICAgY29sb3I6ICMyMjQ2YmY7XHJcbiAgICAgICAgaGVpZ2h0OiAxLjZyZW07XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMTVweCFpbXBvcnRhbnQ7XHJcbiAgICAgICAgLS1ib3gtc2hhZG93OiBub25lIWltcG9ydGFudDtcclxuICAgICAgICBtYXJnaW4tdG9wOiAxMnB4IWltcG9ydGFudDtcclxuICAgICAgICAtLXBhZGRpbmctZW5kOiA0cHg7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcclxuICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDRweDtcclxuICAgICAgICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xyXG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogbm9uZSFpbXBvcnRhbnQ7XHJcbiAgICAgIH1cclxuICAgICAgLmZ1bGwtYnRuIHtcclxuICAgICAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICAgICAgaGVpZ2h0OiAzcmVtO1xyXG4gICAgICAgIHdpZHRoOiAxMDAlIWltcG9ydGFudDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufSIsImlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xufVxuaW9uLWNvbnRlbnQgLnRlbG1leC1jb250ZW50IHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgcGFkZGluZzogMjBweCAyNXB4O1xuICBtYXJnaW46IDEwcHggMjBweCAyMHB4O1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAudHYtbG9nbyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAudHYtbG9nbyBpbWcge1xuICB3aWR0aDogNTVweDtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCBoNSB7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBmb250LXdlaWdodDogNzAwO1xufVxuaW9uLWNvbnRlbnQgLnRlbG1leC1jb250ZW50IGgzIHtcbiAgYmFja2dyb3VuZDogIzUxNzZmMztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgZm9udC1zaXplOiAyOXB4O1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBwYWRkaW5nOiAxMHB4O1xuICBsZXR0ZXItc3BhY2luZzogMnB4O1xuICBtYXJnaW4tYm90dG9tOiAxNHB4O1xufVxuaW9uLWNvbnRlbnQgLnRlbG1leC1jb250ZW50IC5yZWNlaXB0LXRhZyBoNCB7XG4gIGJvcmRlcjogMnB4IHNvbGlkICM1MTc2ZjM7XG4gIGJvcmRlci1yYWRpdXM6IDM2cHg7XG4gIHBhZGRpbmc6IDEycHggMThweDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBjb2xvcjogIzUxNzZmMztcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAucmVjZWlwdC10YWcgaDQgc3BhbiB7XG4gIGZsb2F0OiByaWdodDtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAucmVjZWlwdC10YWcgaDQgc3BhbiBpbWcge1xuICB3aWR0aDogMjVweDtcbiAgdmVydGljYWwtYWxpZ246IHN1Yjtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAucmVjZWlwdC10YWcgLnJlZmVyZW5jZS1saW5rIHtcbiAgcGFkZGluZy1sZWZ0OiAwO1xufVxuaW9uLWNvbnRlbnQgLnRlbG1leC1jb250ZW50IC5yZWNlaXB0LXRhZyAucmVmZXJlbmNlLWxpbmsgbGkge1xuICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAucmVjZWlwdC10YWcgLnJlZmVyZW5jZS1saW5rIC5yZWYtYnRuLTEge1xuICB3aWR0aDogNzAlO1xuICBjb2xvcjogIzUxNzZmMztcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAucmVjZWlwdC10YWcgLnJlZmVyZW5jZS1saW5rIC5yZWYtYnRuLTIge1xuICB3aWR0aDogMzAlO1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAucmVjZWlwdC10YWcgLnJlZmVyZW5jZS1saW5rIC5yZWYtYnRuLTIgaW9uLWljb24ge1xuICBmb250LXNpemU6IDI4cHg7XG4gIGNvbG9yOiAjNTE3NmYzO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xufVxuaW9uLWNvbnRlbnQgLnRlbG1leC1jb250ZW50IC5yZWNlaXB0LXRhZyAucmVmLWJsb2NrIHAge1xuICBjb2xvcjogIzk0OTM5Mztcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAucmVjZWlwdC10YWcgaDYge1xuICBjb2xvcjogIzk0OTM5MztcbiAgZm9udC1zaXplOiAxNXB4O1xuICBwYWRkaW5nOiAwIDRweDtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAucmVjZWlwdC10YWcgaDYgc3BhbiB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6ICMwMDA7XG4gIGZsb2F0OiByaWdodDtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAuY29udGVudC1yZWNlaXB0IHVsIHtcbiAgcGFkZGluZy1sZWZ0OiAwO1xufVxuaW9uLWNvbnRlbnQgLnRlbG1leC1jb250ZW50IC5jb250ZW50LXJlY2VpcHQgdWwgbGkge1xuICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XG4gIHBhZGRpbmc6IDVweCAwO1xufVxuaW9uLWNvbnRlbnQgLnRlbG1leC1jb250ZW50IC5jb250ZW50LXJlY2VpcHQgdWwgbGkgc3BhbiB7XG4gIGZsb2F0OiByaWdodDtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAuY29udGVudC1yZWNlaXB0IHVsIGxpOm50aC1jaGlsZCgyKSBzcGFuIHtcbiAgY29sb3I6ICMyMjQ2YmY7XG59XG5pb24tY29udGVudCAudGVsbWV4LWNvbnRlbnQgLmNvbnRlbnQtcmVjZWlwdCBpb24tbGlzdCBpb24taXRlbSB7XG4gIC0tYm9yZGVyLWNvbG9yOiAjZmZmO1xuICBib3JkZXI6IDFweCBzb2xpZCAjMjI0NmJmO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBmb250LXNpemU6IDE0cHg7XG59XG5pb24tY29udGVudCAudGVsbWV4LWNvbnRlbnQgLmNvbnRlbnQtcmVjZWlwdCBpb24tbGlzdCBpb24taXRlbSBpb24tY2hlY2tib3gge1xuICAtLWJvcmRlci1yYWRpdXM6IDUwJTtcbiAgLS1zaXplOiAyNHB4O1xuICAtLWJvcmRlci1jb2xvcjogIzRkNmZlMDtcbiAgbWFyZ2luOiAxNXB4IDA7XG59XG5pb24tY29udGVudCAudGVsbWV4LWNvbnRlbnQgLmNvbnRlbnQtcmVjZWlwdCBpb24tbGlzdCBpb24taXRlbSBpb24tbGFiZWwge1xuICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xuICBtYXJnaW46IDAgMTBweDtcbiAgY29sb3I6ICMyMjQ2YmY7XG59XG5pb24tY29udGVudCAudGVsbWV4LWNvbnRlbnQgLmNvbnRlbnQtcmVjZWlwdCBwIHtcbiAgY29sb3I6ICM5NDkzOTM7XG4gIG1hcmdpbi10b3A6IDVweDtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAuYnRuLWJvdHRvbS1vbmUge1xuICBwYWRkaW5nLXRvcDogMTJweDtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5pb24tY29udGVudCAudGVsbWV4LWNvbnRlbnQgLmJ0bi1ib3R0b20tb25lIC5mdWxsLWJ0biB7XG4gIG1hcmdpbi10b3A6IDVweDtcbiAgaGVpZ2h0OiAzcmVtO1xuICB3aWR0aDogNDYlICFpbXBvcnRhbnQ7XG59XG5pb24tY29udGVudCAudGVsbWV4LWNvbnRlbnQgLmJ0bi1ib3R0b20tdHdvIHtcbiAgcGFkZGluZy10b3A6IDEycHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAuYnRuLWJvdHRvbS10d28gLmJ0bi10cmFuc3BhcmVudCB7XG4gIGNvbG9yOiAjMjI0NmJmO1xuICBoZWlnaHQ6IDEuNnJlbTtcbiAgbWFyZ2luLWJvdHRvbTogMTVweCAhaW1wb3J0YW50O1xuICAtLWJveC1zaGFkb3c6IG5vbmUhaW1wb3J0YW50O1xuICBtYXJnaW4tdG9wOiAxMnB4ICFpbXBvcnRhbnQ7XG4gIC0tcGFkZGluZy1lbmQ6IDRweDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gIC0tcGFkZGluZy1zdGFydDogNHB4O1xuICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xuICAtLWJvcmRlci1yYWRpdXM6IG5vbmUhaW1wb3J0YW50O1xufVxuaW9uLWNvbnRlbnQgLnRlbG1leC1jb250ZW50IC5idG4tYm90dG9tLXR3byAuZnVsbC1idG4ge1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIGhlaWdodDogM3JlbTtcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pagodeservicio/telmex/telmex.page.ts":
/*!******************************************************!*\
  !*** ./src/app/pagodeservicio/telmex/telmex.page.ts ***!
  \******************************************************/
/*! exports provided: TelmexPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TelmexPage", function() { return TelmexPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let TelmexPage = class TelmexPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
        this.linkWrap = false;
        this.receiptContent = false;
        this.receiptCamera = true;
        this.btn1 = true;
        this.btn2 = false;
        this.closeIc = false;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    showreceipt() {
        this.receiptContent = true;
        this.receiptCamera = false;
        this.btn1 = false;
        this.btn2 = true;
    }
    closereceipt() {
        this.receiptContent = false;
        this.receiptCamera = true;
        this.btn1 = true;
        this.btn2 = false;
    }
    viewRef() {
        this.linkWrap = true;
        this.closeIc = true;
    }
    closeRef() {
        this.linkWrap = false;
        this.closeIc = false;
    }
    telmexconfirm() {
        this.router.navigateByUrl('/telmexconfirm');
    }
};
TelmexPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
TelmexPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-telmex',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./telmex.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/telmex/telmex.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./telmex.page.scss */ "./src/app/pagodeservicio/telmex/telmex.page.scss")).default]
    })
], TelmexPage);



/***/ })

}]);
//# sourceMappingURL=pagodeservicio-telmex-telmex-module-es2015.js.map