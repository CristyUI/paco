function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
  /*!***************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"secondary\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title><img src=\"assets/imgs/text-logo.png\" alt=\"\"></ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content style=\"--background: url(assets/imgs/home-bg.png) no-repeat center center / cover;\">\n   <div class=\"ion-padding\">\n     <div class=\"top-image\">\n       <img src=\"assets/imgs/home-chat.png\" alt=\"\">\n     </div>\n     <div class=\"block-category\">\n       <ion-row>\n         <ion-col size=\"6\">\n           <div class=\"wrapper\">\n             <img src=\"assets/imgs/h-1.png\" alt=\"\">\n             <p>Adelanto de nómina</p>\n           </div>\n         </ion-col>\n         <ion-col size=\"6\">\n           <div class=\"wrapper\">\n             <img src=\"assets/imgs/h-2.png\" alt=\"\">\n             <p>Recargas</p>\n           </div>\n         </ion-col>\n         <ion-col size=\"6\">\n           <div class=\"wrapper\" (click)=\"PageRoute('pagodemain')\">\n             <img src=\"assets/imgs/h-3.png\" alt=\"\">\n             <p>Pago de servicios</p>\n           </div>\n         </ion-col>\n         <ion-col size=\"6\">\n           <div class=\"wrapper\">\n             <img src=\"assets/imgs/h-4.png\" alt=\"\">\n             <p>Descuentos</p>\n           </div>\n         </ion-col>\n         <ion-col size=\"6\">\n           <div class=\"wrapper\">\n             <img src=\"assets/imgs/h-5.png\" alt=\"\">\n             <p>Doctor en línea</p>\n           </div>\n         </ion-col>\n         <ion-col size=\"6\">\n           <div class=\"wrapper\">\n             <img src=\"assets/imgs/h-6.png\" alt=\"\">\n             <p>Asistencias y seguros</p>\n           </div>\n         </ion-col>\n         <ion-col size=\"6\">\n           <div class=\"wrapper\">\n             <span class=\"tag\">2</span>\n             <img src=\"assets/imgs/h-7.png\" alt=\"\">\n             <p>Comunicación</p>\n           </div>\n         </ion-col>\n         <ion-col size=\"6\">\n           <div class=\"wrapper\">\n             <span class=\"tag\">1</span>\n             <img src=\"assets/imgs/h-8.png\" alt=\"\">\n             <p>Encuestas</p>\n           </div>\n         </ion-col>\n         <ion-col size=\"6\">\n           <div class=\"wrapper\">\n             <img src=\"assets/imgs/h-9.png\" alt=\"\">\n             <p>Voz del empleado</p>\n           </div>\n         </ion-col>\n         <ion-col size=\"6\">\n           <div class=\"wrapper\">\n             <img src=\"assets/imgs/h-10.png\" alt=\"\">\n             <p>Reconoce a tu equipo</p>\n           </div>\n         </ion-col>\n       </ion-row>\n     </div>\n   </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/home/home-routing.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/home/home-routing.module.ts ***!
    \*********************************************/

  /*! exports provided: HomePageRoutingModule */

  /***/
  function srcAppHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
      return HomePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./home.page */
    "./src/app/home/home.page.ts");

    var routes = [{
      path: '',
      component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
    }];

    var HomePageRoutingModule = function HomePageRoutingModule() {
      _classCallCheck(this, HomePageRoutingModule);
    };

    HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], HomePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/home/home.module.ts":
  /*!*************************************!*\
    !*** ./src/app/home/home.module.ts ***!
    \*************************************/

  /*! exports provided: HomePageModule */

  /***/
  function srcAppHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
      return HomePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _home_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./home.page */
    "./src/app/home/home.page.ts");
    /* harmony import */


    var _home_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./home-routing.module */
    "./src/app/home/home-routing.module.ts");

    var HomePageModule = function HomePageModule() {
      _classCallCheck(this, HomePageModule);
    };

    HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_6__["HomePageRoutingModule"]],
      declarations: [_home_page__WEBPACK_IMPORTED_MODULE_5__["HomePage"]]
    })], HomePageModule);
    /***/
  },

  /***/
  "./src/app/home/home.page.scss":
  /*!*************************************!*\
    !*** ./src/app/home/home.page.scss ***!
    \*************************************/

  /*! exports provided: default */

  /***/
  function srcAppHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n\n.ion-padding .top-image {\n  text-align: center;\n}\n\n.ion-padding .top-image img {\n  margin: 12px 0 0;\n}\n\n.ion-padding .block-category {\n  padding-top: 10px;\n}\n\n.ion-padding .block-category .wrapper {\n  background: #fff;\n  text-align: center;\n  border-radius: 20px;\n  padding: 7px;\n  height: 150px;\n  position: relative;\n  box-shadow: 0 7px 12px -7px rgba(0, 0, 0, 0.4);\n}\n\n.ion-padding .block-category .wrapper .tag {\n  position: absolute;\n  right: 0;\n  width: 30px;\n  height: 30px;\n  background: #fb4f33;\n  color: #fff;\n  font-size: 14px;\n  line-height: 30px;\n  border-radius: 50%;\n  top: 0;\n}\n\n.ion-padding .block-category .wrapper img {\n  width: 90px;\n}\n\n.ion-padding .block-category .wrapper p {\n  margin-bottom: 4px;\n  margin-top: 0;\n  font-weight: 700;\n  color: #1f1f1f;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXGhvbWVcXGhvbWUucGFnZS5zY3NzIiwic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNETjs7QURNRTtFQUNFLGtCQUFBO0FDSEo7O0FESUk7RUFDRSxnQkFBQTtBQ0ZOOztBREtFO0VBQ0UsaUJBQUE7QUNISjs7QURJSTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSw4Q0FBQTtBQ0ZOOztBREdNO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLE1BQUE7QUNEUjs7QURHTTtFQUNFLFdBQUE7QUNEUjs7QURHTTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQ0RSIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xuICAuYnRuLXJpZ2h0IHtcbiAgICAuYWxlcnQtdGFnIHtcbiAgICAgIHdpZHRoOiAxMnB4O1xuICAgICAgaGVpZ2h0OiAxMnB4O1xuICAgICAgYmFja2dyb3VuZDogI2ZiNGYzMztcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgcmlnaHQ6IC0zcHg7XG4gICAgICBib3R0b206IC0ycHg7XG4gICAgfVxuICB9XG59XG4uaW9uLXBhZGRpbmcge1xuICAudG9wLWltYWdlIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgaW1nIHtcbiAgICAgIG1hcmdpbjogMTJweCAwIDA7XG4gICAgfVxuICB9XG4gIC5ibG9jay1jYXRlZ29yeSB7XG4gICAgcGFkZGluZy10b3A6IDEwcHg7XG4gICAgLndyYXBwZXIge1xuICAgICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gICAgICBwYWRkaW5nOiA3cHg7XG4gICAgICBoZWlnaHQ6IDE1MHB4O1xuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgYm94LXNoYWRvdzogMCA3cHggMTJweCAtN3B4IHJnYmEoMCwgMCwgMCwgMC40KTtcbiAgICAgIC50YWcge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHJpZ2h0OiAwO1xuICAgICAgICB3aWR0aDogMzBweDtcbiAgICAgICAgaGVpZ2h0OiAzMHB4O1xuICAgICAgICBiYWNrZ3JvdW5kOiAjZmI0ZjMzO1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgICBsaW5lLWhlaWdodDogMzBweDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICB0b3A6IDA7XG4gICAgICB9XG4gICAgICBpbWcge1xuICAgICAgICB3aWR0aDogOTBweDtcbiAgICAgIH1cbiAgICAgIHAge1xuICAgICAgICBtYXJnaW4tYm90dG9tOiA0cHg7XG4gICAgICAgIG1hcmdpbi10b3A6IDA7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgICAgIGNvbG9yOiAjMWYxZjFmO1xuICAgICAgfVxuICAgIH1cbiAgfVxufSIsImlvbi1oZWFkZXIgLmJ0bi1yaWdodCAuYWxlcnQtdGFnIHtcbiAgd2lkdGg6IDEycHg7XG4gIGhlaWdodDogMTJweDtcbiAgYmFja2dyb3VuZDogI2ZiNGYzMztcbiAgZGlzcGxheTogYmxvY2s7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogLTNweDtcbiAgYm90dG9tOiAtMnB4O1xufVxuXG4uaW9uLXBhZGRpbmcgLnRvcC1pbWFnZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5pb24tcGFkZGluZyAudG9wLWltYWdlIGltZyB7XG4gIG1hcmdpbjogMTJweCAwIDA7XG59XG4uaW9uLXBhZGRpbmcgLmJsb2NrLWNhdGVnb3J5IHtcbiAgcGFkZGluZy10b3A6IDEwcHg7XG59XG4uaW9uLXBhZGRpbmcgLmJsb2NrLWNhdGVnb3J5IC53cmFwcGVyIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICBwYWRkaW5nOiA3cHg7XG4gIGhlaWdodDogMTUwcHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgYm94LXNoYWRvdzogMCA3cHggMTJweCAtN3B4IHJnYmEoMCwgMCwgMCwgMC40KTtcbn1cbi5pb24tcGFkZGluZyAuYmxvY2stY2F0ZWdvcnkgLndyYXBwZXIgLnRhZyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDA7XG4gIHdpZHRoOiAzMHB4O1xuICBoZWlnaHQ6IDMwcHg7XG4gIGJhY2tncm91bmQ6ICNmYjRmMzM7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHRvcDogMDtcbn1cbi5pb24tcGFkZGluZyAuYmxvY2stY2F0ZWdvcnkgLndyYXBwZXIgaW1nIHtcbiAgd2lkdGg6IDkwcHg7XG59XG4uaW9uLXBhZGRpbmcgLmJsb2NrLWNhdGVnb3J5IC53cmFwcGVyIHAge1xuICBtYXJnaW4tYm90dG9tOiA0cHg7XG4gIG1hcmdpbi10b3A6IDA7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIGNvbG9yOiAjMWYxZjFmO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/home/home.page.ts":
  /*!***********************************!*\
    !*** ./src/app/home/home.page.ts ***!
    \***********************************/

  /*! exports provided: HomePage */

  /***/
  function srcAppHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePage", function () {
      return HomePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var HomePage = /*#__PURE__*/function () {
      function HomePage(router) {
        _classCallCheck(this, HomePage);

        this.router = router;
      }

      _createClass(HomePage, [{
        key: "PageRoute",
        value: function PageRoute(urlSlug) {
          this.router.navigateByUrl('/' + urlSlug);
        }
      }]);

      return HomePage;
    }();

    HomePage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }];
    };

    HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-home',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./home.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./home.page.scss */
      "./src/app/home/home.page.scss"))["default"]]
    })], HomePage);
    /***/
  }
}]);
//# sourceMappingURL=home-home-module-es5.js.map