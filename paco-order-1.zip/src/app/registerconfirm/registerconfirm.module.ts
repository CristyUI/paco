import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RegisterconfirmPageRoutingModule } from './registerconfirm-routing.module';

import { RegisterconfirmPage } from './registerconfirm.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RegisterconfirmPageRoutingModule
  ],
  declarations: [RegisterconfirmPage]
})
export class RegisterconfirmPageModule {}
