import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PincreatePageRoutingModule } from './pincreate-routing.module';

import { PincreatePage } from './pincreate.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PincreatePageRoutingModule
  ],
  declarations: [PincreatePage]
})
export class PincreatePageModule {}
