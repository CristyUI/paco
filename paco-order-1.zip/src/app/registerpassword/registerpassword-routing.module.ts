import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegisterpasswordPage } from './registerpassword.page';

const routes: Routes = [
  {
    path: '',
    component: RegisterpasswordPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RegisterpasswordPageRoutingModule {}
