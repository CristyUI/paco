import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-registerpassword',
  templateUrl: './registerpassword.page.html',
  styleUrls: ['./registerpassword.page.scss'],
})
export class RegisterpasswordPage implements OnInit {
  public type = 'password';
  public showPass = false;
  constructor(public router: Router, public menuCtrl: MenuController) { }
    public isToggled: boolean = false;
    active: boolean = true;
  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    showPassword() {
        this.showPass = !this.showPass;
        if (this.showPass) {
            this.type = 'text';
        } else {
            this.type = 'password';
        }
    }
    changeEvent(event) {
        console.log(this.isToggled);
        this.isToggled = !this.isToggled;
        this.active = !this.active;
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
}
