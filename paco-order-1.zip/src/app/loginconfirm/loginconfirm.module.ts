import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LoginconfirmPageRoutingModule } from './loginconfirm-routing.module';

import { LoginconfirmPage } from './loginconfirm.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LoginconfirmPageRoutingModule
  ],
  declarations: [LoginconfirmPage]
})
export class LoginconfirmPageModule {}
