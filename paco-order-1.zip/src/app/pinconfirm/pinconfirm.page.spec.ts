import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { PinconfirmPage } from './pinconfirm.page';

describe('PinconfirmPage', () => {
  let component: PinconfirmPage;
  let fixture: ComponentFixture<PinconfirmPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PinconfirmPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(PinconfirmPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
