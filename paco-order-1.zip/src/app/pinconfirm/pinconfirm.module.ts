import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PinconfirmPageRoutingModule } from './pinconfirm-routing.module';

import { PinconfirmPage } from './pinconfirm.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PinconfirmPageRoutingModule
  ],
  declarations: [PinconfirmPage]
})
export class PinconfirmPageModule {}
