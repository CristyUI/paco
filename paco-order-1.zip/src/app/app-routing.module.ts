import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'loginconfirm',
    loadChildren: () => import('./loginconfirm/loginconfirm.module').then( m => m.LoginconfirmPageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'registerconfirm',
    loadChildren: () => import('./registerconfirm/registerconfirm.module').then( m => m.RegisterconfirmPageModule)
  },
  {
    path: 'registerpassword',
    loadChildren: () => import('./registerpassword/registerpassword.module').then( m => m.RegisterpasswordPageModule)
  },
  {
    path: 'termscondition',
    loadChildren: () => import('./termscondition/termscondition.module').then( m => m.TermsconditionPageModule)
  },
  {
    path: 'pincreate',
    loadChildren: () => import('./pincreate/pincreate.module').then( m => m.PincreatePageModule)
  },
  {
    path: 'pinconfirm',
    loadChildren: () => import('./pinconfirm/pinconfirm.module').then( m => m.PinconfirmPageModule)
  },
  {
    path: 'onboardslider',
    loadChildren: () => import('./onboardslider/onboardslider.module').then( m => m.OnboardsliderPageModule)
  },
  {
    path: 'pagodemain',
    loadChildren: () => import('./pagodeservicio/pagodemain/pagodemain.module').then( m => m.PagodemainPageModule)
  },
  {
    path: 'pagotelevision',
    loadChildren: () => import('./pagodeservicio/pagotelevision/pagotelevision.module').then( m => m.PagotelevisionPageModule)
  },
  {
    path: 'telmex',
    loadChildren: () => import('./pagodeservicio/telmex/telmex.module').then( m => m.TelmexPageModule)
  },
  {
    path: 'telmexconfirm',
    loadChildren: () => import('./pagodeservicio/telmexconfirm/telmexconfirm.module').then( m => m.TelmexconfirmPageModule)
  },
  {
    path: 'comprobante',
    loadChildren: () => import('./pagodeservicio/comprobante/comprobante.module').then( m => m.ComprobantePageModule)
  },
  {
    path: 'messagenotify',
    loadChildren: () => import('./pagodeservicio/messagenotify/messagenotify.module').then( m => m.MessagenotifyPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
