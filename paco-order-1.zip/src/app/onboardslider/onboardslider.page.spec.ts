import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { OnboardsliderPage } from './onboardslider.page';

describe('OnboardsliderPage', () => {
  let component: OnboardsliderPage;
  let fixture: ComponentFixture<OnboardsliderPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardsliderPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(OnboardsliderPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
