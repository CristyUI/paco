import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-onboardslider',
  templateUrl: './onboardslider.page.html',
  styleUrls: ['./onboardslider.page.scss'],
})
export class OnboardsliderPage implements OnInit {
    slideboard = {
        initialSlide: 0,
        speed: 800,
        autoplay: false,
        slidesPerView: 1,
        spaceBetween: 2,
        cssClass: 'board-slider',
    };
  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
}
