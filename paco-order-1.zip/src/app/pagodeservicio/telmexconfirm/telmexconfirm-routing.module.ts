import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TelmexconfirmPage } from './telmexconfirm.page';

const routes: Routes = [
  {
    path: '',
    component: TelmexconfirmPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TelmexconfirmPageRoutingModule {}
