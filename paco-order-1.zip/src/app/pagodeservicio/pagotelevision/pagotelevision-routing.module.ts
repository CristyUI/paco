import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PagotelevisionPage } from './pagotelevision.page';

const routes: Routes = [
  {
    path: '',
    component: PagotelevisionPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PagotelevisionPageRoutingModule {}
