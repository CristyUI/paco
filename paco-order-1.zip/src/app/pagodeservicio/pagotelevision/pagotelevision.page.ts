import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-pagotelevision',
  templateUrl: './pagotelevision.page.html',
  styleUrls: ['./pagotelevision.page.scss'],
})
export class PagotelevisionPage implements OnInit {
    public tab1: boolean = true;
    public tab2: boolean = false;
    public tab3: boolean = true;
    public tab4: boolean = false;
    catList = false;
    catGrid = true;
  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    showlist() {
        this.catList = true;
        this.catGrid = false;
        this.tab1 = false;
        this.tab2 = true;
        this.tab3 = false;
        this.tab4 = true;
    }
    showgrid() {
        this.catGrid = true;
        this.catList = false;
        this.tab3 = true;
        this.tab4 = false;
        this.tab1 = true;
        this.tab2 = false;
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
}
