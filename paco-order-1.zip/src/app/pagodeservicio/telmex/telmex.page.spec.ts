import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { TelmexPage } from './telmex.page';

describe('TelmexPage', () => {
  let component: TelmexPage;
  let fixture: ComponentFixture<TelmexPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TelmexPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(TelmexPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
