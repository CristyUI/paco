import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-telmex',
  templateUrl: './telmex.page.html',
  styleUrls: ['./telmex.page.scss'],
})
export class TelmexPage implements OnInit {
    linkWrap = false;
    receiptContent = false;
    receiptCamera = true;
    btn1 = true;
    btn2 = false;
    closeIc = false;
  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    showreceipt() {
        this.receiptContent = true;
        this.receiptCamera = false;
        this.btn1 = false;
        this.btn2 = true;
    }
    closereceipt() {
        this.receiptContent = false;
        this.receiptCamera = true;
        this.btn1 = true;
        this.btn2 = false;
    }
    viewRef() {
        this.linkWrap = true;
        this.closeIc = true;
    }
    closeRef() {
        this.linkWrap = false;
        this.closeIc = false;
    }
    telmexconfirm() {
        this.router.navigateByUrl('/telmexconfirm');
    }
}
