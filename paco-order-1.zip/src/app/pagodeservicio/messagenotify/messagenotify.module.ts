import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MessagenotifyPageRoutingModule } from './messagenotify-routing.module';

import { MessagenotifyPage } from './messagenotify.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MessagenotifyPageRoutingModule
  ],
  declarations: [MessagenotifyPage]
})
export class MessagenotifyPageModule {}
