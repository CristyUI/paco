import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-termscondition',
  templateUrl: './termscondition.page.html',
  styleUrls: ['./termscondition.page.scss'],
})
export class TermsconditionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
