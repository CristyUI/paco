import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TelmexPage } from './telmex.page';

const routes: Routes = [
  {
    path: '',
    component: TelmexPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TelmexPageRoutingModule {}
