import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-pagodemain',
  templateUrl: './pagodemain.page.html',
  styleUrls: ['./pagodemain.page.scss'],
})
export class PagodemainPage implements OnInit {
    slidecat = {
        initialSlide: 0,
        speed: 400,
        slidesPerView: 5,
        spaceBetween: 0,
    };
  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
}
