import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PagotelevisionPageRoutingModule } from './pagotelevision-routing.module';

import { PagotelevisionPage } from './pagotelevision.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PagotelevisionPageRoutingModule
  ],
  declarations: [PagotelevisionPage]
})
export class PagotelevisionPageModule {}
