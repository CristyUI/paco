import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { PagotelevisionPage } from './pagotelevision.page';

describe('PagotelevisionPage', () => {
  let component: PagotelevisionPage;
  let fixture: ComponentFixture<PagotelevisionPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagotelevisionPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(PagotelevisionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
