import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EncunhayPageRoutingModule } from './encunhay-routing.module';

import { EncunhayPage } from './encunhay.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EncunhayPageRoutingModule
  ],
  declarations: [EncunhayPage]
})
export class EncunhayPageModule {}
