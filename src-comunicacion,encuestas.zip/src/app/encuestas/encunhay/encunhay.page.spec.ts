import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { EncunhayPage } from './encunhay.page';

describe('EncunhayPage', () => {
  let component: EncunhayPage;
  let fixture: ComponentFixture<EncunhayPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EncunhayPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(EncunhayPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
