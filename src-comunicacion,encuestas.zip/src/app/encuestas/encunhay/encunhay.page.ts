import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-encunhay',
  templateUrl: './encunhay.page.html',
  styleUrls: ['./encunhay.page.scss'],
})
export class EncunhayPage implements OnInit {

  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    encumain() {
        this.router.navigateByUrl('/encumain');
    }
}
