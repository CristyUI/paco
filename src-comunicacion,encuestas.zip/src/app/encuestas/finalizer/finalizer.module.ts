import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FinalizerPageRoutingModule } from './finalizer-routing.module';

import { FinalizerPage } from './finalizer.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FinalizerPageRoutingModule
  ],
  declarations: [FinalizerPage]
})
export class FinalizerPageModule {}
