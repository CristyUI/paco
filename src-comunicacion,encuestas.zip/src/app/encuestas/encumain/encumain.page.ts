import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-encumain',
  templateUrl: './encumain.page.html',
  styleUrls: ['./encumain.page.scss'],
})
export class EncumainPage implements OnInit {
    public BtnClick: boolean = false;
    public BtnClick2: boolean = false;
  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
    public showHide() {
        this.BtnClick = !this.BtnClick;
    }
    public showHide2() {
        this.BtnClick2 = !this.BtnClick2;
    }
}
