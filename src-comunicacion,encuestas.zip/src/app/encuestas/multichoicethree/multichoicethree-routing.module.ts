import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MultichoicethreePage } from './multichoicethree.page';

const routes: Routes = [
  {
    path: '',
    component: MultichoicethreePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MultichoicethreePageRoutingModule {}
