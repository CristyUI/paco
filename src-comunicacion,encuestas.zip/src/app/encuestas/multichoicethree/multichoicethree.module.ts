import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MultichoicethreePageRoutingModule } from './multichoicethree-routing.module';

import { MultichoicethreePage } from './multichoicethree.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MultichoicethreePageRoutingModule
  ],
  declarations: [MultichoicethreePage]
})
export class MultichoicethreePageModule {}
