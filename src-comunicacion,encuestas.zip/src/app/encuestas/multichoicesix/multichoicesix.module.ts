import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MultichoicesixPageRoutingModule } from './multichoicesix-routing.module';

import { MultichoicesixPage } from './multichoicesix.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MultichoicesixPageRoutingModule
  ],
  declarations: [MultichoicesixPage]
})
export class MultichoicesixPageModule {}
