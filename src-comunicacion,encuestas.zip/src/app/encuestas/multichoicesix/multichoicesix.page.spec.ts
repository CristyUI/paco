import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MultichoicesixPage } from './multichoicesix.page';

describe('MultichoicesixPage', () => {
  let component: MultichoicesixPage;
  let fixture: ComponentFixture<MultichoicesixPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultichoicesixPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MultichoicesixPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
