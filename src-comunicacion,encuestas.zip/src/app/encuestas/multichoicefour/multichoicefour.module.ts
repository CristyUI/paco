import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MultichoicefourPageRoutingModule } from './multichoicefour-routing.module';

import { MultichoicefourPage } from './multichoicefour.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MultichoicefourPageRoutingModule
  ],
  declarations: [MultichoicefourPage]
})
export class MultichoicefourPageModule {}
