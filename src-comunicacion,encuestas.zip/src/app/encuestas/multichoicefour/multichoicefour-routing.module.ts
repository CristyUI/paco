import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MultichoicefourPage } from './multichoicefour.page';

const routes: Routes = [
  {
    path: '',
    component: MultichoicefourPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MultichoicefourPageRoutingModule {}
