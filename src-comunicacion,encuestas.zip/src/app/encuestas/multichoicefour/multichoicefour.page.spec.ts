import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MultichoicefourPage } from './multichoicefour.page';

describe('MultichoicefourPage', () => {
  let component: MultichoicefourPage;
  let fixture: ComponentFixture<MultichoicefourPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultichoicefourPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MultichoicefourPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
