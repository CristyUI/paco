import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MultichoicefivePage } from './multichoicefive.page';

describe('MultichoicefivePage', () => {
  let component: MultichoicefivePage;
  let fixture: ComponentFixture<MultichoicefivePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultichoicefivePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MultichoicefivePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
