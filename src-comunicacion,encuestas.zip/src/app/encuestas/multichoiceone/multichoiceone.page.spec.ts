import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MultichoiceonePage } from './multichoiceone.page';

describe('MultichoiceonePage', () => {
  let component: MultichoiceonePage;
  let fixture: ComponentFixture<MultichoiceonePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultichoiceonePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MultichoiceonePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
