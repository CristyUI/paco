import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { OnboardsliderPageRoutingModule } from './onboardslider-routing.module';

import { OnboardsliderPage } from './onboardslider.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    OnboardsliderPageRoutingModule
  ],
  declarations: [OnboardsliderPage]
})
export class OnboardsliderPageModule {}
