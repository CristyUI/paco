import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-loginconfirm',
  templateUrl: './loginconfirm.page.html',
  styleUrls: ['./loginconfirm.page.scss'],
})
export class LoginconfirmPage implements OnInit {

  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
  ionViewWillEnter() {
     this.menuCtrl.enable(false);
  }
  ionViewDidLeave() {
     this.menuCtrl.enable(true);
  }
  PageRoute(urlSlug: string) {
    this.router.navigateByUrl('/' + urlSlug);
  }
}
