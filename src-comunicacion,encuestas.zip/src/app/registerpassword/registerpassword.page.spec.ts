import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { RegisterpasswordPage } from './registerpassword.page';

describe('RegisterpasswordPage', () => {
  let component: RegisterpasswordPage;
  let fixture: ComponentFixture<RegisterpasswordPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterpasswordPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(RegisterpasswordPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
