import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RegisterpasswordPageRoutingModule } from './registerpassword-routing.module';

import { RegisterpasswordPage } from './registerpassword.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RegisterpasswordPageRoutingModule
  ],
  declarations: [RegisterpasswordPage]
})
export class RegisterpasswordPageModule {}
