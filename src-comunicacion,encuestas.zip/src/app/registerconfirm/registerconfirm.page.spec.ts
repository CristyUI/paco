import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { RegisterconfirmPage } from './registerconfirm.page';

describe('RegisterconfirmPage', () => {
  let component: RegisterconfirmPage;
  let fixture: ComponentFixture<RegisterconfirmPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterconfirmPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(RegisterconfirmPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
