import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'loginconfirm',
    loadChildren: () => import('./loginconfirm/loginconfirm.module').then( m => m.LoginconfirmPageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'registerconfirm',
    loadChildren: () => import('./registerconfirm/registerconfirm.module').then( m => m.RegisterconfirmPageModule)
  },
  {
    path: 'registerpassword',
    loadChildren: () => import('./registerpassword/registerpassword.module').then( m => m.RegisterpasswordPageModule)
  },
  {
    path: 'termscondition',
    loadChildren: () => import('./termscondition/termscondition.module').then( m => m.TermsconditionPageModule)
  },
  {
    path: 'pincreate',
    loadChildren: () => import('./pincreate/pincreate.module').then( m => m.PincreatePageModule)
  },
  {
    path: 'pinconfirm',
    loadChildren: () => import('./pinconfirm/pinconfirm.module').then( m => m.PinconfirmPageModule)
  },
  {
    path: 'onboardslider',
    loadChildren: () => import('./onboardslider/onboardslider.module').then( m => m.OnboardsliderPageModule)
  },
  {
    path: 'pagodemain',
    loadChildren: () => import('./pagodeservicio/pagodemain/pagodemain.module').then( m => m.PagodemainPageModule)
  },
  {
    path: 'pagotelevision',
    loadChildren: () => import('./pagodeservicio/pagotelevision/pagotelevision.module').then( m => m.PagotelevisionPageModule)
  },
  {
    path: 'telmex',
    loadChildren: () => import('./pagodeservicio/telmex/telmex.module').then( m => m.TelmexPageModule)
  },
  {
    path: 'telmexconfirm',
    loadChildren: () => import('./pagodeservicio/telmexconfirm/telmexconfirm.module').then( m => m.TelmexconfirmPageModule)
  },
  {
    path: 'comprobante',
    loadChildren: () => import('./pagodeservicio/comprobante/comprobante.module').then( m => m.ComprobantePageModule)
  },
  {
    path: 'messagenotify',
    loadChildren: () => import('./pagodeservicio/messagenotify/messagenotify.module').then( m => m.MessagenotifyPageModule)
  },
  {
    path: 'communication',
    loadChildren: () => import('./comunicacion/communication/communication.module').then( m => m.CommunicationPageModule)
  },
  {
    path: 'search',
    loadChildren: () => import('./search/search.module').then( m => m.SearchPageModule)
  },
  {
    path: 'mensaje',
    loadChildren: () => import('./comunicacion/mensaje/mensaje.module').then( m => m.MensajePageModule)
  },
  {
    path: 'encunhay',
    loadChildren: () => import('./encuestas/encunhay/encunhay.module').then( m => m.EncunhayPageModule)
  },
  {
    path: 'encumain',
    loadChildren: () => import('./encuestas/encumain/encumain.module').then( m => m.EncumainPageModule)
  },
  {
    path: 'bienvenida',
    loadChildren: () => import('./encuestas/bienvenida/bienvenida.module').then( m => m.BienvenidaPageModule)
  },
  {
    path: 'multichoiceone',
    loadChildren: () => import('./encuestas/multichoiceone/multichoiceone.module').then( m => m.MultichoiceonePageModule)
  },
  {
    path: 'multichoicetwo',
    loadChildren: () => import('./encuestas/multichoicetwo/multichoicetwo.module').then( m => m.MultichoicetwoPageModule)
  },
  {
    path: 'multichoicethree',
    loadChildren: () => import('./encuestas/multichoicethree/multichoicethree.module').then( m => m.MultichoicethreePageModule)
  },
  {
    path: 'multichoicefour',
    loadChildren: () => import('./encuestas/multichoicefour/multichoicefour.module').then( m => m.MultichoicefourPageModule)
  },
  {
    path: 'multichoicefive',
    loadChildren: () => import('./encuestas/multichoicefive/multichoicefive.module').then( m => m.MultichoicefivePageModule)
  },
  {
    path: 'multichoicesix',
    loadChildren: () => import('./encuestas/multichoicesix/multichoicesix.module').then( m => m.MultichoicesixPageModule)
  },
  {
    path: 'finalizer',
    loadChildren: () => import('./encuestas/finalizer/finalizer.module').then( m => m.FinalizerPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
