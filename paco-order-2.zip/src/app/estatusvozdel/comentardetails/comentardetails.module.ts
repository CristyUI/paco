import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ComentardetailsPageRoutingModule } from './comentardetails-routing.module';

import { ComentardetailsPage } from './comentardetails.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ComentardetailsPageRoutingModule
  ],
  declarations: [ComentardetailsPage]
})
export class ComentardetailsPageModule {}
