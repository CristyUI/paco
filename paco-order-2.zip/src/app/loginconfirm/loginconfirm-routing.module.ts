import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginconfirmPage } from './loginconfirm.page';

const routes: Routes = [
  {
    path: '',
    component: LoginconfirmPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LoginconfirmPageRoutingModule {}
