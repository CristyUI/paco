import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { LoginconfirmPage } from './loginconfirm.page';

describe('LoginconfirmPage', () => {
  let component: LoginconfirmPage;
  let fixture: ComponentFixture<LoginconfirmPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginconfirmPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(LoginconfirmPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
