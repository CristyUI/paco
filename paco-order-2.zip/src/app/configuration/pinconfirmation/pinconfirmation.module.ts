import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PinconfirmationPageRoutingModule } from './pinconfirmation-routing.module';

import { PinconfirmationPage } from './pinconfirmation.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PinconfirmationPageRoutingModule
  ],
  declarations: [PinconfirmationPage]
})
export class PinconfirmationPageModule {}
