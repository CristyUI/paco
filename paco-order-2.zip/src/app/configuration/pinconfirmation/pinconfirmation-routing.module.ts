import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PinconfirmationPage } from './pinconfirmation.page';

const routes: Routes = [
  {
    path: '',
    component: PinconfirmationPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PinconfirmationPageRoutingModule {}
