import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ConfigmainPageRoutingModule } from './configmain-routing.module';

import { ConfigmainPage } from './configmain.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ConfigmainPageRoutingModule
  ],
  declarations: [ConfigmainPage]
})
export class ConfigmainPageModule {}
