import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ConfigmainPage } from './configmain.page';

const routes: Routes = [
  {
    path: '',
    component: ConfigmainPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ConfigmainPageRoutingModule {}
