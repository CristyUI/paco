import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PinnuevaPage } from './pinnueva.page';

const routes: Routes = [
  {
    path: '',
    component: PinnuevaPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PinnuevaPageRoutingModule {}
