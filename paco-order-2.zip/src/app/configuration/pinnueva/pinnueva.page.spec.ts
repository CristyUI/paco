import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { PinnuevaPage } from './pinnueva.page';

describe('PinnuevaPage', () => {
  let component: PinnuevaPage;
  let fixture: ComponentFixture<PinnuevaPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PinnuevaPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(PinnuevaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
