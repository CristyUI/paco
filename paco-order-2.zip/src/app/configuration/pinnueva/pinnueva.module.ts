import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PinnuevaPageRoutingModule } from './pinnueva-routing.module';

import { PinnuevaPage } from './pinnueva.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PinnuevaPageRoutingModule
  ],
  declarations: [PinnuevaPage]
})
export class PinnuevaPageModule {}
