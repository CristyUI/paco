import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ModificadoPage } from './modificado.page';

describe('ModificadoPage', () => {
  let component: ModificadoPage;
  let fixture: ComponentFixture<ModificadoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModificadoPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ModificadoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
