import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ModificadoPage } from './modificado.page';

const routes: Routes = [
  {
    path: '',
    component: ModificadoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ModificadoPageRoutingModule {}
