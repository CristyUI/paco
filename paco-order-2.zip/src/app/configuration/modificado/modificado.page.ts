import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-modificado',
  templateUrl: './modificado.page.html',
  styleUrls: ['./modificado.page.scss'],
})
export class ModificadoPage implements OnInit {

  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    home() {
        this.router.navigateByUrl('/home');
    }
}
