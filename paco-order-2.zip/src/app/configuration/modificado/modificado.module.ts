import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ModificadoPageRoutingModule } from './modificado-routing.module';

import { ModificadoPage } from './modificado.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ModificadoPageRoutingModule
  ],
  declarations: [ModificadoPage]
})
export class ModificadoPageModule {}
