import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PinactualPage } from './pinactual.page';

const routes: Routes = [
  {
    path: '',
    component: PinactualPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PinactualPageRoutingModule {}
