import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { PinactualPage } from './pinactual.page';

describe('PinactualPage', () => {
  let component: PinactualPage;
  let fixture: ComponentFixture<PinactualPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PinactualPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(PinactualPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
