import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PinactualPageRoutingModule } from './pinactual-routing.module';

import { PinactualPage } from './pinactual.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PinactualPageRoutingModule
  ],
  declarations: [PinactualPage]
})
export class PinactualPageModule {}
