import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-billinfo',
  templateUrl: './billinfo.page.html',
  styleUrls: ['./billinfo.page.scss'],
})
export class BillinfoPage implements OnInit {
    public type = 'password';
    public showPass = false;
  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
    showPassword() {
        this.showPass = !this.showPass;
        if (this.showPass) {
            this.type = 'text';
        } else {
            this.type = 'password';
        }
    }
}
