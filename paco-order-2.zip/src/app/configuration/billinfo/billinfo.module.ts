import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BillinfoPageRoutingModule } from './billinfo-routing.module';

import { BillinfoPage } from './billinfo.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BillinfoPageRoutingModule
  ],
  declarations: [BillinfoPage]
})
export class BillinfoPageModule {}
