import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BillinfoPage } from './billinfo.page';

const routes: Routes = [
  {
    path: '',
    component: BillinfoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BillinfoPageRoutingModule {}
