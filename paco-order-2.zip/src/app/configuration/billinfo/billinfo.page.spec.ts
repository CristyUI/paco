import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { BillinfoPage } from './billinfo.page';

describe('BillinfoPage', () => {
  let component: BillinfoPage;
  let fixture: ComponentFixture<BillinfoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillinfoPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(BillinfoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
