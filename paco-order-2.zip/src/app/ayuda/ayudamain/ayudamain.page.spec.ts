import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AyudamainPage } from './ayudamain.page';

describe('AyudamainPage', () => {
  let component: AyudamainPage;
  let fixture: ComponentFixture<AyudamainPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AyudamainPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AyudamainPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
