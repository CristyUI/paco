import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AyudamainPage } from './ayudamain.page';

const routes: Routes = [
  {
    path: '',
    component: AyudamainPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AyudamainPageRoutingModule {}
