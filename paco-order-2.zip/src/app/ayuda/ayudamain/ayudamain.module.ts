import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AyudamainPageRoutingModule } from './ayudamain-routing.module';

import { AyudamainPage } from './ayudamain.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AyudamainPageRoutingModule
  ],
  declarations: [AyudamainPage]
})
export class AyudamainPageModule {}
