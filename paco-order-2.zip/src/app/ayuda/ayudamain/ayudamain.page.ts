import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
    selector: 'app-ayudamain',
    templateUrl: './ayudamain.page.html',
    styleUrls: ['./ayudamain.page.scss'],
})
export class AyudamainPage implements OnInit {

    SelectedData: any = 'Pagos';

    public TabsData = [
        {
            name: 'Pagos',
        },
        {
            name: 'Seguros',
        },
        {
            name: 'Nominas',
        },
        {
            name: 'Descuentos',
        },
    ];
    constructor(public router: Router, public menuCtrl: MenuController) { }

    ngOnInit() {
    }
    tabsElement(tab){
        this.SelectedData = tab.name;
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }

}
