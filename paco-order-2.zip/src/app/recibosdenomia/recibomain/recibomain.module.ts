import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RecibomainPageRoutingModule } from './recibomain-routing.module';

import { RecibomainPage } from './recibomain.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RecibomainPageRoutingModule
  ],
  declarations: [RecibomainPage]
})
export class RecibomainPageModule {}
