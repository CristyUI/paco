import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { RecibomainPage } from './recibomain.page';

describe('RecibomainPage', () => {
  let component: RecibomainPage;
  let fixture: ComponentFixture<RecibomainPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecibomainPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(RecibomainPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
