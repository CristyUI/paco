import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RecibomainPage } from './recibomain.page';

const routes: Routes = [
  {
    path: '',
    component: RecibomainPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RecibomainPageRoutingModule {}
