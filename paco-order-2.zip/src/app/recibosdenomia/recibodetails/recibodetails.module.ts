import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RecibodetailsPageRoutingModule } from './recibodetails-routing.module';

import { RecibodetailsPage } from './recibodetails.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RecibodetailsPageRoutingModule
  ],
  declarations: [RecibodetailsPage]
})
export class RecibodetailsPageModule {}
