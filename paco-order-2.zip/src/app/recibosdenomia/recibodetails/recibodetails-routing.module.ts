import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RecibodetailsPage } from './recibodetails.page';

const routes: Routes = [
  {
    path: '',
    component: RecibodetailsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RecibodetailsPageRoutingModule {}
