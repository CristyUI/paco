import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CupoerrorPageRoutingModule } from './cupoerror-routing.module';

import { CupoerrorPage } from './cupoerror.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CupoerrorPageRoutingModule
  ],
  declarations: [CupoerrorPage]
})
export class CupoerrorPageModule {}
