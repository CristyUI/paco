import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { CupomainPage } from './cupomain.page';

describe('CupomainPage', () => {
  let component: CupomainPage;
  let fixture: ComponentFixture<CupomainPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CupomainPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(CupomainPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
