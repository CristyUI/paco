import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CupomainPageRoutingModule } from './cupomain-routing.module';

import { CupomainPage } from './cupomain.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CupomainPageRoutingModule
  ],
  declarations: [CupomainPage]
})
export class CupomainPageModule {}
