import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CupomainPage } from './cupomain.page';

const routes: Routes = [
  {
    path: '',
    component: CupomainPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CupomainPageRoutingModule {}
