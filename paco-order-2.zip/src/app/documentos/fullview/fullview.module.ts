import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FullviewPageRoutingModule } from './fullview-routing.module';

import { FullviewPage } from './fullview.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FullviewPageRoutingModule
  ],
  declarations: [FullviewPage]
})
export class FullviewPageModule {}
