import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
import {ActionSheetController} from '@ionic/angular';
@Component({
  selector: 'app-docview',
  templateUrl: './docview.page.html',
  styleUrls: ['./docview.page.scss'],
})
export class DocviewPage implements OnInit {
    public tab1: boolean = true;
    public tab2: boolean = false;
    public tab3: boolean = true;
    public tab4: boolean = false;
    catList = false;
    catGrid = true;
  constructor(public router: Router,
              public menuCtrl: MenuController,
              public actionSheetController: ActionSheetController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
    showlist() {
        this.catList = true;
        this.catGrid = false;
        this.tab1 = false;
        this.tab2 = true;
        this.tab3 = false;
        this.tab4 = true;
    }
    showgrid() {
        this.catGrid = true;
        this.catList = false;
        this.tab3 = true;
        this.tab4 = false;
        this.tab1 = true;
        this.tab2 = false;
    }
    async sortby() {
        const actionSheet = await this.actionSheetController.create({
            header: 'Sort By',
            mode: 'ios',
            buttons: [{
                text: 'Oldest',
                handler: () => {
                    console.log('Oldest clicked');
                }
            }, {
                text: 'Newest',
                handler: () => {
                    console.log('Newest clicked');
                }
            }, {
                text: 'Recently Viewed',
                handler: () => {
                    console.log('Recently Viewed clicked');
                }
            },
                {
                    text: 'Cancel',
                    role: 'cancel',
                    handler: () => {
                        console.log('Cancel clicked');
                    }
                }, ]
        });
        await actionSheet.present();
    }
}
