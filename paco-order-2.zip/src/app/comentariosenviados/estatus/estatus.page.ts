import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-estatus',
  templateUrl: './estatus.page.html',
  styleUrls: ['./estatus.page.scss'],
})
export class EstatusPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
