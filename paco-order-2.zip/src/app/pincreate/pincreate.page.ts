import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-pincreate',
  templateUrl: './pincreate.page.html',
  styleUrls: ['./pincreate.page.scss'],
})
export class PincreatePage implements OnInit {

  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    pinconfirm() {
        this.router.navigateByUrl('/pinconfirm');
    }
}
