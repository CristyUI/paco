import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { PincreatePage } from './pincreate.page';

describe('PincreatePage', () => {
  let component: PincreatePage;
  let fixture: ComponentFixture<PincreatePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PincreatePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(PincreatePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
