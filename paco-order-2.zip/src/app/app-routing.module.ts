import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'loginconfirm',
    loadChildren: () => import('./loginconfirm/loginconfirm.module').then( m => m.LoginconfirmPageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'registerconfirm',
    loadChildren: () => import('./registerconfirm/registerconfirm.module').then( m => m.RegisterconfirmPageModule)
  },
  {
    path: 'registerpassword',
    loadChildren: () => import('./registerpassword/registerpassword.module').then( m => m.RegisterpasswordPageModule)
  },
  {
    path: 'termscondition',
    loadChildren: () => import('./termscondition/termscondition.module').then( m => m.TermsconditionPageModule)
  },
  {
    path: 'pincreate',
    loadChildren: () => import('./pincreate/pincreate.module').then( m => m.PincreatePageModule)
  },
  {
    path: 'pinconfirm',
    loadChildren: () => import('./pinconfirm/pinconfirm.module').then( m => m.PinconfirmPageModule)
  },
  {
    path: 'onboardslider',
    loadChildren: () => import('./onboardslider/onboardslider.module').then( m => m.OnboardsliderPageModule)
  },
  {
    path: 'pagodemain',
    loadChildren: () => import('./pagodeservicio/pagodemain/pagodemain.module').then( m => m.PagodemainPageModule)
  },
  {
    path: 'pagotelevision',
    loadChildren: () => import('./pagodeservicio/pagotelevision/pagotelevision.module').then( m => m.PagotelevisionPageModule)
  },
  {
    path: 'telmex',
    loadChildren: () => import('./pagodeservicio/telmex/telmex.module').then( m => m.TelmexPageModule)
  },
  {
    path: 'telmexconfirm',
    loadChildren: () => import('./pagodeservicio/telmexconfirm/telmexconfirm.module').then( m => m.TelmexconfirmPageModule)
  },
  {
    path: 'comprobante',
    loadChildren: () => import('./pagodeservicio/comprobante/comprobante.module').then( m => m.ComprobantePageModule)
  },
  {
    path: 'messagenotify',
    loadChildren: () => import('./pagodeservicio/messagenotify/messagenotify.module').then( m => m.MessagenotifyPageModule)
  },
  {
    path: 'communication',
    loadChildren: () => import('./comunicacion/communication/communication.module').then( m => m.CommunicationPageModule)
  },
  {
    path: 'search',
    loadChildren: () => import('./search/search.module').then( m => m.SearchPageModule)
  },
  {
    path: 'mensaje',
    loadChildren: () => import('./comunicacion/mensaje/mensaje.module').then( m => m.MensajePageModule)
  },
  {
    path: 'encunhay',
    loadChildren: () => import('./encuestas/encunhay/encunhay.module').then( m => m.EncunhayPageModule)
  },
  {
    path: 'encumain',
    loadChildren: () => import('./encuestas/encumain/encumain.module').then( m => m.EncumainPageModule)
  },
  {
    path: 'bienvenida',
    loadChildren: () => import('./encuestas/bienvenida/bienvenida.module').then( m => m.BienvenidaPageModule)
  },
  {
    path: 'multichoiceone',
    loadChildren: () => import('./encuestas/multichoiceone/multichoiceone.module').then( m => m.MultichoiceonePageModule)
  },
  {
    path: 'multichoicetwo',
    loadChildren: () => import('./encuestas/multichoicetwo/multichoicetwo.module').then( m => m.MultichoicetwoPageModule)
  },
  {
    path: 'multichoicethree',
    loadChildren: () => import('./encuestas/multichoicethree/multichoicethree.module').then( m => m.MultichoicethreePageModule)
  },
  {
    path: 'multichoicefour',
    loadChildren: () => import('./encuestas/multichoicefour/multichoicefour.module').then( m => m.MultichoicefourPageModule)
  },
  {
    path: 'multichoicefive',
    loadChildren: () => import('./encuestas/multichoicefive/multichoicefive.module').then( m => m.MultichoicefivePageModule)
  },
  {
    path: 'multichoicesix',
    loadChildren: () => import('./encuestas/multichoicesix/multichoicesix.module').then( m => m.MultichoicesixPageModule)
  },
  {
    path: 'finalizer',
    loadChildren: () => import('./encuestas/finalizer/finalizer.module').then( m => m.FinalizerPageModule)
  },
  {
    path: 'vozdelmain',
    loadChildren: () => import('./vozdelempleado/vozdelmain/vozdelmain.module').then( m => m.VozdelmainPageModule)
  },
  {
    path: 'mensaja',
    loadChildren: () => import('./vozdelempleado/mensaja/mensaja.module').then( m => m.MensajaPageModule)
  },
  {
    path: 'reconomain',
    loadChildren: () => import('./reconoce/reconomain/reconomain.module').then( m => m.ReconomainPageModule)
  },
  {
    path: 'usuario',
    loadChildren: () => import('./reconoce/usuario/usuario.module').then( m => m.UsuarioPageModule)
  },
  {
    path: 'enviado',
    loadChildren: () => import('./reconoce/enviado/enviado.module').then( m => m.EnviadoPageModule)
  },
  {
    path: 'misremain',
    loadChildren: () => import('./misreconocimientos/misremain/misremain.module').then( m => m.MisremainPageModule)
  },
  {
    path: 'detalles',
    loadChildren: () => import('./misreconocimientos/detalles/detalles.module').then( m => m.DetallesPageModule)
  },
  {
    path: 'otorgado',
    loadChildren: () => import('./misreconocimientos/otorgado/otorgado.module').then( m => m.OtorgadoPageModule)
  },
  {
    path: 'configmain',
    loadChildren: () => import('./configuration/configmain/configmain.module').then( m => m.ConfigmainPageModule)
  },
  {
    path: 'billinfo',
    loadChildren: () => import('./configuration/billinfo/billinfo.module').then( m => m.BillinfoPageModule)
  },
  {
    path: 'cuentas',
    loadChildren: () => import('./configuration/cuentas/cuentas.module').then( m => m.CuentasPageModule)
  },
  {
    path: 'pinactual',
    loadChildren: () => import('./configuration/pinactual/pinactual.module').then( m => m.PinactualPageModule)
  },
  {
    path: 'pinnueva',
    loadChildren: () => import('./configuration/pinnueva/pinnueva.module').then( m => m.PinnuevaPageModule)
  },
  {
    path: 'modificado',
    loadChildren: () => import('./configuration/modificado/modificado.module').then( m => m.ModificadoPageModule)
  },
  {
    path: 'pinconfirmation',
    loadChildren: () => import('./configuration/pinconfirmation/pinconfirmation.module').then( m => m.PinconfirmationPageModule)
  },
  {
    path: 'estatus',
    loadChildren: () => import('./comentariosenviados/estatus/estatus.module').then( m => m.EstatusPageModule)
  },
  {
    path: 'docview',
    loadChildren: () => import('./documentos/docview/docview.module').then( m => m.DocviewPageModule)
  },
  {
    path: 'fullview',
    loadChildren: () => import('./documentos/fullview/fullview.module').then( m => m.FullviewPageModule)
  },
  {
    path: 'recibomain',
    loadChildren: () => import('./recibosdenomia/recibomain/recibomain.module').then( m => m.RecibomainPageModule)
  },
  {
    path: 'recibodetails',
    loadChildren: () => import('./recibosdenomia/recibodetails/recibodetails.module').then( m => m.RecibodetailsPageModule)
  },
  {
    path: 'comentarios',
    loadChildren: () => import('./estatusvozdel/comentarios/comentarios.module').then( m => m.ComentariosPageModule)
  },
  {
    path: 'comentardetails',
    loadChildren: () => import('./estatusvozdel/comentardetails/comentardetails.module').then( m => m.ComentardetailsPageModule)
  },
  {
    path: 'cupomain',
    loadChildren: () => import('./cupones/cupomain/cupomain.module').then( m => m.CupomainPageModule)
  },
  {
    path: 'cupoerror',
    loadChildren: () => import('./cupones/cupoerror/cupoerror.module').then( m => m.CupoerrorPageModule)
  },
  {
    path: 'servicios',
    loadChildren: () => import('./cupones/servicios/servicios.module').then( m => m.ServiciosPageModule)
  },
  {
    path: 'ayudamain',
    loadChildren: () => import('./ayuda/ayudamain/ayudamain.module').then( m => m.AyudamainPageModule)
  },
  {
    path: 'chartpie',
    loadChildren: () => import('./reportedegastos/chartpie/chartpie.module').then( m => m.ChartpiePageModule)
  },
  {
    path: 'chartstraight',
    loadChildren: () => import('./reportedegastos/chartstraight/chartstraight.module').then( m => m.ChartstraightPageModule)
  },
  {
    path: 'repcomprobante',
    loadChildren: () => import('./reportedegastos/repcomprobante/repcomprobante.module').then( m => m.RepcomprobantePageModule)
  },
  {
    path: 'editar',
    loadChildren: () => import('./configuration/editar/editar.module').then( m => m.EditarPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
