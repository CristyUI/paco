import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EncumainPage } from './encumain.page';

const routes: Routes = [
  {
    path: '',
    component: EncumainPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EncumainPageRoutingModule {}
