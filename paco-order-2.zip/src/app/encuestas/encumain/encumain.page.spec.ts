import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { EncumainPage } from './encumain.page';

describe('EncumainPage', () => {
  let component: EncumainPage;
  let fixture: ComponentFixture<EncumainPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EncumainPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(EncumainPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
