import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EncunhayPage } from './encunhay.page';

const routes: Routes = [
  {
    path: '',
    component: EncunhayPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EncunhayPageRoutingModule {}
