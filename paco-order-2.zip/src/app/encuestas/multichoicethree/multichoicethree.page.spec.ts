import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MultichoicethreePage } from './multichoicethree.page';

describe('MultichoicethreePage', () => {
  let component: MultichoicethreePage;
  let fixture: ComponentFixture<MultichoicethreePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultichoicethreePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MultichoicethreePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
