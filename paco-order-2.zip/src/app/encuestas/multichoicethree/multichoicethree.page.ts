import {Component, OnInit, ViewChild} from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
import {IonSlides} from '@ionic/angular';
@Component({
  selector: 'app-multichoicethree',
  templateUrl: './multichoicethree.page.html',
  styleUrls: ['./multichoicethree.page.scss'],
})
export class MultichoicethreePage implements OnInit {
    @ViewChild('slides') slides: IonSlides;
    public activeIndex: any;
  constructor(public router: Router, public menuCtrl: MenuController) { }
    slideOpts = {
        initialSlide: 5,
        speed: 800,
        autoplay: false,
        slidesPerView: 5,
        spaceBetween: 0,
    };
  ngOnInit() {
  }
    SlideChanges(slide: IonSlides) {
        slide.getActiveIndex().then((index: number) => {
            this.activeIndex = index + 3;
            console.log(this.activeIndex);
        });
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
}
