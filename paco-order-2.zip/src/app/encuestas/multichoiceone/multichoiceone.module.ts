import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MultichoiceonePageRoutingModule } from './multichoiceone-routing.module';

import { MultichoiceonePage } from './multichoiceone.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MultichoiceonePageRoutingModule
  ],
  declarations: [MultichoiceonePage]
})
export class MultichoiceonePageModule {}
