import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MultichoiceonePage } from './multichoiceone.page';

const routes: Routes = [
  {
    path: '',
    component: MultichoiceonePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MultichoiceonePageRoutingModule {}
