import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MultichoicetwoPageRoutingModule } from './multichoicetwo-routing.module';

import { MultichoicetwoPage } from './multichoicetwo.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MultichoicetwoPageRoutingModule
  ],
  declarations: [MultichoicetwoPage]
})
export class MultichoicetwoPageModule {}
