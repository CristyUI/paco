import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MultichoicetwoPage } from './multichoicetwo.page';

const routes: Routes = [
  {
    path: '',
    component: MultichoicetwoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MultichoicetwoPageRoutingModule {}
