import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MultichoicetwoPage } from './multichoicetwo.page';

describe('MultichoicetwoPage', () => {
  let component: MultichoicetwoPage;
  let fixture: ComponentFixture<MultichoicetwoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultichoicetwoPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MultichoicetwoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
