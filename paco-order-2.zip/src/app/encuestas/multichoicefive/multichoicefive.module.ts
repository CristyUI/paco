import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MultichoicefivePageRoutingModule } from './multichoicefive-routing.module';

import { MultichoicefivePage } from './multichoicefive.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MultichoicefivePageRoutingModule
  ],
  declarations: [MultichoicefivePage]
})
export class MultichoicefivePageModule {}
