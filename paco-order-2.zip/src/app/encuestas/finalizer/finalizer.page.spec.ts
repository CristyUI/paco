import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FinalizerPage } from './finalizer.page';

describe('FinalizerPage', () => {
  let component: FinalizerPage;
  let fixture: ComponentFixture<FinalizerPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinalizerPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FinalizerPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
