import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-multichoicefour',
  templateUrl: './multichoicefour.page.html',
  styleUrls: ['./multichoicefour.page.scss'],
})
export class MultichoicefourPage implements OnInit {
    public SelectedData : any;
  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
    radioGroupChange(event) {
        this.SelectedData = event.detail.value;
    }
}
