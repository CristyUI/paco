import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { OtorgadoPageRoutingModule } from './otorgado-routing.module';

import { OtorgadoPage } from './otorgado.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    OtorgadoPageRoutingModule
  ],
  declarations: [OtorgadoPage]
})
export class OtorgadoPageModule {}
