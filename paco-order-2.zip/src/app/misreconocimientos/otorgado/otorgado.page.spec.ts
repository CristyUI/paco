import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { OtorgadoPage } from './otorgado.page';

describe('OtorgadoPage', () => {
  let component: OtorgadoPage;
  let fixture: ComponentFixture<OtorgadoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtorgadoPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(OtorgadoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
