import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-otorgado',
  templateUrl: './otorgado.page.html',
  styleUrls: ['./otorgado.page.scss'],
})
export class OtorgadoPage implements OnInit {

  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
}
