import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
import {ActionSheetController} from '@ionic/angular';
@Component({
  selector: 'app-misremain',
  templateUrl: './misremain.page.html',
  styleUrls: ['./misremain.page.scss'],
})
export class MisremainPage implements OnInit {

  constructor(public router: Router,
              public menuCtrl: MenuController,
              public actionSheetController: ActionSheetController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
    async sortby() {
        const actionSheet = await this.actionSheetController.create({
            header: 'Sort By',
            mode: 'ios',
            buttons: [{
                text: 'Oldest',
                handler: () => {
                    console.log('Oldest clicked');
                }
            }, {
                text: 'Newest',
                handler: () => {
                    console.log('Newest clicked');
                }
            }, {
                text: 'Recently Viewed',
                handler: () => {
                    console.log('Recently Viewed clicked');
                }
            },
                {
                    text: 'Cancel',
                    role: 'cancel',
                    handler: () => {
                        console.log('Cancel clicked');
                    }
                }, ]
        });
        await actionSheet.present();
    }
}
