import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MisremainPageRoutingModule } from './misremain-routing.module';

import { MisremainPage } from './misremain.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MisremainPageRoutingModule
  ],
  declarations: [MisremainPage]
})
export class MisremainPageModule {}
