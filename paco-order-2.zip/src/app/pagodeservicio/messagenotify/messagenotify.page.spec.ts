import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MessagenotifyPage } from './messagenotify.page';

describe('MessagenotifyPage', () => {
  let component: MessagenotifyPage;
  let fixture: ComponentFixture<MessagenotifyPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MessagenotifyPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MessagenotifyPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
