import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { PagodemainPage } from './pagodemain.page';

describe('PagodemainPage', () => {
  let component: PagodemainPage;
  let fixture: ComponentFixture<PagodemainPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagodemainPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(PagodemainPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
