import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PagodemainPageRoutingModule } from './pagodemain-routing.module';

import { PagodemainPage } from './pagodemain.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PagodemainPageRoutingModule
  ],
  declarations: [PagodemainPage]
})
export class PagodemainPageModule {}
