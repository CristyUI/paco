import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TelmexPageRoutingModule } from './telmex-routing.module';

import { TelmexPage } from './telmex.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TelmexPageRoutingModule
  ],
  declarations: [TelmexPage]
})
export class TelmexPageModule {}
