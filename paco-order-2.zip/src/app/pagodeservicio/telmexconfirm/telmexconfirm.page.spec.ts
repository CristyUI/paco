import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { TelmexconfirmPage } from './telmexconfirm.page';

describe('TelmexconfirmPage', () => {
  let component: TelmexconfirmPage;
  let fixture: ComponentFixture<TelmexconfirmPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TelmexconfirmPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(TelmexconfirmPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
