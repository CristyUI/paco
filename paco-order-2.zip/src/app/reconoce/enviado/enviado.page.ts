import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-enviado',
  templateUrl: './enviado.page.html',
  styleUrls: ['./enviado.page.scss'],
})
export class EnviadoPage implements OnInit {
    list: any;
    selected: any;
  constructor(public router: Router, public menuCtrl: MenuController) {
      this.list = [
          {name: 'Danny L. Wells', designation: 'CFO | Management'},
          {name: 'Jacqueline R. Waxman', designation: 'CFO | Management'},
          {name: 'Danny L. Wells', designation: 'CFO | Management'},
          {name: 'Dan D. Kean', designation: 'RH'},
      ];
  }

  ngOnInit() {
  }
    select(item) {
        this.selected = item;
    }
    isActive(item) {
        return this.selected === item;
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    reconomain() {
        this.router.navigateByUrl('/reconomain');
    }
}
