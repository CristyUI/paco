import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
@Component({
  selector: 'app-reconomain',
  templateUrl: './reconomain.page.html',
  styleUrls: ['./reconomain.page.scss'],
})
export class ReconomainPage implements OnInit {
    slideOpts = {
        initialSlide: 5,
        speed: 800,
        autoplay: false,
        slidesPerView: 3,
        spaceBetween: 28,
    };
  constructor(public router: Router, public menuCtrl: MenuController) { }

  ngOnInit() {
  }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
}
