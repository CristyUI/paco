import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ReconomainPageRoutingModule } from './reconomain-routing.module';

import { ReconomainPage } from './reconomain.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReconomainPageRoutingModule
  ],
  declarations: [ReconomainPage]
})
export class ReconomainPageModule {}
