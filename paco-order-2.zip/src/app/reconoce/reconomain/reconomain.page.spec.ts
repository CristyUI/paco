import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ReconomainPage } from './reconomain.page';

describe('ReconomainPage', () => {
  let component: ReconomainPage;
  let fixture: ComponentFixture<ReconomainPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReconomainPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ReconomainPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
