import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
    public appPages = [
        {
            title: 'Servicios de Paco',
            url: '',
            image: 'assets/imgs/ic_1.png'
        },
        {
            title: 'Reportes de gastos',
            url: '/chartpie',
            image: 'assets/imgs/ic_2.png'
        },
        {
            title: 'Documentos corporativos',
            url: '/docview',
            image: 'assets/imgs/ic_3.png'
        },
        {
            title: 'Recibos de nómina',
            url: '/recibomain',
            image: 'assets/imgs/ic_4.png'
        },
        {
            title: 'Estatus voz del empleado',
            url: '/comentarios',
            image: 'assets/imgs/ic_5.png'
        },
        {
            title: 'Mis reconocimientos',
            url: '/misremain',
            image: 'assets/imgs/ic_6.png'
        },
        {
            title: 'Ayuda',
            url: '/ayudamain',
            image: 'assets/imgs/ic_7.png'
        },
        {
            title: 'Tengo un cupón',
            url: '/cupomain',
            image: 'assets/imgs/ic_8.png'
        },
        {
            title: 'Configuración',
            url: '/configmain',
            image: 'assets/imgs/ic_9.png'
        },
    ];
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
}
