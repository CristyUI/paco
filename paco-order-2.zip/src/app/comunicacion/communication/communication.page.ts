import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { MenuController } from '@ionic/angular';
import {ActionSheetController} from '@ionic/angular';
@Component({
  selector: 'app-communication',
  templateUrl: './communication.page.html',
  styleUrls: ['./communication.page.scss'],
})
export class CommunicationPage implements OnInit {
    public BtnClick: boolean = false;
    public BtnClick2: boolean = false;
  constructor(public router: Router,
              public menuCtrl: MenuController,
              public actionSheetController: ActionSheetController) { }

  ngOnInit() {
  }
    async sortby() {
        const actionSheet = await this.actionSheetController.create({
            header: 'Sort By',
            mode: 'ios',
            buttons: [{
                text: 'Oldest',
                handler: () => {
                    console.log('Oldest clicked');
                }
            }, {
                text: 'Newest',
                handler: () => {
                    console.log('Newest clicked');
                }
            }, {
                text: 'Recently Viewed',
                handler: () => {
                    console.log('Recently Viewed clicked');
                }
            },
                {
                    text: 'Cancel',
                    role: 'cancel',
                    handler: () => {
                        console.log('Cancel clicked');
                    }
                }, ]
        });
        await actionSheet.present();
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug: string) {
        this.router.navigateByUrl('/' + urlSlug);
    }
    public showHide() {
        this.BtnClick = !this.BtnClick;
    }
    public showHide2() {
        this.BtnClick2 = !this.BtnClick2;
    }
}
