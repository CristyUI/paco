(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["misreconocimientos-otorgado-otorgado-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/misreconocimientos/otorgado/otorgado.page.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/misreconocimientos/otorgado/otorgado.page.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Otorgado por</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"term-content\">\n    <img src=\"assets/imgs/misrecon/user.png\" alt=\"\">\n    <h5>Hannelore N. Underwood</h5>\n    <h6>hannelore@planetbiz.com</h6>\n    <p>Ayer 21231</p>\n    <p>Pharetra vulputate morbi eget dignissim nisi id arcu posuere ac. Mi et tincidunt massa sit vitae, vel feugiat.\n      Praesent viverra gravida non facilisi vestibulum.</p>\n    <div class=\"btn-wrap\">\n      <ion-button (click)=\"PageRoute('home')\">Finalizer</ion-button>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/misreconocimientos/otorgado/otorgado-routing.module.ts":
/*!************************************************************************!*\
  !*** ./src/app/misreconocimientos/otorgado/otorgado-routing.module.ts ***!
  \************************************************************************/
/*! exports provided: OtorgadoPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OtorgadoPageRoutingModule", function() { return OtorgadoPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _otorgado_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./otorgado.page */ "./src/app/misreconocimientos/otorgado/otorgado.page.ts");




const routes = [
    {
        path: '',
        component: _otorgado_page__WEBPACK_IMPORTED_MODULE_3__["OtorgadoPage"]
    }
];
let OtorgadoPageRoutingModule = class OtorgadoPageRoutingModule {
};
OtorgadoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], OtorgadoPageRoutingModule);



/***/ }),

/***/ "./src/app/misreconocimientos/otorgado/otorgado.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/misreconocimientos/otorgado/otorgado.module.ts ***!
  \****************************************************************/
/*! exports provided: OtorgadoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OtorgadoPageModule", function() { return OtorgadoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _otorgado_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./otorgado-routing.module */ "./src/app/misreconocimientos/otorgado/otorgado-routing.module.ts");
/* harmony import */ var _otorgado_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./otorgado.page */ "./src/app/misreconocimientos/otorgado/otorgado.page.ts");







let OtorgadoPageModule = class OtorgadoPageModule {
};
OtorgadoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _otorgado_routing_module__WEBPACK_IMPORTED_MODULE_5__["OtorgadoPageRoutingModule"]
        ],
        declarations: [_otorgado_page__WEBPACK_IMPORTED_MODULE_6__["OtorgadoPage"]]
    })
], OtorgadoPageModule);



/***/ }),

/***/ "./src/app/misreconocimientos/otorgado/otorgado.page.scss":
/*!****************************************************************!*\
  !*** ./src/app/misreconocimientos/otorgado/otorgado.page.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #5176f3;\n}\nion-content .term-content {\n  background: #fff;\n  padding: 20px 18px;\n  margin: 16px 20px 20px;\n  text-align: center;\n  border-radius: 20px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\nion-content .term-content img {\n  width: 100px;\n  margin: 0 0 20px;\n}\nion-content .term-content h5 {\n  font-size: 18px;\n  margin-top: 6px;\n  font-weight: 700;\n}\nion-content .term-content h6 {\n  color: #2c55e0;\n  margin: 0 0 23px;\n  font-weight: 100;\n  font-size: 15px;\n}\nion-content .term-content p {\n  margin-bottom: 4px;\n  text-align: left;\n  color: #737373;\n}\nion-content .term-content .btn-wrap {\n  margin-top: 10px;\n}\nion-content .term-content .btn-wrap ion-button {\n  width: 44% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWlzcmVjb25vY2ltaWVudG9zL290b3JnYWRvL0c6XFxpb25pY1xcRklWRVJSXFxwYW50YWxsYXMtcGFjby9zcmNcXGFwcFxcbWlzcmVjb25vY2ltaWVudG9zXFxvdG9yZ2Fkb1xcb3RvcmdhZG8ucGFnZS5zY3NzIiwic3JjL2FwcC9taXNyZWNvbm9jaW1pZW50b3Mvb3RvcmdhZG8vb3RvcmdhZG8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQUE7QUNDRjtBREFFO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLCtDQUFBO0FDRUo7QURESTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtBQ0dOO0FEREk7RUFDRSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDR047QURESTtFQUNFLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQ0dOO0FEREk7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQ0dOO0FEREk7RUFDRSxnQkFBQTtBQ0dOO0FERk07RUFDRSxxQkFBQTtBQ0lSIiwiZmlsZSI6InNyYy9hcHAvbWlzcmVjb25vY2ltaWVudG9zL290b3JnYWRvL290b3JnYWRvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XHJcbiAgLnRlcm0tY29udGVudCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgcGFkZGluZzogMjBweCAxOHB4O1xyXG4gICAgbWFyZ2luOiAxNnB4IDIwcHggMjBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcclxuICAgIGltZyB7XHJcbiAgICAgIHdpZHRoOiAxMDBweDtcclxuICAgICAgbWFyZ2luOiAwIDAgMjBweDtcclxuICAgIH1cclxuICAgIGg1IHtcclxuICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICBtYXJnaW4tdG9wOiA2cHg7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICB9XHJcbiAgICBoNiB7XHJcbiAgICAgIGNvbG9yOiAjMmM1NWUwO1xyXG4gICAgICBtYXJnaW46IDAgMCAyM3B4O1xyXG4gICAgICBmb250LXdlaWdodDogMTAwO1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICB9XHJcbiAgICBwIHtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG4gICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgICBjb2xvcjogIzczNzM3MztcclxuICAgIH1cclxuICAgIC5idG4td3JhcCB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgIHdpZHRoOiA0NCUhaW1wb3J0YW50O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59IiwiaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgcGFkZGluZzogMjBweCAxOHB4O1xuICBtYXJnaW46IDE2cHggMjBweCAyMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIGJveC1zaGFkb3c6IDAgN3B4IDE2cHggLTdweCByZ2JhKDAsIDAsIDAsIDAuNjkpO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBpbWcge1xuICB3aWR0aDogMTAwcHg7XG4gIG1hcmdpbjogMCAwIDIwcHg7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGg1IHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBtYXJnaW4tdG9wOiA2cHg7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGg2IHtcbiAgY29sb3I6ICMyYzU1ZTA7XG4gIG1hcmdpbjogMCAwIDIzcHg7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgcCB7XG4gIG1hcmdpbi1ib3R0b206IDRweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6ICM3MzczNzM7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5idG4td3JhcCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5idG4td3JhcCBpb24tYnV0dG9uIHtcbiAgd2lkdGg6IDQ0JSAhaW1wb3J0YW50O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/misreconocimientos/otorgado/otorgado.page.ts":
/*!**************************************************************!*\
  !*** ./src/app/misreconocimientos/otorgado/otorgado.page.ts ***!
  \**************************************************************/
/*! exports provided: OtorgadoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OtorgadoPage", function() { return OtorgadoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let OtorgadoPage = class OtorgadoPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
};
OtorgadoPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
OtorgadoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-otorgado',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./otorgado.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/misreconocimientos/otorgado/otorgado.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./otorgado.page.scss */ "./src/app/misreconocimientos/otorgado/otorgado.page.scss")).default]
    })
], OtorgadoPage);



/***/ })

}]);
//# sourceMappingURL=misreconocimientos-otorgado-otorgado-module-es2015.js.map