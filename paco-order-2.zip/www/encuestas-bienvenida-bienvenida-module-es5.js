function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["encuestas-bienvenida-bienvenida-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/encuestas/bienvenida/bienvenida.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/encuestas/bienvenida/bienvenida.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppEncuestasBienvenidaBienvenidaPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"term-content\">\n    <img src=\"assets/imgs/encuestas/bein.png\" alt=\"\">\n    <h5>Necesitamos un poco de información</h5>\n    <p>Vivamus sit amet diam rhoncus, porttitor ex a, semper arcu. Pellentesque imperdiet turpis quis lectus gravida rutrum quis sit amet leo.\n      Etiam id tincidunt diam, eleifend pretium dolor. Cras sed tincidunt felis. </p>\n    <h4>Tiempo de encuesta: 5 min.</h4>\n    <h4>Lorem Ipsum</h4>\n    <div class=\"btn-wrap\">\n      <ion-button (click)=\"multichoiceone()\">Comenzar</ion-button>\n    </div>\n  </div>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/encuestas/bienvenida/bienvenida-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/encuestas/bienvenida/bienvenida-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: BienvenidaPageRoutingModule */

  /***/
  function srcAppEncuestasBienvenidaBienvenidaRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BienvenidaPageRoutingModule", function () {
      return BienvenidaPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _bienvenida_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./bienvenida.page */
    "./src/app/encuestas/bienvenida/bienvenida.page.ts");

    var routes = [{
      path: '',
      component: _bienvenida_page__WEBPACK_IMPORTED_MODULE_3__["BienvenidaPage"]
    }];

    var BienvenidaPageRoutingModule = function BienvenidaPageRoutingModule() {
      _classCallCheck(this, BienvenidaPageRoutingModule);
    };

    BienvenidaPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], BienvenidaPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/encuestas/bienvenida/bienvenida.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/encuestas/bienvenida/bienvenida.module.ts ***!
    \***********************************************************/

  /*! exports provided: BienvenidaPageModule */

  /***/
  function srcAppEncuestasBienvenidaBienvenidaModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BienvenidaPageModule", function () {
      return BienvenidaPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _bienvenida_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./bienvenida-routing.module */
    "./src/app/encuestas/bienvenida/bienvenida-routing.module.ts");
    /* harmony import */


    var _bienvenida_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./bienvenida.page */
    "./src/app/encuestas/bienvenida/bienvenida.page.ts");

    var BienvenidaPageModule = function BienvenidaPageModule() {
      _classCallCheck(this, BienvenidaPageModule);
    };

    BienvenidaPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _bienvenida_routing_module__WEBPACK_IMPORTED_MODULE_5__["BienvenidaPageRoutingModule"]],
      declarations: [_bienvenida_page__WEBPACK_IMPORTED_MODULE_6__["BienvenidaPage"]]
    })], BienvenidaPageModule);
    /***/
  },

  /***/
  "./src/app/encuestas/bienvenida/bienvenida.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/encuestas/bienvenida/bienvenida.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppEncuestasBienvenidaBienvenidaPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-content {\n  --background: #5176f3;\n}\nion-content .term-content {\n  background: #fff;\n  padding: 20px 25px;\n  margin: 16px 20px 20px;\n  text-align: center;\n  border-radius: 20px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\nion-content .term-content img {\n  width: 190px;\n  margin: 0 0 6px;\n}\nion-content .term-content h5 {\n  font-size: 16px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n}\nion-content .term-content h4 {\n  font-size: 15px;\n  color: #969696;\n  font-weight: 600;\n  margin: 5px 0;\n  letter-spacing: 1px;\n}\nion-content .term-content .btn-wrap ion-button {\n  width: 44% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZW5jdWVzdGFzL2JpZW52ZW5pZGEvRzpcXGlvbmljXFxGSVZFUlJcXHBhbnRhbGxhcy1wYWNvL3NyY1xcYXBwXFxlbmN1ZXN0YXNcXGJpZW52ZW5pZGFcXGJpZW52ZW5pZGEucGFnZS5zY3NzIiwic3JjL2FwcC9lbmN1ZXN0YXMvYmllbnZlbmlkYS9iaWVudmVuaWRhLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FDQ0Y7QURBRTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSwrQ0FBQTtBQ0VKO0FEREk7RUFDRSxZQUFBO0VBQ0EsZUFBQTtBQ0dOO0FEREk7RUFDRSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQ0dOO0FEREk7RUFDRSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FDR047QURBTTtFQUNFLHFCQUFBO0FDRVIiLCJmaWxlIjoic3JjL2FwcC9lbmN1ZXN0YXMvYmllbnZlbmlkYS9iaWVudmVuaWRhLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XHJcbiAgLnRlcm0tY29udGVudCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgcGFkZGluZzogMjBweCAyNXB4O1xyXG4gICAgbWFyZ2luOiAxNnB4IDIwcHggMjBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcclxuICAgIGltZyB7XHJcbiAgICAgIHdpZHRoOiAxOTBweDtcclxuICAgICAgbWFyZ2luOiAwIDAgNnB4O1xyXG4gICAgfVxyXG4gICAgaDUge1xyXG4gICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDZweDtcclxuICAgICAgY29sb3I6ICMyYzU1ZTA7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICB9XHJcbiAgICBoNCB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgY29sb3I6ICM5Njk2OTY7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgIG1hcmdpbjogNXB4IDA7XHJcbiAgICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbiAgICB9XHJcbiAgICAuYnRuLXdyYXAge1xyXG4gICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogNDQlIWltcG9ydGFudDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufSIsImlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHBhZGRpbmc6IDIwcHggMjVweDtcbiAgbWFyZ2luOiAxNnB4IDIwcHggMjBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaW1nIHtcbiAgd2lkdGg6IDE5MHB4O1xuICBtYXJnaW46IDAgMCA2cHg7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGg1IHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBtYXJnaW4tdG9wOiA2cHg7XG4gIGNvbG9yOiAjMmM1NWUwO1xuICBmb250LXdlaWdodDogNzAwO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBoNCB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgY29sb3I6ICM5Njk2OTY7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIG1hcmdpbjogNXB4IDA7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5idG4td3JhcCBpb24tYnV0dG9uIHtcbiAgd2lkdGg6IDQ0JSAhaW1wb3J0YW50O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/encuestas/bienvenida/bienvenida.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/encuestas/bienvenida/bienvenida.page.ts ***!
    \*********************************************************/

  /*! exports provided: BienvenidaPage */

  /***/
  function srcAppEncuestasBienvenidaBienvenidaPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BienvenidaPage", function () {
      return BienvenidaPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var BienvenidaPage = /*#__PURE__*/function () {
      function BienvenidaPage(router, menuCtrl) {
        _classCallCheck(this, BienvenidaPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
      }

      _createClass(BienvenidaPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "multichoiceone",
        value: function multichoiceone() {
          this.router.navigateByUrl('/multichoiceone');
        }
      }]);

      return BienvenidaPage;
    }();

    BienvenidaPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    BienvenidaPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-bienvenida',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./bienvenida.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/encuestas/bienvenida/bienvenida.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./bienvenida.page.scss */
      "./src/app/encuestas/bienvenida/bienvenida.page.scss"))["default"]]
    })], BienvenidaPage);
    /***/
  }
}]);
//# sourceMappingURL=encuestas-bienvenida-bienvenida-module-es5.js.map