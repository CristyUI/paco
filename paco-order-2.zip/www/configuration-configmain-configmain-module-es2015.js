(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["configuration-configmain-configmain-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/configmain/configmain.page.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/configmain/configmain.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" (click)=\"PageRoute('home')\">\n      <ion-icon name=\"chevron-back-outline\" color=\"secondary\" style=\"margin-top: 4px;\"></ion-icon>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Configuración</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <div class=\"top-section\">\n      <img src=\"assets/imgs/configuration/dummy-user.png\" alt=\"\">\n      <h5>Carla A. Dillard</h5>\n      <h6>cadillard@planetbiz.com</h6>\n      <div class=\"btn-wrap\">\n        <ion-button>Agregar foto</ion-button>\n      </div>\n    </div>\n    <h4>Cuenta</h4>\n    <div class=\"listing-area\">\n      <ul>\n        <li (click)=\"PageRoute('billinfo')\">Cambiar contraseña</li>\n        <li (click)=\"PageRoute('billinfo')\">Cambiar NIP</li>\n        <li (click)=\"PageRoute('billinfo')\">Cuentas de banco y tarjetas</li>\n      </ul>\n    </div>\n    <div class=\"bottom-btn\">\n      <ion-button class=\"btn-transparent\" (click)=\"PageRoute('login')\">Cerrar sesión</ion-button>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/configuration/configmain/configmain-routing.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/configuration/configmain/configmain-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: ConfigmainPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigmainPageRoutingModule", function() { return ConfigmainPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _configmain_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./configmain.page */ "./src/app/configuration/configmain/configmain.page.ts");




const routes = [
    {
        path: '',
        component: _configmain_page__WEBPACK_IMPORTED_MODULE_3__["ConfigmainPage"]
    }
];
let ConfigmainPageRoutingModule = class ConfigmainPageRoutingModule {
};
ConfigmainPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ConfigmainPageRoutingModule);



/***/ }),

/***/ "./src/app/configuration/configmain/configmain.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/configuration/configmain/configmain.module.ts ***!
  \***************************************************************/
/*! exports provided: ConfigmainPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigmainPageModule", function() { return ConfigmainPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _configmain_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./configmain-routing.module */ "./src/app/configuration/configmain/configmain-routing.module.ts");
/* harmony import */ var _configmain_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./configmain.page */ "./src/app/configuration/configmain/configmain.page.ts");







let ConfigmainPageModule = class ConfigmainPageModule {
};
ConfigmainPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _configmain_routing_module__WEBPACK_IMPORTED_MODULE_5__["ConfigmainPageRoutingModule"]
        ],
        declarations: [_configmain_page__WEBPACK_IMPORTED_MODULE_6__["ConfigmainPage"]]
    })
], ConfigmainPageModule);



/***/ }),

/***/ "./src/app/configuration/configmain/configmain.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/configuration/configmain/configmain.page.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-title {\n  font-weight: 600;\n}\nion-header ion-buttons {\n  margin-left: 20px;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.ion-padding {\n  padding: 16px 20px;\n}\n.top-section {\n  text-align: center;\n}\n.top-section img {\n  width: 130px;\n  margin: 0 0 10px;\n}\n.top-section h5 {\n  font-size: 18px;\n  margin-top: 6px;\n  font-weight: 700;\n}\n.top-section h6 {\n  color: #2c55e0;\n  margin: 0 0 10px;\n  font-weight: 100;\n  font-size: 15px;\n}\n.top-section .btn-wrap ion-button {\n  width: 44% !important;\n}\nh4 {\n  font-size: 17px;\n  font-weight: 600;\n  margin: 22px 0 0 5px;\n}\n.listing-area ul {\n  padding-left: 0;\n}\n.listing-area ul li {\n  list-style-type: none;\n  border: 2px solid #7995f3;\n  border-radius: 30px;\n  color: #2c55e0;\n  padding: 12px 16px;\n  margin-bottom: 12px;\n}\n.bottom-btn {\n  text-align: center;\n}\n.bottom-btn ion-button {\n  color: #2246bf;\n  font-size: 15px !important;\n  font-weight: 800;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29uZmlndXJhdGlvbi9jb25maWdtYWluL0c6XFxpb25pY1xcRklWRVJSXFxwYW50YWxsYXMtcGFjby9zcmNcXGFwcFxcY29uZmlndXJhdGlvblxcY29uZmlnbWFpblxcY29uZmlnbWFpbi5wYWdlLnNjc3MiLCJzcmMvYXBwL2NvbmZpZ3VyYXRpb24vY29uZmlnbWFpbi9jb25maWdtYWluLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGdCQUFBO0FDQUo7QURFRTtFQUNFLGlCQUFBO0FDQUo7QURHSTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDRE47QURLQTtFQUNFLGtCQUFBO0FDRkY7QURJQTtFQUNFLGtCQUFBO0FDREY7QURFRTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtBQ0FKO0FERUU7RUFDRSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDQUo7QURFRTtFQUNFLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQ0FKO0FER0k7RUFDRSxxQkFBQTtBQ0ROO0FES0E7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtBQ0ZGO0FES0U7RUFDRSxlQUFBO0FDRko7QURHSTtFQUNFLHFCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDRE47QURLQTtFQUNFLGtCQUFBO0FDRkY7QURHRTtFQUNFLGNBQUE7RUFDQSwwQkFBQTtFQUNBLGdCQUFBO0FDREoiLCJmaWxlIjoic3JjL2FwcC9jb25maWd1cmF0aW9uL2NvbmZpZ21haW4vY29uZmlnbWFpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tdGl0bGUge1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB9XHJcbiAgaW9uLWJ1dHRvbnMge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgfVxyXG4gIC5idG4tcmlnaHQge1xyXG4gICAgLmFsZXJ0LXRhZyB7XHJcbiAgICAgIHdpZHRoOiAxMnB4O1xyXG4gICAgICBoZWlnaHQ6IDEycHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNmYjRmMzM7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgcmlnaHQ6IC0zcHg7XHJcbiAgICAgIGJvdHRvbTogLTJweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuLmlvbi1wYWRkaW5nIHtcclxuICBwYWRkaW5nOiAxNnB4IDIwcHg7XHJcbn1cclxuLnRvcC1zZWN0aW9uIHtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgaW1nIHtcclxuICAgIHdpZHRoOiAxMzBweDtcclxuICAgIG1hcmdpbjogMCAwIDEwcHg7XHJcbiAgfVxyXG4gIGg1IHtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIG1hcmdpbi10b3A6IDZweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgfVxyXG4gIGg2IHtcclxuICAgIGNvbG9yOiAjMmM1NWUwO1xyXG4gICAgbWFyZ2luOiAwIDAgMTBweDtcclxuICAgIGZvbnQtd2VpZ2h0OiAxMDA7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgfVxyXG4gIC5idG4td3JhcCB7XHJcbiAgICBpb24tYnV0dG9uIHtcclxuICAgICAgd2lkdGg6IDQ0JSFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbmg0IHtcclxuICBmb250LXNpemU6IDE3cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBtYXJnaW46IDIycHggMCAwIDVweDtcclxufVxyXG4ubGlzdGluZy1hcmVhIHtcclxuICB1bCB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDA7XHJcbiAgICBsaSB7XHJcbiAgICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcclxuICAgICAgYm9yZGVyOiAycHggc29saWQgIzc5OTVmMztcclxuICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgICAgY29sb3I6ICMyYzU1ZTA7XHJcbiAgICAgIHBhZGRpbmc6IDEycHggMTZweDtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogMTJweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuLmJvdHRvbS1idG4ge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBpb24tYnV0dG9uIHtcclxuICAgIGNvbG9yOiAjMjI0NmJmO1xyXG4gICAgZm9udC1zaXplOiAxNXB4IWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgfVxyXG59IiwiaW9uLWhlYWRlciBpb24tdGl0bGUge1xuICBmb250LXdlaWdodDogNjAwO1xufVxuaW9uLWhlYWRlciBpb24tYnV0dG9ucyB7XG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xufVxuaW9uLWhlYWRlciAuYnRuLXJpZ2h0IC5hbGVydC10YWcge1xuICB3aWR0aDogMTJweDtcbiAgaGVpZ2h0OiAxMnB4O1xuICBiYWNrZ3JvdW5kOiAjZmI0ZjMzO1xuICBkaXNwbGF5OiBibG9jaztcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAtM3B4O1xuICBib3R0b206IC0ycHg7XG59XG5cbi5pb24tcGFkZGluZyB7XG4gIHBhZGRpbmc6IDE2cHggMjBweDtcbn1cblxuLnRvcC1zZWN0aW9uIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLnRvcC1zZWN0aW9uIGltZyB7XG4gIHdpZHRoOiAxMzBweDtcbiAgbWFyZ2luOiAwIDAgMTBweDtcbn1cbi50b3Atc2VjdGlvbiBoNSB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBmb250LXdlaWdodDogNzAwO1xufVxuLnRvcC1zZWN0aW9uIGg2IHtcbiAgY29sb3I6ICMyYzU1ZTA7XG4gIG1hcmdpbjogMCAwIDEwcHg7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cbi50b3Atc2VjdGlvbiAuYnRuLXdyYXAgaW9uLWJ1dHRvbiB7XG4gIHdpZHRoOiA0NCUgIWltcG9ydGFudDtcbn1cblxuaDQge1xuICBmb250LXNpemU6IDE3cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIG1hcmdpbjogMjJweCAwIDAgNXB4O1xufVxuXG4ubGlzdGluZy1hcmVhIHVsIHtcbiAgcGFkZGluZy1sZWZ0OiAwO1xufVxuLmxpc3RpbmctYXJlYSB1bCBsaSB7XG4gIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbiAgYm9yZGVyOiAycHggc29saWQgIzc5OTVmMztcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgY29sb3I6ICMyYzU1ZTA7XG4gIHBhZGRpbmc6IDEycHggMTZweDtcbiAgbWFyZ2luLWJvdHRvbTogMTJweDtcbn1cblxuLmJvdHRvbS1idG4ge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uYm90dG9tLWJ0biBpb24tYnV0dG9uIHtcbiAgY29sb3I6ICMyMjQ2YmY7XG4gIGZvbnQtc2l6ZTogMTVweCAhaW1wb3J0YW50O1xuICBmb250LXdlaWdodDogODAwO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/configuration/configmain/configmain.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/configuration/configmain/configmain.page.ts ***!
  \*************************************************************/
/*! exports provided: ConfigmainPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigmainPage", function() { return ConfigmainPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let ConfigmainPage = class ConfigmainPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
};
ConfigmainPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
ConfigmainPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-configmain',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./configmain.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/configmain/configmain.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./configmain.page.scss */ "./src/app/configuration/configmain/configmain.page.scss")).default]
    })
], ConfigmainPage);



/***/ })

}]);
//# sourceMappingURL=configuration-configmain-configmain-module-es2015.js.map