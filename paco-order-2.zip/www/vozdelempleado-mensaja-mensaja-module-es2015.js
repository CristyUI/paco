(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["vozdelempleado-mensaja-mensaja-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/vozdelempleado/mensaja/mensaja.page.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/vozdelempleado/mensaja/mensaja.page.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close-outline\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"term-content\">\n    <img src=\"assets/imgs/message.png\" alt=\"\">\n    <h5>Mensaje enviado</h5>\n    <p>El mensaje se ha enviado exitosamente, en breve recibirás una respuesta.</p>\n    <div class=\"btn-wrap\">\n      <ion-button (click)=\"home()\">Continuar</ion-button>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/vozdelempleado/mensaja/mensaja-routing.module.ts":
/*!******************************************************************!*\
  !*** ./src/app/vozdelempleado/mensaja/mensaja-routing.module.ts ***!
  \******************************************************************/
/*! exports provided: MensajaPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MensajaPageRoutingModule", function() { return MensajaPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _mensaja_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mensaja.page */ "./src/app/vozdelempleado/mensaja/mensaja.page.ts");




const routes = [
    {
        path: '',
        component: _mensaja_page__WEBPACK_IMPORTED_MODULE_3__["MensajaPage"]
    }
];
let MensajaPageRoutingModule = class MensajaPageRoutingModule {
};
MensajaPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MensajaPageRoutingModule);



/***/ }),

/***/ "./src/app/vozdelempleado/mensaja/mensaja.module.ts":
/*!**********************************************************!*\
  !*** ./src/app/vozdelempleado/mensaja/mensaja.module.ts ***!
  \**********************************************************/
/*! exports provided: MensajaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MensajaPageModule", function() { return MensajaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _mensaja_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./mensaja-routing.module */ "./src/app/vozdelempleado/mensaja/mensaja-routing.module.ts");
/* harmony import */ var _mensaja_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./mensaja.page */ "./src/app/vozdelempleado/mensaja/mensaja.page.ts");







let MensajaPageModule = class MensajaPageModule {
};
MensajaPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _mensaja_routing_module__WEBPACK_IMPORTED_MODULE_5__["MensajaPageRoutingModule"]
        ],
        declarations: [_mensaja_page__WEBPACK_IMPORTED_MODULE_6__["MensajaPage"]]
    })
], MensajaPageModule);



/***/ }),

/***/ "./src/app/vozdelempleado/mensaja/mensaja.page.scss":
/*!**********************************************************!*\
  !*** ./src/app/vozdelempleado/mensaja/mensaja.page.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #5176f3;\n}\nion-content .term-content {\n  background: #fff;\n  padding: 20px 18px;\n  margin: 16px 20px 20px;\n  text-align: center;\n  border-radius: 20px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\nion-content .term-content img {\n  width: 100px;\n  margin: 0 0 20px;\n}\nion-content .term-content h5 {\n  font-size: 18px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n}\nion-content .term-content p {\n  margin-bottom: 4px;\n}\nion-content .term-content .btn-wrap ion-button {\n  width: 44% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdm96ZGVsZW1wbGVhZG8vbWVuc2FqYS9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXHZvemRlbGVtcGxlYWRvXFxtZW5zYWphXFxtZW5zYWphLnBhZ2Uuc2NzcyIsInNyYy9hcHAvdm96ZGVsZW1wbGVhZG8vbWVuc2FqYS9tZW5zYWphLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FDQ0Y7QURBRTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSwrQ0FBQTtBQ0VKO0FEREk7RUFDRSxZQUFBO0VBQ0EsZ0JBQUE7QUNHTjtBRERJO0VBQ0UsZUFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUNHTjtBRERJO0VBQ0Usa0JBQUE7QUNHTjtBREFNO0VBQ0UscUJBQUE7QUNFUiIsImZpbGUiOiJzcmMvYXBwL3ZvemRlbGVtcGxlYWRvL21lbnNhamEvbWVuc2FqYS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gIC50ZXJtLWNvbnRlbnQge1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIHBhZGRpbmc6IDIwcHggMThweDtcclxuICAgIG1hcmdpbjogMTZweCAyMHB4IDIwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgYm94LXNoYWRvdzogMCA3cHggMTZweCAtN3B4IHJnYmEoMCwgMCwgMCwgMC42OSk7XHJcbiAgICBpbWcge1xyXG4gICAgICB3aWR0aDogMTAwcHg7XHJcbiAgICAgIG1hcmdpbjogMCAwIDIwcHg7XHJcbiAgICB9XHJcbiAgICBoNSB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgbWFyZ2luLXRvcDogNnB4O1xyXG4gICAgICBjb2xvcjogIzJjNTVlMDtcclxuICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgIH1cclxuICAgIHAge1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiA0cHg7XHJcbiAgICB9XHJcbiAgICAuYnRuLXdyYXAge1xyXG4gICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogNDQlIWltcG9ydGFudDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufSIsImlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHBhZGRpbmc6IDIwcHggMThweDtcbiAgbWFyZ2luOiAxNnB4IDIwcHggMjBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaW1nIHtcbiAgd2lkdGg6IDEwMHB4O1xuICBtYXJnaW46IDAgMCAyMHB4O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBoNSB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBjb2xvcjogIzJjNTVlMDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgcCB7XG4gIG1hcmdpbi1ib3R0b206IDRweDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgLmJ0bi13cmFwIGlvbi1idXR0b24ge1xuICB3aWR0aDogNDQlICFpbXBvcnRhbnQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/vozdelempleado/mensaja/mensaja.page.ts":
/*!********************************************************!*\
  !*** ./src/app/vozdelempleado/mensaja/mensaja.page.ts ***!
  \********************************************************/
/*! exports provided: MensajaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MensajaPage", function() { return MensajaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let MensajaPage = class MensajaPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    home() {
        this.router.navigateByUrl('/home');
    }
};
MensajaPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
MensajaPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-mensaja',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./mensaja.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/vozdelempleado/mensaja/mensaja.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./mensaja.page.scss */ "./src/app/vozdelempleado/mensaja/mensaja.page.scss")).default]
    })
], MensajaPage);



/***/ })

}]);
//# sourceMappingURL=vozdelempleado-mensaja-mensaja-module-es2015.js.map