function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["vozdelempleado-vozdelmain-vozdelmain-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/vozdelempleado/vozdelmain/vozdelmain.page.html":
  /*!******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/vozdelempleado/vozdelmain/vozdelmain.page.html ***!
    \******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppVozdelempleadoVozdelmainVozdelmainPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close-outline\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"term-content\">\n    <h5>Voz del empleado</h5>\n    <h6>¿Sagittis ultricies quam nisl?</h6>\n    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Erat facilisis facilisis laoreet euismod.</p>\n    <ion-list>\n      <ion-item class=\"ion-no-padding\">\n        <ion-label>Tema</ion-label>\n        <ion-select>\n          <ion-select-option value=\"lacus\">Lacus in sed</ion-select-option>\n          <ion-select-option value=\"otros\">Otros</ion-select-option>\n          <ion-select-option value=\"duis\">Duis elit senectus</ion-select-option>\n          <ion-select-option value=\"condimentum\">Condimentum</ion-select-option>\n        </ion-select>\n      </ion-item>\n\n      <ion-item class=\"ion-no-padding\">\n        <ion-textarea placeholder=\"Comentario\"></ion-textarea>\n      </ion-item>\n      <div class=\"camera-link\">\n         <p>Adjuntar imagen (opcional)<span><img src=\"assets/imgs/camera.png\" alt=\"\"></span></p>\n      </div>\n\n    </ion-list>\n\n   <div class=\"check-box\">\n     <ion-list>\n       <ion-item class=\"ion-no-padding\" [ngClass]=\"{'active': !active}\">\n         <ion-checkbox (ionChange)=\"changeEvent($event)\"></ion-checkbox>\n         <ion-label>Quiero que mi comentario sea anónimo</ion-label>\n       </ion-item>\n     </ion-list>\n   </div>\n\n    <div class=\"btn-wrap\">\n      <ion-button (click)=\"mensaja()\">Enviar</ion-button>\n    </div>\n\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/vozdelempleado/vozdelmain/vozdelmain-routing.module.ts":
  /*!************************************************************************!*\
    !*** ./src/app/vozdelempleado/vozdelmain/vozdelmain-routing.module.ts ***!
    \************************************************************************/

  /*! exports provided: VozdelmainPageRoutingModule */

  /***/
  function srcAppVozdelempleadoVozdelmainVozdelmainRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VozdelmainPageRoutingModule", function () {
      return VozdelmainPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _vozdelmain_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./vozdelmain.page */
    "./src/app/vozdelempleado/vozdelmain/vozdelmain.page.ts");

    var routes = [{
      path: '',
      component: _vozdelmain_page__WEBPACK_IMPORTED_MODULE_3__["VozdelmainPage"]
    }];

    var VozdelmainPageRoutingModule = function VozdelmainPageRoutingModule() {
      _classCallCheck(this, VozdelmainPageRoutingModule);
    };

    VozdelmainPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], VozdelmainPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/vozdelempleado/vozdelmain/vozdelmain.module.ts":
  /*!****************************************************************!*\
    !*** ./src/app/vozdelempleado/vozdelmain/vozdelmain.module.ts ***!
    \****************************************************************/

  /*! exports provided: VozdelmainPageModule */

  /***/
  function srcAppVozdelempleadoVozdelmainVozdelmainModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VozdelmainPageModule", function () {
      return VozdelmainPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _vozdelmain_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./vozdelmain-routing.module */
    "./src/app/vozdelempleado/vozdelmain/vozdelmain-routing.module.ts");
    /* harmony import */


    var _vozdelmain_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./vozdelmain.page */
    "./src/app/vozdelempleado/vozdelmain/vozdelmain.page.ts");

    var VozdelmainPageModule = function VozdelmainPageModule() {
      _classCallCheck(this, VozdelmainPageModule);
    };

    VozdelmainPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _vozdelmain_routing_module__WEBPACK_IMPORTED_MODULE_5__["VozdelmainPageRoutingModule"]],
      declarations: [_vozdelmain_page__WEBPACK_IMPORTED_MODULE_6__["VozdelmainPage"]]
    })], VozdelmainPageModule);
    /***/
  },

  /***/
  "./src/app/vozdelempleado/vozdelmain/vozdelmain.page.scss":
  /*!****************************************************************!*\
    !*** ./src/app/vozdelempleado/vozdelmain/vozdelmain.page.scss ***!
    \****************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppVozdelempleadoVozdelmainVozdelmainPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-content {\n  --background: #5176f3;\n}\nion-content .term-content {\n  background: #fff;\n  padding: 20px 25px;\n  margin: 20px;\n  border-radius: 20px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\nion-content .term-content h5 {\n  font-size: 17px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n  text-align: left;\n}\nion-content .term-content h6 {\n  text-align: left;\n  font-size: 15px;\n  font-weight: 700;\n}\nion-content .term-content p {\n  text-align: left;\n  font-size: 14px;\n  line-height: 20px;\n  color: #808080;\n  margin-bottom: 2px;\n}\nion-content .term-content ion-list ion-item {\n  --border-color: transparent;\n  font-size: 15px;\n  color: #2c55e0;\n  border: 1px solid #718be4;\n  --min-height: 32px;\n  padding: 4px 14px;\n  margin: 12px 0;\n  border-radius: 30px;\n  font-weight: 600;\n  --background: transparent;\n}\nion-content .term-content ion-list ion-item ion-checkbox {\n  --border-radius: 50%;\n  margin: 0 5px 0 0;\n  --border-color: #5176f3;\n  height: 30px;\n  width: 30px;\n}\nion-content .term-content ion-list ion-item ion-label {\n  white-space: normal !important;\n  margin: 2px;\n}\nion-content .term-content ion-list .active {\n  background: #5176f3;\n  --background: transparent;\n  color: #fff;\n}\nion-content .term-content ion-list ion-textarea {\n  height: 80px;\n  margin: 0;\n  padding: 0 10px;\n}\nion-content .term-content ion-list ion-textarea::-moz-placeholder {\n  color: #9c9c9c;\n}\nion-content .term-content ion-list ion-textarea::-ms-input-placeholder {\n  color: #9c9c9c;\n}\nion-content .term-content ion-list ion-textarea::placeholder {\n  color: #9c9c9c;\n}\nion-content .term-content .camera-link p {\n  border: 1px solid #5176f3;\n  padding: 11px 19px;\n  border-radius: 30px;\n  color: #5176f3;\n  font-weight: 600;\n}\nion-content .term-content .camera-link p span {\n  float: right;\n}\nion-content .term-content .check-box ion-item {\n  border: 1px solid #2c55e0;\n}\nion-content .term-content .btn-wrap {\n  text-align: right;\n}\nion-content .term-content .btn-wrap ion-button {\n  width: 44% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdm96ZGVsZW1wbGVhZG8vdm96ZGVsbWFpbi9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXHZvemRlbGVtcGxlYWRvXFx2b3pkZWxtYWluXFx2b3pkZWxtYWluLnBhZ2Uuc2NzcyIsInNyYy9hcHAvdm96ZGVsZW1wbGVhZG8vdm96ZGVsbWFpbi92b3pkZWxtYWluLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FDQ0Y7QURBRTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSwrQ0FBQTtBQ0VKO0FEREk7RUFDRSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FDR047QURESTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDR047QURESTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FDR047QURBTTtFQUNFLDJCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFFQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0FDQ1I7QURBUTtFQUNFLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FDRVY7QURBTztFQUNFLDhCQUFBO0VBQ0EsV0FBQTtBQ0VUO0FEQ007RUFDRSxtQkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtBQ0NSO0FEQ007RUFDRSxZQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7QUNDUjtBREFRO0VBQ0UsY0FBQTtBQ0VWO0FESFE7RUFDRSxjQUFBO0FDRVY7QURIUTtFQUNFLGNBQUE7QUNFVjtBREdNO0VBQ0UseUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDRFI7QURFUTtFQUNFLFlBQUE7QUNBVjtBREtNO0VBQ0UseUJBQUE7QUNIUjtBRE1JO0VBQ0UsaUJBQUE7QUNKTjtBREtNO0VBQ0UscUJBQUE7QUNIUiIsImZpbGUiOiJzcmMvYXBwL3ZvemRlbGVtcGxlYWRvL3ZvemRlbG1haW4vdm96ZGVsbWFpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gIC50ZXJtLWNvbnRlbnQge1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIHBhZGRpbmc6IDIwcHggMjVweDtcclxuICAgIG1hcmdpbjogMjBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcclxuICAgIGg1IHtcclxuICAgICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgICBtYXJnaW4tdG9wOiA2cHg7XHJcbiAgICAgIGNvbG9yOiAjMmM1NWUwO1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgfVxyXG4gICAgaDYge1xyXG4gICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICB9XHJcbiAgICBwIHtcclxuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICBsaW5lLWhlaWdodDogMjBweDtcclxuICAgICAgY29sb3I6ICM4MDgwODA7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDJweDtcclxuICAgIH1cclxuICAgIGlvbi1saXN0IHtcclxuICAgICAgaW9uLWl0ZW0ge1xyXG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgICAgY29sb3I6ICMyYzU1ZTA7XHJcblxyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICM3MThiZTQ7XHJcbiAgICAgICAgLS1taW4taGVpZ2h0OiAzMnB4O1xyXG4gICAgICAgIHBhZGRpbmc6IDRweCAxNHB4O1xyXG4gICAgICAgIG1hcmdpbjogMTJweCAwO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIGlvbi1jaGVja2JveCB7XHJcbiAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgIG1hcmdpbjogMCA1cHggMCAwO1xyXG4gICAgICAgICAgLS1ib3JkZXItY29sb3I6ICM1MTc2ZjM7XHJcbiAgICAgICAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICAgICAgICB3aWR0aDogMzBweDtcclxuICAgICAgICB9XHJcbiAgICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgICB3aGl0ZS1zcGFjZTogbm9ybWFsIWltcG9ydGFudDtcclxuICAgICAgICAgbWFyZ2luOiAycHg7XHJcbiAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgLmFjdGl2ZSB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogIzUxNzZmMztcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICB9XHJcbiAgICAgIGlvbi10ZXh0YXJlYSB7XHJcbiAgICAgICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICBwYWRkaW5nOiAwIDEwcHg7XHJcbiAgICAgICAgJjo6cGxhY2Vob2xkZXIge1xyXG4gICAgICAgICAgY29sb3I6ICM5YzljOWM7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAuY2FtZXJhLWxpbmsge1xyXG4gICAgICBwIHtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjNTE3NmYzO1xyXG4gICAgICAgIHBhZGRpbmc6IDExcHggMTlweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgICAgIGNvbG9yOiAjNTE3NmYzO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgc3BhbiB7XHJcbiAgICAgICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAuY2hlY2stYm94IHtcclxuICAgICAgaW9uLWl0ZW0ge1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICMyYzU1ZTA7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5idG4td3JhcCB7XHJcbiAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogNDQlIWltcG9ydGFudDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufSIsImlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHBhZGRpbmc6IDIwcHggMjVweDtcbiAgbWFyZ2luOiAyMHB4O1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaDUge1xuICBmb250LXNpemU6IDE3cHg7XG4gIG1hcmdpbi10b3A6IDZweDtcbiAgY29sb3I6ICMyYzU1ZTA7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGg2IHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBmb250LXdlaWdodDogNzAwO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBwIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBsaW5lLWhlaWdodDogMjBweDtcbiAgY29sb3I6ICM4MDgwODA7XG4gIG1hcmdpbi1ib3R0b206IDJweDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaW9uLWxpc3QgaW9uLWl0ZW0ge1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgY29sb3I6ICMyYzU1ZTA7XG4gIGJvcmRlcjogMXB4IHNvbGlkICM3MThiZTQ7XG4gIC0tbWluLWhlaWdodDogMzJweDtcbiAgcGFkZGluZzogNHB4IDE0cHg7XG4gIG1hcmdpbjogMTJweCAwO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBpb24tbGlzdCBpb24taXRlbSBpb24tY2hlY2tib3gge1xuICAtLWJvcmRlci1yYWRpdXM6IDUwJTtcbiAgbWFyZ2luOiAwIDVweCAwIDA7XG4gIC0tYm9yZGVyLWNvbG9yOiAjNTE3NmYzO1xuICBoZWlnaHQ6IDMwcHg7XG4gIHdpZHRoOiAzMHB4O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBpb24tbGlzdCBpb24taXRlbSBpb24tbGFiZWwge1xuICB3aGl0ZS1zcGFjZTogbm9ybWFsICFpbXBvcnRhbnQ7XG4gIG1hcmdpbjogMnB4O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBpb24tbGlzdCAuYWN0aXZlIHtcbiAgYmFja2dyb3VuZDogIzUxNzZmMztcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgY29sb3I6ICNmZmY7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGlvbi1saXN0IGlvbi10ZXh0YXJlYSB7XG4gIGhlaWdodDogODBweDtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwIDEwcHg7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGlvbi1saXN0IGlvbi10ZXh0YXJlYTo6cGxhY2Vob2xkZXIge1xuICBjb2xvcjogIzljOWM5Yztcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgLmNhbWVyYS1saW5rIHAge1xuICBib3JkZXI6IDFweCBzb2xpZCAjNTE3NmYzO1xuICBwYWRkaW5nOiAxMXB4IDE5cHg7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIGNvbG9yOiAjNTE3NmYzO1xuICBmb250LXdlaWdodDogNjAwO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCAuY2FtZXJhLWxpbmsgcCBzcGFuIHtcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCAuY2hlY2stYm94IGlvbi1pdGVtIHtcbiAgYm9yZGVyOiAxcHggc29saWQgIzJjNTVlMDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgLmJ0bi13cmFwIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5idG4td3JhcCBpb24tYnV0dG9uIHtcbiAgd2lkdGg6IDQ0JSAhaW1wb3J0YW50O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/vozdelempleado/vozdelmain/vozdelmain.page.ts":
  /*!**************************************************************!*\
    !*** ./src/app/vozdelempleado/vozdelmain/vozdelmain.page.ts ***!
    \**************************************************************/

  /*! exports provided: VozdelmainPage */

  /***/
  function srcAppVozdelempleadoVozdelmainVozdelmainPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VozdelmainPage", function () {
      return VozdelmainPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var VozdelmainPage = /*#__PURE__*/function () {
      function VozdelmainPage(router, menuCtrl) {
        _classCallCheck(this, VozdelmainPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
        this.isToggled = false;
        this.active = true;
      }

      _createClass(VozdelmainPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "changeEvent",
        value: function changeEvent(event) {
          console.log(this.isToggled);
          this.isToggled = !this.isToggled;
          this.active = !this.active;
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "mensaja",
        value: function mensaja() {
          this.router.navigateByUrl('/mensaja');
        }
      }]);

      return VozdelmainPage;
    }();

    VozdelmainPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    VozdelmainPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-vozdelmain',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./vozdelmain.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/vozdelempleado/vozdelmain/vozdelmain.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./vozdelmain.page.scss */
      "./src/app/vozdelempleado/vozdelmain/vozdelmain.page.scss"))["default"]]
    })], VozdelmainPage);
    /***/
  }
}]);
//# sourceMappingURL=vozdelempleado-vozdelmain-vozdelmain-module-es5.js.map