function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["reconoce-enviado-enviado-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/reconoce/enviado/enviado.page.html":
  /*!******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/reconoce/enviado/enviado.page.html ***!
    \******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppReconoceEnviadoEnviadoPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <div class=\"term-content\">\n    <h5>Usuarios</h5>\n    <div class=\"search-area\">\n      <div class=\"content-search\" (click)=\"PageRoute('search')\">\n        <span>Buscar<img src=\"assets/imgs/search-icon.png\" alt=\"\"></span>\n      </div>\n    </div>\n    <h4>Grupos</h4>\n\n    <ion-list>\n      <ion-radio-group>\n        <ion-item class=\"ion-no-padding\">\n          <ion-radio value=\"management\"></ion-radio>\n          <ion-label>Management <br><span>Lorem ipsum</span></ion-label>\n        </ion-item>\n        <ion-item class=\"ion-no-padding\">\n          <ion-radio value=\"recursos\"></ion-radio>\n          <ion-label>Recursos humanos <br><span>Lorem ipsum</span></ion-label>\n        </ion-item>\n      </ion-radio-group>\n    </ion-list>\n\n    <h4>Personas</h4>\n\n    <div class=\"persona-wrap\">\n      <div class=\"single-item\" *ngFor=\"let n of list\"  (click)=\"select(n)\" [ngClass]=\"{active: isActive(n)}\">\n        <ion-row>\n          <ion-col size=\"2\">\n           <div class=\"checking-icon\">\n             <ion-icon name=\"ellipse-outline\" id=\"circle\"></ion-icon>\n             <ion-icon name=\"checkmark-outline\" id=\"check\"></ion-icon>\n           </div>\n          </ion-col>\n          <ion-col size=\"8\">\n            <h6>{{n.name}}</h6>\n            <p>{{n.designation}}</p>\n          </ion-col>\n          <ion-col size=\"2\">\n           <div class=\"user-icon\">\n             <ion-icon name=\"person-outline\"></ion-icon>\n           </div>\n          </ion-col>\n        </ion-row>\n      </div>\n    </div>\n\n\n\n    <div class=\"btn-wrap\">\n      <ion-button (click)=\"reconomain()\">Aceptar</ion-button>\n    </div>\n\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/reconoce/enviado/enviado-routing.module.ts":
  /*!************************************************************!*\
    !*** ./src/app/reconoce/enviado/enviado-routing.module.ts ***!
    \************************************************************/

  /*! exports provided: EnviadoPageRoutingModule */

  /***/
  function srcAppReconoceEnviadoEnviadoRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EnviadoPageRoutingModule", function () {
      return EnviadoPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _enviado_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./enviado.page */
    "./src/app/reconoce/enviado/enviado.page.ts");

    var routes = [{
      path: '',
      component: _enviado_page__WEBPACK_IMPORTED_MODULE_3__["EnviadoPage"]
    }];

    var EnviadoPageRoutingModule = function EnviadoPageRoutingModule() {
      _classCallCheck(this, EnviadoPageRoutingModule);
    };

    EnviadoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], EnviadoPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/reconoce/enviado/enviado.module.ts":
  /*!****************************************************!*\
    !*** ./src/app/reconoce/enviado/enviado.module.ts ***!
    \****************************************************/

  /*! exports provided: EnviadoPageModule */

  /***/
  function srcAppReconoceEnviadoEnviadoModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EnviadoPageModule", function () {
      return EnviadoPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _enviado_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./enviado-routing.module */
    "./src/app/reconoce/enviado/enviado-routing.module.ts");
    /* harmony import */


    var _enviado_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./enviado.page */
    "./src/app/reconoce/enviado/enviado.page.ts");

    var EnviadoPageModule = function EnviadoPageModule() {
      _classCallCheck(this, EnviadoPageModule);
    };

    EnviadoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _enviado_routing_module__WEBPACK_IMPORTED_MODULE_5__["EnviadoPageRoutingModule"]],
      declarations: [_enviado_page__WEBPACK_IMPORTED_MODULE_6__["EnviadoPage"]]
    })], EnviadoPageModule);
    /***/
  },

  /***/
  "./src/app/reconoce/enviado/enviado.page.scss":
  /*!****************************************************!*\
    !*** ./src/app/reconoce/enviado/enviado.page.scss ***!
    \****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppReconoceEnviadoEnviadoPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-content {\n  --background: #5176f3;\n}\nion-content .term-content {\n  background: #fff;\n  padding: 20px 22px;\n  margin: 16px 20px 20px;\n  border-radius: 30px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\nion-content .term-content h5 {\n  font-size: 17px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n  text-align: left;\n}\nion-content .term-content h4 {\n  font-size: 17px;\n  font-weight: 700;\n}\nion-content .term-content .search-area {\n  margin: 16px 0 22px;\n}\nion-content .term-content .search-area .content-search {\n  box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.2588235294);\n  border-radius: 30px;\n  padding: 15px 22px;\n}\nion-content .term-content .search-area .content-search span {\n  color: #8c8b8b;\n}\nion-content .term-content .search-area .content-search span img {\n  width: 20px;\n  vertical-align: bottom;\n  float: right;\n}\nion-content .term-content ion-list ion-item {\n  --border-color: transparent;\n}\nion-content .term-content ion-list ion-item ion-radio {\n  margin-right: 12px;\n  width: 30px;\n  height: 30px;\n}\nion-content .term-content ion-list ion-item ion-label {\n  color: #2c55e0;\n  font-size: 17px;\n  font-weight: 600;\n}\nion-content .term-content ion-list ion-item ion-label span {\n  font-size: 14px;\n  font-weight: 100;\n}\nion-content .term-content .persona-wrap .single-item h6 {\n  font-size: 16px;\n  margin: 0 0 4px;\n  font-weight: 600;\n}\nion-content .term-content .persona-wrap .single-item p {\n  margin: 0;\n  color: #908f8f;\n  font-size: 14px;\n}\nion-content .term-content .persona-wrap .single-item ion-row ion-col:nth-child(1) {\n  padding-left: 0;\n}\nion-content .term-content .persona-wrap .single-item .checking-icon {\n  text-align: center;\n}\nion-content .term-content .persona-wrap .single-item .checking-icon ion-icon {\n  font-size: 38px;\n  color: #5176f3;\n  margin-top: 3px;\n}\nion-content .term-content .persona-wrap .single-item .checking-icon #check {\n  display: none;\n}\nion-content .term-content .persona-wrap .single-item .user-icon {\n  text-align: center;\n}\nion-content .term-content .persona-wrap .single-item .user-icon ion-icon {\n  font-size: 18px;\n  border: 2px solid #acbcef;\n  border-radius: 50%;\n  padding: 5px;\n  color: #acbcef;\n  margin-top: 5px;\n}\nion-content .term-content .persona-wrap .active {\n  background: #5176f3;\n  border-radius: 30px;\n}\nion-content .term-content .persona-wrap .active h6 {\n  color: #fff;\n}\nion-content .term-content .persona-wrap .active p {\n  color: #fff;\n}\nion-content .term-content .persona-wrap .active .checking-icon #check {\n  display: block;\n  color: #fff;\n  font-size: 34px;\n}\nion-content .term-content .persona-wrap .active .checking-icon #circle {\n  display: none;\n}\nion-content .term-content .persona-wrap .active .user-icon ion-icon {\n  border: 2px solid #fff;\n  color: #fff;\n}\nion-content .term-content .btn-wrap {\n  text-align: right;\n}\nion-content .term-content .btn-wrap ion-button {\n  width: 44% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVjb25vY2UvZW52aWFkby9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXHJlY29ub2NlXFxlbnZpYWRvXFxlbnZpYWRvLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcmVjb25vY2UvZW52aWFkby9lbnZpYWRvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FDQ0Y7QURBRTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsK0NBQUE7QUNFSjtBRERJO0VBQ0UsZUFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ0dOO0FEREk7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7QUNHTjtBRERJO0VBQ0UsbUJBQUE7QUNHTjtBREZNO0VBQ0Usd0RBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FDSVI7QURIUTtFQUNFLGNBQUE7QUNLVjtBREpVO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQ01aO0FEQU07RUFDRSwyQkFBQTtBQ0VSO0FERFE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDR1Y7QUREUTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNHVjtBREZVO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FDSVo7QURHUTtFQUNFLGVBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNEVjtBREdRO0VBQ0MsU0FBQTtFQUNDLGNBQUE7RUFDQSxlQUFBO0FDRFY7QURLWTtFQUNFLGVBQUE7QUNIZDtBRE9RO0VBQ0Usa0JBQUE7QUNMVjtBRE1VO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FDSlo7QURNVTtFQUNFLGFBQUE7QUNKWjtBRE9RO0VBQ0Usa0JBQUE7QUNMVjtBRE1VO0VBQ0UsZUFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7QUNKWjtBRFFNO0VBQ0UsbUJBQUE7RUFDQSxtQkFBQTtBQ05SO0FET1E7RUFDRSxXQUFBO0FDTFY7QURPUTtFQUNFLFdBQUE7QUNMVjtBRFFVO0VBQ0UsY0FBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FDTlo7QURRVTtFQUNFLGFBQUE7QUNOWjtBRFVVO0VBQ0Usc0JBQUE7RUFDQSxXQUFBO0FDUlo7QURhSTtFQUNFLGlCQUFBO0FDWE47QURZTTtFQUNFLHFCQUFBO0FDVlIiLCJmaWxlIjoic3JjL2FwcC9yZWNvbm9jZS9lbnZpYWRvL2VudmlhZG8ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcclxuICAudGVybS1jb250ZW50IHtcclxuICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICBwYWRkaW5nOiAyMHB4IDIycHg7XHJcbiAgICBtYXJnaW46IDE2cHggMjBweCAyMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIGJveC1zaGFkb3c6IDAgN3B4IDE2cHggLTdweCByZ2JhKDAsIDAsIDAsIDAuNjkpO1xyXG4gICAgaDUge1xyXG4gICAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDZweDtcclxuICAgICAgY29sb3I6ICMyYzU1ZTA7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICB9XHJcbiAgICBoNCB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTdweDtcclxuICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgIH1cclxuICAgIC5zZWFyY2gtYXJlYXtcclxuICAgICAgbWFyZ2luOiAxNnB4IDAgMjJweDtcclxuICAgICAgLmNvbnRlbnQtc2VhcmNoIHtcclxuICAgICAgICBib3gtc2hhZG93OiBpbnNldCAwIDJweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yNTg4MjM1Mjk0MTE3NjQ3Myk7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgICAgICBwYWRkaW5nOiAxNXB4IDIycHg7XHJcbiAgICAgICAgc3BhbiB7XHJcbiAgICAgICAgICBjb2xvcjogIzhjOGI4YjtcclxuICAgICAgICAgIGltZyB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogYm90dG9tO1xyXG4gICAgICAgICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpb24tbGlzdCB7XHJcbiAgICAgIGlvbi1pdGVtIHtcclxuICAgICAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgaW9uLXJhZGlvIHtcclxuICAgICAgICAgIG1hcmdpbi1yaWdodDogMTJweDtcclxuICAgICAgICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgICAgICAgaGVpZ2h0OiAzMHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgICAgY29sb3I6ICMyYzU1ZTA7XHJcbiAgICAgICAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgc3BhbiB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDEwMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5wZXJzb25hLXdyYXAge1xyXG4gICAgICAuc2luZ2xlLWl0ZW0ge1xyXG4gICAgICAgIGg2IHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICAgIG1hcmdpbjogMCAwIDRweDtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHAge1xyXG4gICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICBjb2xvcjogIzkwOGY4ZjtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaW9uLXJvdyB7XHJcbiAgICAgICAgICBpb24tY29sIHtcclxuICAgICAgICAgICAgJjpudGgtY2hpbGQoMSkge1xyXG4gICAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAuY2hlY2tpbmctaWNvbiB7XHJcbiAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMzhweDtcclxuICAgICAgICAgICAgY29sb3I6ICM1MTc2ZjM7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDNweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgICNjaGVjayB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC51c2VyLWljb24ge1xyXG4gICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkICNhY2JjZWY7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgICAgcGFkZGluZzogNXB4O1xyXG4gICAgICAgICAgICBjb2xvcjogI2FjYmNlZjtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAuYWN0aXZlIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICAgICAgaDYge1xyXG4gICAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHAge1xyXG4gICAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5jaGVja2luZy1pY29uIHtcclxuICAgICAgICAgICNjaGVjayB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAzNHB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgI2NpcmNsZSB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC51c2VyLWljb24ge1xyXG4gICAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgICBib3JkZXI6IDJweCBzb2xpZCAjZmZmO1xyXG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5idG4td3JhcCB7XHJcbiAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogNDQlIWltcG9ydGFudDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBwYWRkaW5nOiAyMHB4IDIycHg7XG4gIG1hcmdpbjogMTZweCAyMHB4IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIGJveC1zaGFkb3c6IDAgN3B4IDE2cHggLTdweCByZ2JhKDAsIDAsIDAsIDAuNjkpO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBoNSB7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBjb2xvcjogIzJjNTVlMDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaDQge1xuICBmb250LXNpemU6IDE3cHg7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5zZWFyY2gtYXJlYSB7XG4gIG1hcmdpbjogMTZweCAwIDIycHg7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5zZWFyY2gtYXJlYSAuY29udGVudC1zZWFyY2gge1xuICBib3gtc2hhZG93OiBpbnNldCAwIDJweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yNTg4MjM1Mjk0KTtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgcGFkZGluZzogMTVweCAyMnB4O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCAuc2VhcmNoLWFyZWEgLmNvbnRlbnQtc2VhcmNoIHNwYW4ge1xuICBjb2xvcjogIzhjOGI4Yjtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgLnNlYXJjaC1hcmVhIC5jb250ZW50LXNlYXJjaCBzcGFuIGltZyB7XG4gIHdpZHRoOiAyMHB4O1xuICB2ZXJ0aWNhbC1hbGlnbjogYm90dG9tO1xuICBmbG9hdDogcmlnaHQ7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGlvbi1saXN0IGlvbi1pdGVtIHtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBpb24tbGlzdCBpb24taXRlbSBpb24tcmFkaW8ge1xuICBtYXJnaW4tcmlnaHQ6IDEycHg7XG4gIHdpZHRoOiAzMHB4O1xuICBoZWlnaHQ6IDMwcHg7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGlvbi1saXN0IGlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gIGNvbG9yOiAjMmM1NWUwO1xuICBmb250LXNpemU6IDE3cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGlvbi1saXN0IGlvbi1pdGVtIGlvbi1sYWJlbCBzcGFuIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBmb250LXdlaWdodDogMTAwO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCAucGVyc29uYS13cmFwIC5zaW5nbGUtaXRlbSBoNiB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbWFyZ2luOiAwIDAgNHB4O1xuICBmb250LXdlaWdodDogNjAwO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCAucGVyc29uYS13cmFwIC5zaW5nbGUtaXRlbSBwIHtcbiAgbWFyZ2luOiAwO1xuICBjb2xvcjogIzkwOGY4ZjtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCAucGVyc29uYS13cmFwIC5zaW5nbGUtaXRlbSBpb24tcm93IGlvbi1jb2w6bnRoLWNoaWxkKDEpIHtcbiAgcGFkZGluZy1sZWZ0OiAwO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCAucGVyc29uYS13cmFwIC5zaW5nbGUtaXRlbSAuY2hlY2tpbmctaWNvbiB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgLnBlcnNvbmEtd3JhcCAuc2luZ2xlLWl0ZW0gLmNoZWNraW5nLWljb24gaW9uLWljb24ge1xuICBmb250LXNpemU6IDM4cHg7XG4gIGNvbG9yOiAjNTE3NmYzO1xuICBtYXJnaW4tdG9wOiAzcHg7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5wZXJzb25hLXdyYXAgLnNpbmdsZS1pdGVtIC5jaGVja2luZy1pY29uICNjaGVjayB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5wZXJzb25hLXdyYXAgLnNpbmdsZS1pdGVtIC51c2VyLWljb24ge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5wZXJzb25hLXdyYXAgLnNpbmdsZS1pdGVtIC51c2VyLWljb24gaW9uLWljb24ge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGJvcmRlcjogMnB4IHNvbGlkICNhY2JjZWY7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgcGFkZGluZzogNXB4O1xuICBjb2xvcjogI2FjYmNlZjtcbiAgbWFyZ2luLXRvcDogNXB4O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCAucGVyc29uYS13cmFwIC5hY3RpdmUge1xuICBiYWNrZ3JvdW5kOiAjNTE3NmYzO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCAucGVyc29uYS13cmFwIC5hY3RpdmUgaDYge1xuICBjb2xvcjogI2ZmZjtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgLnBlcnNvbmEtd3JhcCAuYWN0aXZlIHAge1xuICBjb2xvcjogI2ZmZjtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgLnBlcnNvbmEtd3JhcCAuYWN0aXZlIC5jaGVja2luZy1pY29uICNjaGVjayB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAzNHB4O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCAucGVyc29uYS13cmFwIC5hY3RpdmUgLmNoZWNraW5nLWljb24gI2NpcmNsZSB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5wZXJzb25hLXdyYXAgLmFjdGl2ZSAudXNlci1pY29uIGlvbi1pY29uIHtcbiAgYm9yZGVyOiAycHggc29saWQgI2ZmZjtcbiAgY29sb3I6ICNmZmY7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5idG4td3JhcCB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCAuYnRuLXdyYXAgaW9uLWJ1dHRvbiB7XG4gIHdpZHRoOiA0NCUgIWltcG9ydGFudDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/reconoce/enviado/enviado.page.ts":
  /*!**************************************************!*\
    !*** ./src/app/reconoce/enviado/enviado.page.ts ***!
    \**************************************************/

  /*! exports provided: EnviadoPage */

  /***/
  function srcAppReconoceEnviadoEnviadoPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EnviadoPage", function () {
      return EnviadoPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var EnviadoPage = /*#__PURE__*/function () {
      function EnviadoPage(router, menuCtrl) {
        _classCallCheck(this, EnviadoPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
        this.list = [{
          name: 'Danny L. Wells',
          designation: 'CFO | Management'
        }, {
          name: 'Jacqueline R. Waxman',
          designation: 'CFO | Management'
        }, {
          name: 'Danny L. Wells',
          designation: 'CFO | Management'
        }, {
          name: 'Dan D. Kean',
          designation: 'RH'
        }];
      }

      _createClass(EnviadoPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "select",
        value: function select(item) {
          this.selected = item;
        }
      }, {
        key: "isActive",
        value: function isActive(item) {
          return this.selected === item;
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "reconomain",
        value: function reconomain() {
          this.router.navigateByUrl('/reconomain');
        }
      }]);

      return EnviadoPage;
    }();

    EnviadoPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    EnviadoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-enviado',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./enviado.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/reconoce/enviado/enviado.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./enviado.page.scss */
      "./src/app/reconoce/enviado/enviado.page.scss"))["default"]]
    })], EnviadoPage);
    /***/
  }
}]);
//# sourceMappingURL=reconoce-enviado-enviado-module-es5.js.map