(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cupones-cupoerror-cupoerror-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cupones/cupoerror/cupoerror.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cupones/cupoerror/cupoerror.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"secondary\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Cupones</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <div class=\"img-area\">\n      <img src=\"assets/imgs/cupon/cupon-1.png\" alt=\"\">\n    </div>\n    <div class=\"content-area\">\n      <p>¡Canjea tu cupón para recibir premios geniales!</p>\n      <ion-list>\n        <span>Código no válido</span>\n        <ion-item class=\"ion-no-padding\">\n          <ion-input value=\"YUQ8 - 7YTGL10 - 8103900\"></ion-input>\n        </ion-item>\n      </ion-list>\n    </div>\n  </div>\n</ion-content>\n\n<ion-footer>\n  <ion-button (click)=\"PageRoute('servicios')\">Enviar</ion-button>\n</ion-footer>\n");

/***/ }),

/***/ "./src/app/cupones/cupoerror/cupoerror-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/cupones/cupoerror/cupoerror-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: CupoerrorPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CupoerrorPageRoutingModule", function() { return CupoerrorPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _cupoerror_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./cupoerror.page */ "./src/app/cupones/cupoerror/cupoerror.page.ts");




const routes = [
    {
        path: '',
        component: _cupoerror_page__WEBPACK_IMPORTED_MODULE_3__["CupoerrorPage"]
    }
];
let CupoerrorPageRoutingModule = class CupoerrorPageRoutingModule {
};
CupoerrorPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CupoerrorPageRoutingModule);



/***/ }),

/***/ "./src/app/cupones/cupoerror/cupoerror.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/cupones/cupoerror/cupoerror.module.ts ***!
  \*******************************************************/
/*! exports provided: CupoerrorPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CupoerrorPageModule", function() { return CupoerrorPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _cupoerror_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./cupoerror-routing.module */ "./src/app/cupones/cupoerror/cupoerror-routing.module.ts");
/* harmony import */ var _cupoerror_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./cupoerror.page */ "./src/app/cupones/cupoerror/cupoerror.page.ts");







let CupoerrorPageModule = class CupoerrorPageModule {
};
CupoerrorPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _cupoerror_routing_module__WEBPACK_IMPORTED_MODULE_5__["CupoerrorPageRoutingModule"]
        ],
        declarations: [_cupoerror_page__WEBPACK_IMPORTED_MODULE_6__["CupoerrorPage"]]
    })
], CupoerrorPageModule);



/***/ }),

/***/ "./src/app/cupones/cupoerror/cupoerror.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/cupones/cupoerror/cupoerror.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-title {\n  font-weight: 600;\n}\nion-header ion-buttons {\n  margin-left: 20px;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.ion-padding {\n  padding: 16px 20px;\n}\n.img-area {\n  text-align: center;\n}\n.img-area img {\n  width: 230px;\n}\n.content-area p {\n  color: #565656;\n  margin-top: 4px;\n  margin-bottom: 20px;\n}\n.content-area ion-list {\n  position: relative;\n}\n.content-area ion-list span {\n  color: #FB4F33;\n  font-family: \"Lato\", sans-serif;\n  position: absolute;\n  z-index: 9;\n  background: #fff;\n  top: -2px;\n  left: 28px;\n  padding: 0 7px;\n}\n.content-area ion-list ion-item {\n  --border-color: transparent;\n  border: 2px solid #FB4F33;\n  border-radius: 30px;\n  padding: 0 20px;\n  --min-height: 50px;\n  color: #FB4F33;\n}\nion-footer {\n  text-align: right;\n  padding: 16px 20px;\n}\nion-footer:before {\n  background-image: none;\n}\nion-footer ion-button {\n  margin: 0;\n  width: 42% !important;\n  height: 3.4rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3Vwb25lcy9jdXBvZXJyb3IvRzpcXGlvbmljXFxGSVZFUlJcXHBhbnRhbGxhcy1wYWNvL3NyY1xcYXBwXFxjdXBvbmVzXFxjdXBvZXJyb3JcXGN1cG9lcnJvci5wYWdlLnNjc3MiLCJzcmMvYXBwL2N1cG9uZXMvY3Vwb2Vycm9yL2N1cG9lcnJvci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxnQkFBQTtBQ0FKO0FERUU7RUFDRSxpQkFBQTtBQ0FKO0FER0k7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQ0ROO0FES0E7RUFDRSxrQkFBQTtBQ0ZGO0FESUE7RUFDRSxrQkFBQTtBQ0RGO0FERUU7RUFDRSxZQUFBO0FDQUo7QURJRTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7QUNESjtBREdFO0VBQ0Usa0JBQUE7QUNESjtBREVJO0VBQ0UsY0FBQTtFQUNBLCtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLGNBQUE7QUNBTjtBREVJO0VBQ0UsMkJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQ0FOO0FESUE7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0FDREY7QURFRTtFQUNFLHNCQUFBO0FDQUo7QURFRTtFQUNFLFNBQUE7RUFDQSxxQkFBQTtFQUNBLGNBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL2N1cG9uZXMvY3Vwb2Vycm9yL2N1cG9lcnJvci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tdGl0bGUge1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB9XHJcbiAgaW9uLWJ1dHRvbnMge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgfVxyXG4gIC5idG4tcmlnaHQge1xyXG4gICAgLmFsZXJ0LXRhZyB7XHJcbiAgICAgIHdpZHRoOiAxMnB4O1xyXG4gICAgICBoZWlnaHQ6IDEycHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNmYjRmMzM7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgcmlnaHQ6IC0zcHg7XHJcbiAgICAgIGJvdHRvbTogLTJweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuLmlvbi1wYWRkaW5nIHtcclxuICBwYWRkaW5nOiAxNnB4IDIwcHg7XHJcbn1cclxuLmltZy1hcmVhIHtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgaW1nIHtcclxuICAgIHdpZHRoOiAyMzBweDtcclxuICB9XHJcbn1cclxuLmNvbnRlbnQtYXJlYSB7XHJcbiAgcCB7XHJcbiAgICBjb2xvcjogIzU2NTY1NjtcclxuICAgIG1hcmdpbi10b3A6IDRweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbiAgfVxyXG4gIGlvbi1saXN0IHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHNwYW4ge1xyXG4gICAgICBjb2xvcjogI0ZCNEYzMztcclxuICAgICAgZm9udC1mYW1pbHk6IFwiTGF0b1wiLCBzYW5zLXNlcmlmO1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgIHotaW5kZXg6IDk7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgIHRvcDogLTJweDtcclxuICAgICAgbGVmdDogMjhweDtcclxuICAgICAgcGFkZGluZzogMCA3cHg7XHJcbiAgICB9XHJcbiAgICBpb24taXRlbSB7XHJcbiAgICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgYm9yZGVyOiAycHggc29saWQgI0ZCNEYzMztcclxuICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgICAgcGFkZGluZzogMCAyMHB4O1xyXG4gICAgICAtLW1pbi1oZWlnaHQ6IDUwcHg7XHJcbiAgICAgIGNvbG9yOiAjRkI0RjMzO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5pb24tZm9vdGVyIHtcclxuICB0ZXh0LWFsaWduOiByaWdodDtcclxuICBwYWRkaW5nOiAxNnB4IDIwcHg7XHJcbiAgJjpiZWZvcmUge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcclxuICB9XHJcbiAgaW9uLWJ1dHRvbiB7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICB3aWR0aDogNDIlIWltcG9ydGFudDtcclxuICAgIGhlaWdodDogMy40cmVtO1xyXG4gIH1cclxufSIsImlvbi1oZWFkZXIgaW9uLXRpdGxlIHtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbmlvbi1oZWFkZXIgaW9uLWJ1dHRvbnMge1xuICBtYXJnaW4tbGVmdDogMjBweDtcbn1cbmlvbi1oZWFkZXIgLmJ0bi1yaWdodCAuYWxlcnQtdGFnIHtcbiAgd2lkdGg6IDEycHg7XG4gIGhlaWdodDogMTJweDtcbiAgYmFja2dyb3VuZDogI2ZiNGYzMztcbiAgZGlzcGxheTogYmxvY2s7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogLTNweDtcbiAgYm90dG9tOiAtMnB4O1xufVxuXG4uaW9uLXBhZGRpbmcge1xuICBwYWRkaW5nOiAxNnB4IDIwcHg7XG59XG5cbi5pbWctYXJlYSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5pbWctYXJlYSBpbWcge1xuICB3aWR0aDogMjMwcHg7XG59XG5cbi5jb250ZW50LWFyZWEgcCB7XG4gIGNvbG9yOiAjNTY1NjU2O1xuICBtYXJnaW4tdG9wOiA0cHg7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG4uY29udGVudC1hcmVhIGlvbi1saXN0IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLmNvbnRlbnQtYXJlYSBpb24tbGlzdCBzcGFuIHtcbiAgY29sb3I6ICNGQjRGMzM7XG4gIGZvbnQtZmFtaWx5OiBcIkxhdG9cIiwgc2Fucy1zZXJpZjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiA5O1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICB0b3A6IC0ycHg7XG4gIGxlZnQ6IDI4cHg7XG4gIHBhZGRpbmc6IDAgN3B4O1xufVxuLmNvbnRlbnQtYXJlYSBpb24tbGlzdCBpb24taXRlbSB7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgYm9yZGVyOiAycHggc29saWQgI0ZCNEYzMztcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgcGFkZGluZzogMCAyMHB4O1xuICAtLW1pbi1oZWlnaHQ6IDUwcHg7XG4gIGNvbG9yOiAjRkI0RjMzO1xufVxuXG5pb24tZm9vdGVyIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIHBhZGRpbmc6IDE2cHggMjBweDtcbn1cbmlvbi1mb290ZXI6YmVmb3JlIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn1cbmlvbi1mb290ZXIgaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbjogMDtcbiAgd2lkdGg6IDQyJSAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDMuNHJlbTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/cupones/cupoerror/cupoerror.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/cupones/cupoerror/cupoerror.page.ts ***!
  \*****************************************************/
/*! exports provided: CupoerrorPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CupoerrorPage", function() { return CupoerrorPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let CupoerrorPage = class CupoerrorPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
};
CupoerrorPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
CupoerrorPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-cupoerror',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./cupoerror.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cupones/cupoerror/cupoerror.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./cupoerror.page.scss */ "./src/app/cupones/cupoerror/cupoerror.page.scss")).default]
    })
], CupoerrorPage);



/***/ })

}]);
//# sourceMappingURL=cupones-cupoerror-cupoerror-module-es2015.js.map