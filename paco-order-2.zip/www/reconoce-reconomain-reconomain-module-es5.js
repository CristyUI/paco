function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["reconoce-reconomain-reconomain-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/reconoce/reconomain/reconomain.page.html":
  /*!************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/reconoce/reconomain/reconomain.page.html ***!
    \************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppReconoceReconomainReconomainPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"secondary\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Pago de servicio</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <div class=\"top-area\">\n     <h4>Sagittis ultricies quam nisl</h4>\n    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Erat facilisis facilisis laoreet euismod.</p>\n  </div>\n\n  <ion-slides pager=\"false\" [options]=\"slideOpts\">\n    <ion-slide>\n      <img src=\"assets/imgs/reconoce/s-1.png\">\n      <h6>Excelencia</h6>\n    </ion-slide>\n    <ion-slide>\n      <img src=\"assets/imgs/reconoce/s-2.png\">\n      <h6>Perseverancia</h6>\n    </ion-slide>\n    <ion-slide>\n      <img src=\"assets/imgs/reconoce/s-3.png\">\n      <h6>Adaptación al cambio</h6>\n    </ion-slide>\n    <ion-slide>\n      <img src=\"assets/imgs/reconoce/s-1.png\">\n      <h6>Excelencia</h6>\n    </ion-slide>\n    <ion-slide>\n      <img src=\"assets/imgs/reconoce/s-2.png\">\n      <h6>Perseverancia</h6>\n    </ion-slide>\n    <ion-slide>\n      <img src=\"assets/imgs/reconoce/s-3.png\">\n      <h6>Adaptación al cambio</h6>\n    </ion-slide>\n  </ion-slides>\n\n  <div class=\"bottom-area\">\n    <h4>Sagittis ultricies quam nisl</h4>\n    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Erat facilisis facilisis laoreet euismod.</p>\n    <div class=\"text-edit\" (click)=\"PageRoute('enviado')\">\n      <p>¿A quíen le envías este reconocimiento?</p>\n    </div>\n    <ion-list>\n      <ion-item class=\"ion-no-padding\">\n        <ion-textarea placeholder=\"¿Por qué le das este reconocimiento?\"></ion-textarea>\n      </ion-item>\n    </ion-list>\n    <div class=\"btn-wrap\">\n      <ion-button (click)=\"PageRoute('usuario')\">Continuar</ion-button>\n    </div>\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/reconoce/reconomain/reconomain-routing.module.ts":
  /*!******************************************************************!*\
    !*** ./src/app/reconoce/reconomain/reconomain-routing.module.ts ***!
    \******************************************************************/

  /*! exports provided: ReconomainPageRoutingModule */

  /***/
  function srcAppReconoceReconomainReconomainRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReconomainPageRoutingModule", function () {
      return ReconomainPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _reconomain_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./reconomain.page */
    "./src/app/reconoce/reconomain/reconomain.page.ts");

    var routes = [{
      path: '',
      component: _reconomain_page__WEBPACK_IMPORTED_MODULE_3__["ReconomainPage"]
    }];

    var ReconomainPageRoutingModule = function ReconomainPageRoutingModule() {
      _classCallCheck(this, ReconomainPageRoutingModule);
    };

    ReconomainPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ReconomainPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/reconoce/reconomain/reconomain.module.ts":
  /*!**********************************************************!*\
    !*** ./src/app/reconoce/reconomain/reconomain.module.ts ***!
    \**********************************************************/

  /*! exports provided: ReconomainPageModule */

  /***/
  function srcAppReconoceReconomainReconomainModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReconomainPageModule", function () {
      return ReconomainPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _reconomain_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./reconomain-routing.module */
    "./src/app/reconoce/reconomain/reconomain-routing.module.ts");
    /* harmony import */


    var _reconomain_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./reconomain.page */
    "./src/app/reconoce/reconomain/reconomain.page.ts");

    var ReconomainPageModule = function ReconomainPageModule() {
      _classCallCheck(this, ReconomainPageModule);
    };

    ReconomainPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _reconomain_routing_module__WEBPACK_IMPORTED_MODULE_5__["ReconomainPageRoutingModule"]],
      declarations: [_reconomain_page__WEBPACK_IMPORTED_MODULE_6__["ReconomainPage"]]
    })], ReconomainPageModule);
    /***/
  },

  /***/
  "./src/app/reconoce/reconomain/reconomain.page.scss":
  /*!**********************************************************!*\
    !*** ./src/app/reconoce/reconomain/reconomain.page.scss ***!
    \**********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppReconoceReconomainReconomainPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header ion-title {\n  font-weight: 600;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\nh4 {\n  font-size: 17px;\n  font-weight: 700;\n}\n.top-area {\n  padding: 16px 18px;\n}\nion-slides ion-slide {\n  display: block;\n}\nion-slides ion-slide h6 {\n  font-size: 15px;\n  margin: 5px 0 3px;\n}\n.bottom-area {\n  padding: 16px 18px;\n}\n.bottom-area .text-edit {\n  margin-top: 5px;\n}\n.bottom-area .text-edit p {\n  border: 1px solid #5176f3;\n  padding: 12px 18px;\n  border-radius: 30px;\n  color: #5176f3;\n}\nion-list {\n  padding-top: 0;\n}\nion-list ion-item {\n  --border-color: transparent;\n  font-size: 15px;\n  color: #000000;\n  border: 1px solid #718be4;\n  --min-height: 32px;\n  padding: 4px 14px;\n  margin: 3px 0;\n  border-radius: 30px;\n  font-weight: 600;\n  --background: transparent;\n}\nion-list ion-textarea {\n  height: 88px;\n  margin: 0;\n  padding: 0 10px;\n}\n.btn-wrap {\n  text-align: right;\n}\n.btn-wrap ion-button {\n  width: 44% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVjb25vY2UvcmVjb25vbWFpbi9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXHJlY29ub2NlXFxyZWNvbm9tYWluXFxyZWNvbm9tYWluLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcmVjb25vY2UvcmVjb25vbWFpbi9yZWNvbm9tYWluLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGdCQUFBO0FDQUo7QURHSTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDRE47QURLQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQ0ZGO0FESUE7RUFDRSxrQkFBQTtBQ0RGO0FESUU7RUFDRSxjQUFBO0FDREo7QURFSTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtBQ0FOO0FESUE7RUFDRSxrQkFBQTtBQ0RGO0FERUU7RUFDRSxlQUFBO0FDQUo7QURDSTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7QUNDTjtBREdBO0VBQ0UsY0FBQTtBQ0FGO0FEQ0U7RUFDRSwyQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtBQ0NKO0FEQ0U7RUFDRSxZQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7QUNDSjtBREVBO0VBQ0UsaUJBQUE7QUNDRjtBREFFO0VBQ0UscUJBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL3JlY29ub2NlL3JlY29ub21haW4vcmVjb25vbWFpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tdGl0bGUge1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB9XHJcbiAgLmJ0bi1yaWdodCB7XHJcbiAgICAuYWxlcnQtdGFnIHtcclxuICAgICAgd2lkdGg6IDEycHg7XHJcbiAgICAgIGhlaWdodDogMTJweDtcclxuICAgICAgYmFja2dyb3VuZDogI2ZiNGYzMztcclxuICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICByaWdodDogLTNweDtcclxuICAgICAgYm90dG9tOiAtMnB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5oNCB7XHJcbiAgZm9udC1zaXplOiAxN3B4O1xyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbn1cclxuLnRvcC1hcmVhIHtcclxuICBwYWRkaW5nOiAxNnB4IDE4cHg7XHJcbn1cclxuaW9uLXNsaWRlcyB7XHJcbiAgaW9uLXNsaWRlIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgaDYge1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgIG1hcmdpbjogNXB4IDAgM3B4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4uYm90dG9tLWFyZWEge1xyXG4gIHBhZGRpbmc6IDE2cHggMThweDtcclxuICAudGV4dC1lZGl0IHtcclxuICAgIG1hcmdpbi10b3A6IDVweDtcclxuICAgIHAge1xyXG4gICAgICBib3JkZXI6IDFweCBzb2xpZCAjNTE3NmYzO1xyXG4gICAgICBwYWRkaW5nOiAxMnB4IDE4cHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICAgIGNvbG9yOiAjNTE3NmYzO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5pb24tbGlzdCB7XHJcbiAgcGFkZGluZy10b3A6IDA7XHJcbiAgaW9uLWl0ZW0ge1xyXG4gICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgY29sb3I6ICMwMDAwMDA7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjNzE4YmU0O1xyXG4gICAgLS1taW4taGVpZ2h0OiAzMnB4O1xyXG4gICAgcGFkZGluZzogNHB4IDE0cHg7XHJcbiAgICBtYXJnaW46IDNweCAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gIH1cclxuICBpb24tdGV4dGFyZWEge1xyXG4gICAgaGVpZ2h0OiA4OHB4O1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgcGFkZGluZzogMCAxMHB4O1xyXG4gIH1cclxufVxyXG4uYnRuLXdyYXAge1xyXG4gIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gIGlvbi1idXR0b24ge1xyXG4gICAgd2lkdGg6IDQ0JSFpbXBvcnRhbnQ7XHJcbiAgfVxyXG59IiwiaW9uLWhlYWRlciBpb24tdGl0bGUge1xuICBmb250LXdlaWdodDogNjAwO1xufVxuaW9uLWhlYWRlciAuYnRuLXJpZ2h0IC5hbGVydC10YWcge1xuICB3aWR0aDogMTJweDtcbiAgaGVpZ2h0OiAxMnB4O1xuICBiYWNrZ3JvdW5kOiAjZmI0ZjMzO1xuICBkaXNwbGF5OiBibG9jaztcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAtM3B4O1xuICBib3R0b206IC0ycHg7XG59XG5cbmg0IHtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBmb250LXdlaWdodDogNzAwO1xufVxuXG4udG9wLWFyZWEge1xuICBwYWRkaW5nOiAxNnB4IDE4cHg7XG59XG5cbmlvbi1zbGlkZXMgaW9uLXNsaWRlIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5pb24tc2xpZGVzIGlvbi1zbGlkZSBoNiB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWFyZ2luOiA1cHggMCAzcHg7XG59XG5cbi5ib3R0b20tYXJlYSB7XG4gIHBhZGRpbmc6IDE2cHggMThweDtcbn1cbi5ib3R0b20tYXJlYSAudGV4dC1lZGl0IHtcbiAgbWFyZ2luLXRvcDogNXB4O1xufVxuLmJvdHRvbS1hcmVhIC50ZXh0LWVkaXQgcCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICM1MTc2ZjM7XG4gIHBhZGRpbmc6IDEycHggMThweDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgY29sb3I6ICM1MTc2ZjM7XG59XG5cbmlvbi1saXN0IHtcbiAgcGFkZGluZy10b3A6IDA7XG59XG5pb24tbGlzdCBpb24taXRlbSB7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBjb2xvcjogIzAwMDAwMDtcbiAgYm9yZGVyOiAxcHggc29saWQgIzcxOGJlNDtcbiAgLS1taW4taGVpZ2h0OiAzMnB4O1xuICBwYWRkaW5nOiA0cHggMTRweDtcbiAgbWFyZ2luOiAzcHggMDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbmlvbi1saXN0IGlvbi10ZXh0YXJlYSB7XG4gIGhlaWdodDogODhweDtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwIDEwcHg7XG59XG5cbi5idG4td3JhcCB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuLmJ0bi13cmFwIGlvbi1idXR0b24ge1xuICB3aWR0aDogNDQlICFpbXBvcnRhbnQ7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/reconoce/reconomain/reconomain.page.ts":
  /*!********************************************************!*\
    !*** ./src/app/reconoce/reconomain/reconomain.page.ts ***!
    \********************************************************/

  /*! exports provided: ReconomainPage */

  /***/
  function srcAppReconoceReconomainReconomainPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReconomainPage", function () {
      return ReconomainPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var ReconomainPage = /*#__PURE__*/function () {
      function ReconomainPage(router, menuCtrl) {
        _classCallCheck(this, ReconomainPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
        this.slideOpts = {
          initialSlide: 5,
          speed: 800,
          autoplay: false,
          slidesPerView: 3,
          spaceBetween: 28
        };
      }

      _createClass(ReconomainPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "PageRoute",
        value: function PageRoute(urlSlug) {
          this.router.navigateByUrl('/' + urlSlug);
        }
      }]);

      return ReconomainPage;
    }();

    ReconomainPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    ReconomainPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-reconomain',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./reconomain.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/reconoce/reconomain/reconomain.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./reconomain.page.scss */
      "./src/app/reconoce/reconomain/reconomain.page.scss"))["default"]]
    })], ReconomainPage);
    /***/
  }
}]);
//# sourceMappingURL=reconoce-reconomain-reconomain-module-es5.js.map