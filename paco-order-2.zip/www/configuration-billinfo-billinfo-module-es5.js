function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["configuration-billinfo-billinfo-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/billinfo/billinfo.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/billinfo/billinfo.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppConfigurationBillinfoBillinfoPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"secondary\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Cambiar contraseña</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <img src=\"assets/imgs/configuration/bill.png\" alt=\"\">\n    <p>Usarás tu contraseña para ingresar a la app.</p>\n    <ion-list>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"{{type}}\" placeholder=\"Contraseña actual\"></ion-input>\n        <button *ngIf=\"!showPass\" type=\"button\" class=\"eye-btn\" (click)=\"showPassword()\">\n          <ion-icon name=\"eye-outline\"></ion-icon>\n        </button>\n        <button *ngIf=\"showPass\" type=\"button\" class=\"eye-btn\" (click)=\"showPassword()\">\n          <ion-icon name=\"eye-off-outline\"></ion-icon>\n        </button>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"{{type}}\" placeholder=\"Nueva contraseña\"></ion-input>\n        <button *ngIf=\"!showPass\" type=\"button\" class=\"eye-btn\" (click)=\"showPassword()\">\n          <ion-icon name=\"eye-outline\"></ion-icon>\n        </button>\n        <button *ngIf=\"showPass\" type=\"button\" class=\"eye-btn\" (click)=\"showPassword()\">\n          <ion-icon name=\"eye-off-outline\"></ion-icon>\n        </button>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"{{type}}\" placeholder=\"Confirmar contraseña\"></ion-input>\n        <button *ngIf=\"!showPass\" type=\"button\" class=\"eye-btn\" (click)=\"showPassword()\">\n          <ion-icon name=\"eye-outline\"></ion-icon>\n        </button>\n        <button *ngIf=\"showPass\" type=\"button\" class=\"eye-btn\" (click)=\"showPassword()\">\n          <ion-icon name=\"eye-off-outline\"></ion-icon>\n        </button>\n      </ion-item>\n    </ion-list>\n    <div class=\"btn-wrap\">\n      <ion-button (click)=\"PageRoute('cuentas')\">Guardar</ion-button>\n    </div>\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/configuration/billinfo/billinfo-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/configuration/billinfo/billinfo-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: BillinfoPageRoutingModule */

  /***/
  function srcAppConfigurationBillinfoBillinfoRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BillinfoPageRoutingModule", function () {
      return BillinfoPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _billinfo_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./billinfo.page */
    "./src/app/configuration/billinfo/billinfo.page.ts");

    var routes = [{
      path: '',
      component: _billinfo_page__WEBPACK_IMPORTED_MODULE_3__["BillinfoPage"]
    }];

    var BillinfoPageRoutingModule = function BillinfoPageRoutingModule() {
      _classCallCheck(this, BillinfoPageRoutingModule);
    };

    BillinfoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], BillinfoPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/configuration/billinfo/billinfo.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/configuration/billinfo/billinfo.module.ts ***!
    \***********************************************************/

  /*! exports provided: BillinfoPageModule */

  /***/
  function srcAppConfigurationBillinfoBillinfoModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BillinfoPageModule", function () {
      return BillinfoPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _billinfo_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./billinfo-routing.module */
    "./src/app/configuration/billinfo/billinfo-routing.module.ts");
    /* harmony import */


    var _billinfo_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./billinfo.page */
    "./src/app/configuration/billinfo/billinfo.page.ts");

    var BillinfoPageModule = function BillinfoPageModule() {
      _classCallCheck(this, BillinfoPageModule);
    };

    BillinfoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _billinfo_routing_module__WEBPACK_IMPORTED_MODULE_5__["BillinfoPageRoutingModule"]],
      declarations: [_billinfo_page__WEBPACK_IMPORTED_MODULE_6__["BillinfoPage"]]
    })], BillinfoPageModule);
    /***/
  },

  /***/
  "./src/app/configuration/billinfo/billinfo.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/configuration/billinfo/billinfo.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppConfigurationBillinfoBillinfoPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header ion-title {\n  font-weight: 600;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.ion-padding {\n  text-align: center;\n}\n.ion-padding img {\n  margin: 0 0 10px;\n  width: 210px;\n}\n.ion-padding p {\n  margin-top: 0;\n  color: #757373;\n  margin-bottom: 4px;\n  text-align: left;\n  padding: 0 6px;\n}\n.ion-padding ion-list {\n  margin: 16px 2px 0;\n  background: transparent;\n}\n.ion-padding ion-list ion-item {\n  --background: transparent;\n  margin-bottom: 12px;\n  --border-color: transparent;\n  border: 1px solid #7692f1;\n  border-radius: 30px;\n  --min-height: 44px;\n  padding-left: 4px;\n}\n.ion-padding ion-list ion-item ion-input {\n  font-size: 16px;\n  --padding-start: 14px;\n}\n.ion-padding ion-list ion-item ion-input::-moz-placeholder {\n  color: #2c55e0;\n}\n.ion-padding ion-list ion-item ion-input::-ms-input-placeholder {\n  color: #2c55e0;\n}\n.ion-padding ion-list ion-item ion-input::placeholder {\n  color: #2c55e0;\n}\n.ion-padding ion-list .eye-btn {\n  background: transparent;\n}\n.ion-padding ion-list .eye-btn ion-icon {\n  font-size: 27px;\n  color: #7290f9;\n}\n.ion-padding .btn-wrap {\n  padding-top: 10px;\n}\n.ion-padding .btn-wrap ion-button {\n  width: 42% !important;\n  height: 3.2rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29uZmlndXJhdGlvbi9iaWxsaW5mby9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXGNvbmZpZ3VyYXRpb25cXGJpbGxpbmZvXFxiaWxsaW5mby5wYWdlLnNjc3MiLCJzcmMvYXBwL2NvbmZpZ3VyYXRpb24vYmlsbGluZm8vYmlsbGluZm8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UsZ0JBQUE7QUNBSjtBREdJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNETjtBREtBO0VBQ0Usa0JBQUE7QUNGRjtBREdFO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0FDREo7QURHRTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNESjtBREdFO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtBQ0RKO0FERUk7RUFDRSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0EsMkJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQ0FOO0FEQ007RUFDRSxlQUFBO0VBQ0EscUJBQUE7QUNDUjtBREFRO0VBQ0UsY0FBQTtBQ0VWO0FESFE7RUFDRSxjQUFBO0FDRVY7QURIUTtFQUNFLGNBQUE7QUNFVjtBREVJO0VBQ0UsdUJBQUE7QUNBTjtBRENNO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUNDUjtBREdFO0VBQ0UsaUJBQUE7QUNESjtBREVJO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0FDQU4iLCJmaWxlIjoic3JjL2FwcC9jb25maWd1cmF0aW9uL2JpbGxpbmZvL2JpbGxpbmZvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xyXG4gIGlvbi10aXRsZSB7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gIH1cclxuICAuYnRuLXJpZ2h0IHtcclxuICAgIC5hbGVydC10YWcge1xyXG4gICAgICB3aWR0aDogMTJweDtcclxuICAgICAgaGVpZ2h0OiAxMnB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjZmI0ZjMzO1xyXG4gICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgIHJpZ2h0OiAtM3B4O1xyXG4gICAgICBib3R0b206IC0ycHg7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbi5pb24tcGFkZGluZyB7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGltZyB7XHJcbiAgICBtYXJnaW46IDAgMCAxMHB4O1xyXG4gICAgd2lkdGg6IDIxMHB4O1xyXG4gIH1cclxuICBwIHtcclxuICAgIG1hcmdpbi10b3A6IDA7XHJcbiAgICBjb2xvcjogIzc1NzM3MztcclxuICAgIG1hcmdpbi1ib3R0b206IDRweDtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICBwYWRkaW5nOiAwIDZweDtcclxuICB9XHJcbiAgaW9uLWxpc3Qge1xyXG4gICAgbWFyZ2luOiAxNnB4IDJweCAwO1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBpb24taXRlbSB7XHJcbiAgICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDEycHg7XHJcbiAgICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgYm9yZGVyOiAxcHggc29saWQgIzc2OTJmMTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgICAgLS1taW4taGVpZ2h0OiA0NHB4O1xyXG4gICAgICBwYWRkaW5nLWxlZnQ6IDRweDtcclxuICAgICAgaW9uLWlucHV0IHtcclxuICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxNHB4O1xyXG4gICAgICAgICY6OnBsYWNlaG9sZGVyIHtcclxuICAgICAgICAgIGNvbG9yOiAjMmM1NWUwO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmV5ZS1idG4ge1xyXG4gICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjdweDtcclxuICAgICAgICBjb2xvcjogIzcyOTBmOTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICAuYnRuLXdyYXAge1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgICBpb24tYnV0dG9uIHtcclxuICAgICAgd2lkdGg6IDQyJSAhaW1wb3J0YW50O1xyXG4gICAgICBoZWlnaHQ6IDMuMnJlbTtcclxuICAgIH1cclxuICB9XHJcbn0iLCJpb24taGVhZGVyIGlvbi10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5pb24taGVhZGVyIC5idG4tcmlnaHQgLmFsZXJ0LXRhZyB7XG4gIHdpZHRoOiAxMnB4O1xuICBoZWlnaHQ6IDEycHg7XG4gIGJhY2tncm91bmQ6ICNmYjRmMzM7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IC0zcHg7XG4gIGJvdHRvbTogLTJweDtcbn1cblxuLmlvbi1wYWRkaW5nIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLmlvbi1wYWRkaW5nIGltZyB7XG4gIG1hcmdpbjogMCAwIDEwcHg7XG4gIHdpZHRoOiAyMTBweDtcbn1cbi5pb24tcGFkZGluZyBwIHtcbiAgbWFyZ2luLXRvcDogMDtcbiAgY29sb3I6ICM3NTczNzM7XG4gIG1hcmdpbi1ib3R0b206IDRweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgcGFkZGluZzogMCA2cHg7XG59XG4uaW9uLXBhZGRpbmcgaW9uLWxpc3Qge1xuICBtYXJnaW46IDE2cHggMnB4IDA7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuLmlvbi1wYWRkaW5nIGlvbi1saXN0IGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgbWFyZ2luLWJvdHRvbTogMTJweDtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICBib3JkZXI6IDFweCBzb2xpZCAjNzY5MmYxO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICAtLW1pbi1oZWlnaHQ6IDQ0cHg7XG4gIHBhZGRpbmctbGVmdDogNHB4O1xufVxuLmlvbi1wYWRkaW5nIGlvbi1saXN0IGlvbi1pdGVtIGlvbi1pbnB1dCB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNHB4O1xufVxuLmlvbi1wYWRkaW5nIGlvbi1saXN0IGlvbi1pdGVtIGlvbi1pbnB1dDo6cGxhY2Vob2xkZXIge1xuICBjb2xvcjogIzJjNTVlMDtcbn1cbi5pb24tcGFkZGluZyBpb24tbGlzdCAuZXllLWJ0biB7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuLmlvbi1wYWRkaW5nIGlvbi1saXN0IC5leWUtYnRuIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyN3B4O1xuICBjb2xvcjogIzcyOTBmOTtcbn1cbi5pb24tcGFkZGluZyAuYnRuLXdyYXAge1xuICBwYWRkaW5nLXRvcDogMTBweDtcbn1cbi5pb24tcGFkZGluZyAuYnRuLXdyYXAgaW9uLWJ1dHRvbiB7XG4gIHdpZHRoOiA0MiUgIWltcG9ydGFudDtcbiAgaGVpZ2h0OiAzLjJyZW07XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/configuration/billinfo/billinfo.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/configuration/billinfo/billinfo.page.ts ***!
    \*********************************************************/

  /*! exports provided: BillinfoPage */

  /***/
  function srcAppConfigurationBillinfoBillinfoPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BillinfoPage", function () {
      return BillinfoPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var BillinfoPage = /*#__PURE__*/function () {
      function BillinfoPage(router, menuCtrl) {
        _classCallCheck(this, BillinfoPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
        this.type = 'password';
        this.showPass = false;
      }

      _createClass(BillinfoPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "PageRoute",
        value: function PageRoute(urlSlug) {
          this.router.navigateByUrl('/' + urlSlug);
        }
      }, {
        key: "showPassword",
        value: function showPassword() {
          this.showPass = !this.showPass;

          if (this.showPass) {
            this.type = 'text';
          } else {
            this.type = 'password';
          }
        }
      }]);

      return BillinfoPage;
    }();

    BillinfoPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    BillinfoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-billinfo',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./billinfo.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/billinfo/billinfo.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./billinfo.page.scss */
      "./src/app/configuration/billinfo/billinfo.page.scss"))["default"]]
    })], BillinfoPage);
    /***/
  }
}]);
//# sourceMappingURL=configuration-billinfo-billinfo-module-es5.js.map