(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["encuestas-finalizer-finalizer-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/encuestas/finalizer/finalizer.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/encuestas/finalizer/finalizer.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\" (click)=\"PageRoute('encumain')\">\n      <ion-icon name=\"close\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"term-content\">\n    <img src=\"assets/imgs/encuestas/final.png\" alt=\"\">\n    <h5>¡Listo!</h5>\n    <p>Nullam dictum at metus at semper. Maecenas auctor nisl eu elit condimentum vulputate.</p>\n    <div class=\"btn-wrap\">\n      <ion-button (click)=\"PageRoute('home')\">Finalizer</ion-button>\n    </div>\n  </div>\n</ion-content>");

/***/ }),

/***/ "./src/app/encuestas/finalizer/finalizer-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/encuestas/finalizer/finalizer-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: FinalizerPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FinalizerPageRoutingModule", function() { return FinalizerPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _finalizer_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./finalizer.page */ "./src/app/encuestas/finalizer/finalizer.page.ts");




const routes = [
    {
        path: '',
        component: _finalizer_page__WEBPACK_IMPORTED_MODULE_3__["FinalizerPage"]
    }
];
let FinalizerPageRoutingModule = class FinalizerPageRoutingModule {
};
FinalizerPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], FinalizerPageRoutingModule);



/***/ }),

/***/ "./src/app/encuestas/finalizer/finalizer.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/encuestas/finalizer/finalizer.module.ts ***!
  \*********************************************************/
/*! exports provided: FinalizerPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FinalizerPageModule", function() { return FinalizerPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _finalizer_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./finalizer-routing.module */ "./src/app/encuestas/finalizer/finalizer-routing.module.ts");
/* harmony import */ var _finalizer_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./finalizer.page */ "./src/app/encuestas/finalizer/finalizer.page.ts");







let FinalizerPageModule = class FinalizerPageModule {
};
FinalizerPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _finalizer_routing_module__WEBPACK_IMPORTED_MODULE_5__["FinalizerPageRoutingModule"]
        ],
        declarations: [_finalizer_page__WEBPACK_IMPORTED_MODULE_6__["FinalizerPage"]]
    })
], FinalizerPageModule);



/***/ }),

/***/ "./src/app/encuestas/finalizer/finalizer.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/encuestas/finalizer/finalizer.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-buttons {\n  margin-left: 20px;\n}\n\nion-content {\n  --background: #5176f3;\n}\n\nion-content .term-content {\n  background: #fff;\n  padding: 20px 18px;\n  margin: 16px 20px 20px;\n  text-align: center;\n  border-radius: 20px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\n\nion-content .term-content img {\n  width: 100px;\n  margin: 0 0 20px;\n}\n\nion-content .term-content h5 {\n  font-size: 18px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n}\n\nion-content .term-content p {\n  margin-bottom: 4px;\n}\n\nion-content .term-content .btn-wrap ion-button {\n  width: 44% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZW5jdWVzdGFzL2ZpbmFsaXplci9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXGVuY3Vlc3Rhc1xcZmluYWxpemVyXFxmaW5hbGl6ZXIucGFnZS5zY3NzIiwic3JjL2FwcC9lbmN1ZXN0YXMvZmluYWxpemVyL2ZpbmFsaXplci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxpQkFBQTtBQ0FKOztBREdBO0VBQ0UscUJBQUE7QUNBRjs7QURDRTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSwrQ0FBQTtBQ0NKOztBREFJO0VBQ0UsWUFBQTtFQUNBLGdCQUFBO0FDRU47O0FEQUk7RUFDRSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQ0VOOztBREFJO0VBQ0Usa0JBQUE7QUNFTjs7QURDTTtFQUNFLHFCQUFBO0FDQ1IiLCJmaWxlIjoic3JjL2FwcC9lbmN1ZXN0YXMvZmluYWxpemVyL2ZpbmFsaXplci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tYnV0dG9ucyB7XHJcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcclxuICB9XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcclxuICAudGVybS1jb250ZW50IHtcclxuICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICBwYWRkaW5nOiAyMHB4IDE4cHg7XHJcbiAgICBtYXJnaW46IDE2cHggMjBweCAyMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgIGJveC1zaGFkb3c6IDAgN3B4IDE2cHggLTdweCByZ2JhKDAsIDAsIDAsIDAuNjkpO1xyXG4gICAgaW1nIHtcclxuICAgICAgd2lkdGg6IDEwMHB4O1xyXG4gICAgICBtYXJnaW46IDAgMCAyMHB4O1xyXG4gICAgfVxyXG4gICAgaDUge1xyXG4gICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDZweDtcclxuICAgICAgY29sb3I6ICMyYzU1ZTA7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICB9XHJcbiAgICBwIHtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG4gICAgfVxyXG4gICAgLmJ0bi13cmFwIHtcclxuICAgICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgICAgd2lkdGg6IDQ0JSFpbXBvcnRhbnQ7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn0iLCJpb24taGVhZGVyIGlvbi1idXR0b25zIHtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHBhZGRpbmc6IDIwcHggMThweDtcbiAgbWFyZ2luOiAxNnB4IDIwcHggMjBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaW1nIHtcbiAgd2lkdGg6IDEwMHB4O1xuICBtYXJnaW46IDAgMCAyMHB4O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBoNSB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBjb2xvcjogIzJjNTVlMDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgcCB7XG4gIG1hcmdpbi1ib3R0b206IDRweDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgLmJ0bi13cmFwIGlvbi1idXR0b24ge1xuICB3aWR0aDogNDQlICFpbXBvcnRhbnQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/encuestas/finalizer/finalizer.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/encuestas/finalizer/finalizer.page.ts ***!
  \*******************************************************/
/*! exports provided: FinalizerPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FinalizerPage", function() { return FinalizerPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let FinalizerPage = class FinalizerPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
};
FinalizerPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
FinalizerPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-finalizer',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./finalizer.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/encuestas/finalizer/finalizer.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./finalizer.page.scss */ "./src/app/encuestas/finalizer/finalizer.page.scss")).default]
    })
], FinalizerPage);



/***/ })

}]);
//# sourceMappingURL=encuestas-finalizer-finalizer-module-es2015.js.map