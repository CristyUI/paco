(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["registerconfirm-registerconfirm-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/registerconfirm/registerconfirm.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/registerconfirm/registerconfirm.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Revisa tu correo</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"help-circle-outline\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n   <div class=\"ion-padding\">\n     <p>Hemos enviado un código de verificación al  correo asociado con tu cuenta.</p>\n     <ion-list>\n       <ion-item class=\"ion-no-padding\">\n         <ion-input type=\"text\"></ion-input>\n       </ion-item>\n       <ion-item class=\"ion-no-padding\">\n         <ion-input type=\"text\"></ion-input>\n       </ion-item>\n       <ion-item class=\"ion-no-padding\">\n         <ion-input type=\"text\"></ion-input>\n       </ion-item>\n       <ion-item class=\"ion-no-padding\">\n         <ion-input type=\"text\"></ion-input>\n       </ion-item>\n     </ion-list>\n     <div class=\"ion-text-end\">\n       <ion-button class=\"btn-transparent\" (click)=\"registerpassword()\"><ion-icon name=\"checkmark-outline\"></ion-icon></ion-button>\n\n       <!-- AFTER BUTTON ACTIVE -->\n       <!--<ion-button class=\"btn-white\"><ion-icon name=\"checkmark-outline\"></ion-icon></ion-button>-->\n     </div>\n   </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/registerconfirm/registerconfirm-routing.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/registerconfirm/registerconfirm-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: RegisterconfirmPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterconfirmPageRoutingModule", function() { return RegisterconfirmPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _registerconfirm_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./registerconfirm.page */ "./src/app/registerconfirm/registerconfirm.page.ts");




const routes = [
    {
        path: '',
        component: _registerconfirm_page__WEBPACK_IMPORTED_MODULE_3__["RegisterconfirmPage"]
    }
];
let RegisterconfirmPageRoutingModule = class RegisterconfirmPageRoutingModule {
};
RegisterconfirmPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RegisterconfirmPageRoutingModule);



/***/ }),

/***/ "./src/app/registerconfirm/registerconfirm.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/registerconfirm/registerconfirm.module.ts ***!
  \***********************************************************/
/*! exports provided: RegisterconfirmPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterconfirmPageModule", function() { return RegisterconfirmPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _registerconfirm_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./registerconfirm-routing.module */ "./src/app/registerconfirm/registerconfirm-routing.module.ts");
/* harmony import */ var _registerconfirm_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./registerconfirm.page */ "./src/app/registerconfirm/registerconfirm.page.ts");







let RegisterconfirmPageModule = class RegisterconfirmPageModule {
};
RegisterconfirmPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _registerconfirm_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegisterconfirmPageRoutingModule"]
        ],
        declarations: [_registerconfirm_page__WEBPACK_IMPORTED_MODULE_6__["RegisterconfirmPage"]]
    })
], RegisterconfirmPageModule);



/***/ }),

/***/ "./src/app/registerconfirm/registerconfirm.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/registerconfirm/registerconfirm.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header .btn-right ion-icon {\n  font-size: 24px;\n}\n\nion-content {\n  --background: #5176f3;\n}\n\nion-content .ion-padding {\n  text-align: center;\n}\n\nion-content .ion-padding p {\n  color: #fff;\n  font-size: 15px;\n  line-height: 23px;\n  margin-top: 30px;\n}\n\nion-content .ion-padding ion-list {\n  margin: 30px 10px 5px;\n  background: transparent;\n}\n\nion-content .ion-padding ion-list ion-item {\n  --background: #fff;\n  --border-color: transparent;\n  border-radius: 5px;\n  display: inline-block;\n  width: 50px;\n  margin: 0 5px;\n}\n\nion-content .ion-padding ion-list ion-item ion-input {\n  font-size: 15px;\n  color: #fff;\n  --padding-start: 14px;\n}\n\nion-content .ion-padding ion-list ion-item ion-input::-moz-placeholder {\n  color: #fff;\n}\n\nion-content .ion-padding ion-list ion-item ion-input::-ms-input-placeholder {\n  color: #fff;\n}\n\nion-content .ion-padding ion-list ion-item ion-input::placeholder {\n  color: #fff;\n}\n\nion-content .ion-padding .ion-text-end {\n  padding: 40px 20px 0;\n}\n\nion-content .ion-padding .ion-text-end .btn-transparent {\n  --background: transparent;\n  color: #0c38ce;\n  --padding-end: 0;\n  --padding-start: 0;\n  width: 60px !important;\n  height: 60px;\n}\n\nion-content .ion-padding .ion-text-end .btn-transparent ion-icon {\n  font-size: 35px;\n}\n\nion-content .ion-padding .ion-text-end .btn-white {\n  --background: #fff;\n  color: #5176f3;\n  --padding-end: 0;\n  --padding-start: 0;\n  width: 60px !important;\n  height: 60px;\n}\n\nion-content .ion-padding .ion-text-end .btn-white ion-icon {\n  font-size: 35px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVnaXN0ZXJjb25maXJtL0c6XFxpb25pY1xcRklWRVJSXFxwYW50YWxsYXMtcGFjby9zcmNcXGFwcFxccmVnaXN0ZXJjb25maXJtXFxyZWdpc3RlcmNvbmZpcm0ucGFnZS5zY3NzIiwic3JjL2FwcC9yZWdpc3RlcmNvbmZpcm0vcmVnaXN0ZXJjb25maXJtLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFSTtFQUNFLGVBQUE7QUNETjs7QURLQTtFQUNFLHFCQUFBO0FDRkY7O0FER0U7RUFDRSxrQkFBQTtBQ0RKOztBREVJO0VBQ0UsV0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FDQU47O0FERUk7RUFDRSxxQkFBQTtFQUNBLHVCQUFBO0FDQU47O0FEQ007RUFDRSxrQkFBQTtFQUNBLDJCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0FDQ1I7O0FEQVE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0FDRVY7O0FERFU7RUFDRSxXQUFBO0FDR1o7O0FESlU7RUFDRSxXQUFBO0FDR1o7O0FESlU7RUFDRSxXQUFBO0FDR1o7O0FERUk7RUFDRSxvQkFBQTtBQ0FOOztBRENNO0VBQ0UseUJBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQ0NSOztBREFRO0VBQ0UsZUFBQTtBQ0VWOztBRENNO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQ0NSOztBREFRO0VBQ0UsZUFBQTtBQ0VWIiwiZmlsZSI6InNyYy9hcHAvcmVnaXN0ZXJjb25maXJtL3JlZ2lzdGVyY29uZmlybS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICAuYnRuLXJpZ2h0IHtcclxuICAgIGlvbi1pY29uIHtcclxuICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gIC5pb24tcGFkZGluZyB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwIHtcclxuICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDIzcHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgICB9XHJcbiAgICBpb24tbGlzdCB7XHJcbiAgICAgIG1hcmdpbjogMzBweCAxMHB4IDVweDtcclxuICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgIGlvbi1pdGVtIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgd2lkdGg6IDUwcHg7XHJcbiAgICAgICAgbWFyZ2luOiAwIDVweDtcclxuICAgICAgICBpb24taW5wdXQge1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDE0cHg7XHJcbiAgICAgICAgICAmOjpwbGFjZWhvbGRlciB7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmlvbi10ZXh0LWVuZCB7XHJcbiAgICAgIHBhZGRpbmc6IDQwcHggMjBweCAwO1xyXG4gICAgICAuYnRuLXRyYW5zcGFyZW50IHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIGNvbG9yOiAjMGMzOGNlO1xyXG4gICAgICAgIC0tcGFkZGluZy1lbmQ6IDA7XHJcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xyXG4gICAgICAgIHdpZHRoOiA2MHB4IWltcG9ydGFudDtcclxuICAgICAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgZm9udC1zaXplOiAzNXB4O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAuYnRuLXdoaXRlIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgICAgY29sb3I6ICM1MTc2ZjM7XHJcbiAgICAgICAgLS1wYWRkaW5nLWVuZDogMDtcclxuICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDA7XHJcbiAgICAgICAgd2lkdGg6IDYwcHghaW1wb3J0YW50O1xyXG4gICAgICAgIGhlaWdodDogNjBweDtcclxuICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICBmb250LXNpemU6IDM1cHg7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59IiwiaW9uLWhlYWRlciAuYnRuLXJpZ2h0IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNHB4O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyBwIHtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbGluZS1oZWlnaHQ6IDIzcHg7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgaW9uLWxpc3Qge1xuICBtYXJnaW46IDMwcHggMTBweCA1cHg7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIGlvbi1saXN0IGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogNTBweDtcbiAgbWFyZ2luOiAwIDVweDtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyBpb24tbGlzdCBpb24taXRlbSBpb24taW5wdXQge1xuICBmb250LXNpemU6IDE1cHg7XG4gIGNvbG9yOiAjZmZmO1xuICAtLXBhZGRpbmctc3RhcnQ6IDE0cHg7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgaW9uLWxpc3QgaW9uLWl0ZW0gaW9uLWlucHV0OjpwbGFjZWhvbGRlciB7XG4gIGNvbG9yOiAjZmZmO1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIC5pb24tdGV4dC1lbmQge1xuICBwYWRkaW5nOiA0MHB4IDIwcHggMDtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyAuaW9uLXRleHQtZW5kIC5idG4tdHJhbnNwYXJlbnQge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBjb2xvcjogIzBjMzhjZTtcbiAgLS1wYWRkaW5nLWVuZDogMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICB3aWR0aDogNjBweCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDYwcHg7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgLmlvbi10ZXh0LWVuZCAuYnRuLXRyYW5zcGFyZW50IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAzNXB4O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIC5pb24tdGV4dC1lbmQgLmJ0bi13aGl0ZSB7XG4gIC0tYmFja2dyb3VuZDogI2ZmZjtcbiAgY29sb3I6ICM1MTc2ZjM7XG4gIC0tcGFkZGluZy1lbmQ6IDA7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgd2lkdGg6IDYwcHggIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA2MHB4O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIC5pb24tdGV4dC1lbmQgLmJ0bi13aGl0ZSBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMzVweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/registerconfirm/registerconfirm.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/registerconfirm/registerconfirm.page.ts ***!
  \*********************************************************/
/*! exports provided: RegisterconfirmPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterconfirmPage", function() { return RegisterconfirmPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let RegisterconfirmPage = class RegisterconfirmPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    registerpassword() {
        this.router.navigateByUrl('/registerpassword');
    }
};
RegisterconfirmPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
RegisterconfirmPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-registerconfirm',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./registerconfirm.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/registerconfirm/registerconfirm.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./registerconfirm.page.scss */ "./src/app/registerconfirm/registerconfirm.page.scss")).default]
    })
], RegisterconfirmPage);



/***/ })

}]);
//# sourceMappingURL=registerconfirm-registerconfirm-module-es2015.js.map