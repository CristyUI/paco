(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["documentos-docview-docview-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/documentos/docview/docview.page.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/documentos/docview/docview.page.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" (click)=\"PageRoute('home')\">\n      <ion-icon name=\"chevron-back-outline\" color=\"secondary\" style=\"margin-top: 4px;\"></ion-icon>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Documentos corporativos</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"ion-padding\">\n\n    <div class=\"search-area\">\n      <div class=\"content-search\" (click)=\"PageRoute('search')\">\n        <span>Buscar<img src=\"assets/imgs/search-icon.png\" alt=\"\"></span>\n      </div>\n    </div>\n\n    <ion-row>\n      <ion-col size=\"6\">\n        <div class=\"filter-area\" (click)=\"sortby()\">\n          <p>Ordenar por<span><ion-icon name=\"chevron-down-outline\"></ion-icon></span></p>\n        </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"tab-list\">\n          <ul>\n            <li *ngIf=\"tab1\" (click)=\"showgrid()\"><img src=\"assets/imgs/pagodeservicio/tab-1-dark.png\" alt=\"\"></li>\n            <li *ngIf=\"tab2\" (click)=\"showgrid()\"><img src=\"assets/imgs/pagodeservicio/tab-1-light.png\" alt=\"\"></li>\n            <li *ngIf=\"tab3\" (click)=\"showlist()\"><img src=\"assets/imgs/pagodeservicio/tab-2-light.png\" alt=\"\"></li>\n            <li *ngIf=\"tab4\" (click)=\"showlist()\"><img src=\"assets/imgs/pagodeservicio/tab-2-dark.png\" alt=\"\"></li>\n          </ul>\n        </div>\n      </ion-col>\n    </ion-row>\n\n\n\n\n    <div class=\"list-category\" *ngIf=\"catGrid\">\n      <ul>\n        <li (click)=\"PageRoute('fullview')\">\n          <h5>Reglamento de oficina</h5>\n          <p>06-06-2019 <span>18:24</span></p>\n        </li>\n        <li (click)=\"PageRoute('fullview')\">\n          <h5>Molestie libero vel tellus</h5>\n          <p>06-06-2019 <span>18:24</span></p>\n        </li>\n        <li (click)=\"PageRoute('fullview')\">\n          <h5>Ultrices malesuada dignissim...</h5>\n          <p>14-12-2019 <span>18:24</span></p>\n        </li>\n        <li (click)=\"PageRoute('fullview')\">\n          <h5>Egestas tortor</h5>\n          <p>14-12-2019 <span>18:24</span></p>\n        </li>\n      </ul>\n    </div>\n\n    <div class=\"block-category\" *ngIf=\"catList\">\n      <ion-row>\n        <ion-col size=\"6\" (click)=\"PageRoute('fullview')\">\n          <div class=\"item_wrap\">\n            <img src=\"assets/imgs/documentation/doc.png\" alt=\"\">\n            <div class=\"content\">\n              <h5>Ultrices malesuada dignissim...</h5>\n              <p>06-06-2019 <span>18:24</span></p>\n            </div>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\" (click)=\"PageRoute('fullview')\">\n          <div class=\"item_wrap\">\n            <img src=\"assets/imgs/documentation/doc.png\" alt=\"\">\n            <div class=\"content\">\n              <h5>Ultrices malesuada dignissim...</h5>\n              <p>06-06-2019 <span>18:24</span></p>\n            </div>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\" (click)=\"PageRoute('fullview')\">\n          <div class=\"item_wrap\">\n            <img src=\"assets/imgs/documentation/doc.png\" alt=\"\">\n            <div class=\"content\">\n              <h5>Ultrices malesuada dignissim...</h5>\n              <p>06-06-2019 <span>18:24</span></p>\n            </div>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\" (click)=\"PageRoute('fullview')\">\n          <div class=\"item_wrap\">\n            <img src=\"assets/imgs/documentation/doc.png\" alt=\"\">\n            <div class=\"content\">\n              <h5>Ultrices malesuada dignissim...</h5>\n              <p>06-06-2019 <span>18:24</span></p>\n            </div>\n          </div>\n        </ion-col>\n      </ion-row>\n    </div>\n\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/documentos/docview/docview-routing.module.ts":
/*!**************************************************************!*\
  !*** ./src/app/documentos/docview/docview-routing.module.ts ***!
  \**************************************************************/
/*! exports provided: DocviewPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DocviewPageRoutingModule", function() { return DocviewPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _docview_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./docview.page */ "./src/app/documentos/docview/docview.page.ts");




const routes = [
    {
        path: '',
        component: _docview_page__WEBPACK_IMPORTED_MODULE_3__["DocviewPage"]
    }
];
let DocviewPageRoutingModule = class DocviewPageRoutingModule {
};
DocviewPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DocviewPageRoutingModule);



/***/ }),

/***/ "./src/app/documentos/docview/docview.module.ts":
/*!******************************************************!*\
  !*** ./src/app/documentos/docview/docview.module.ts ***!
  \******************************************************/
/*! exports provided: DocviewPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DocviewPageModule", function() { return DocviewPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _docview_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./docview-routing.module */ "./src/app/documentos/docview/docview-routing.module.ts");
/* harmony import */ var _docview_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./docview.page */ "./src/app/documentos/docview/docview.page.ts");







let DocviewPageModule = class DocviewPageModule {
};
DocviewPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _docview_routing_module__WEBPACK_IMPORTED_MODULE_5__["DocviewPageRoutingModule"]
        ],
        declarations: [_docview_page__WEBPACK_IMPORTED_MODULE_6__["DocviewPage"]]
    })
], DocviewPageModule);



/***/ }),

/***/ "./src/app/documentos/docview/docview.page.scss":
/*!******************************************************!*\
  !*** ./src/app/documentos/docview/docview.page.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-title {\n  font-weight: 600;\n}\nion-header ion-buttons {\n  margin-left: 20px;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.search-area {\n  margin-bottom: 8px;\n}\n.search-area .content-search {\n  box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.2588235294);\n  border-radius: 30px;\n  padding: 15px 22px;\n}\n.search-area .content-search span {\n  color: #8c8b8b;\n}\n.search-area .content-search span img {\n  width: 20px;\n  vertical-align: bottom;\n  float: right;\n}\n.filter-area {\n  padding: 10px 0 5px;\n}\n.filter-area p {\n  border: 1px solid #8ca3f1;\n  padding: 13px 20px;\n  margin: 0;\n  border-radius: 30px;\n  width: 100%;\n  color: #797979;\n}\n.filter-area p span {\n  float: right;\n  font-size: 17px;\n  position: relative;\n  top: 2px;\n  color: #2d5eb7;\n}\n.tab-list {\n  text-align: right;\n}\n.tab-list ul {\n  padding-left: 0;\n  margin-bottom: 0;\n}\n.tab-list ul li {\n  list-style-type: none;\n  display: inline-flex;\n  padding-left: 9px;\n}\n.tab-list ul li img {\n  width: 30px;\n}\n.list-category ul {\n  padding-left: 0;\n}\n.list-category ul li {\n  list-style-type: none;\n  padding-left: 4px;\n}\n.list-category ul li h5 {\n  font-size: 15px;\n  margin-bottom: 5px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.list-category ul li p {\n  font-size: 14px;\n  line-height: 20px;\n  color: #757474;\n  margin: 6px 0;\n}\n.list-category ul li p span {\n  margin-left: 10px;\n}\n.block-category .item_wrap {\n  box-shadow: 0 7px 12px -7px rgba(0, 0, 0, 0.4);\n  background: #fff;\n  border-radius: 20px;\n  margin: 2px 2px 14px;\n}\n.block-category .item_wrap img {\n  width: 100%;\n  height: 111px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 20px 20px 0 0;\n}\n.block-category .item_wrap .content {\n  padding: 2px 7px;\n}\n.block-category .item_wrap .content h5 {\n  margin: 4px 0 0;\n  font-size: 15px;\n}\n.block-category .item_wrap .content p {\n  font-size: 14px;\n  line-height: 20px;\n  color: #757474;\n  margin: 6px 0;\n}\n.block-category .item_wrap .content p span {\n  float: right;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZG9jdW1lbnRvcy9kb2N2aWV3L0c6XFxpb25pY1xcRklWRVJSXFxwYW50YWxsYXMtcGFjby9zcmNcXGFwcFxcZG9jdW1lbnRvc1xcZG9jdmlld1xcZG9jdmlldy5wYWdlLnNjc3MiLCJzcmMvYXBwL2RvY3VtZW50b3MvZG9jdmlldy9kb2N2aWV3LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGdCQUFBO0FDQUo7QURFRTtFQUNFLGlCQUFBO0FDQUo7QURHSTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDRE47QURNQTtFQUNFLGtCQUFBO0FDSEY7QURJRTtFQUNFLHdEQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQ0ZKO0FER0k7RUFDRSxjQUFBO0FDRE47QURFTTtFQUNFLFdBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7QUNBUjtBREtBO0VBQ0UsbUJBQUE7QUNGRjtBREdFO0VBQ0UseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0FDREo7QURFSTtFQUNFLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsY0FBQTtBQ0FOO0FESUE7RUFDRSxpQkFBQTtBQ0RGO0FERUU7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7QUNBSjtBRENJO0VBQ0UscUJBQUE7RUFDQSxvQkFBQTtFQUNBLGlCQUFBO0FDQ047QURBTTtFQUNFLFdBQUE7QUNFUjtBRElFO0VBQ0UsZUFBQTtBQ0RKO0FERUk7RUFDRSxxQkFBQTtFQUNBLGlCQUFBO0FDQU47QURDTTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQ0NSO0FEQ007RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtBQ0NSO0FEQVE7RUFDRSxpQkFBQTtBQ0VWO0FES0U7RUFDRSw4Q0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxvQkFBQTtBQ0ZKO0FER0k7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7RUFDQSw0QkFBQTtBQ0ROO0FER0k7RUFDRSxnQkFBQTtBQ0ROO0FERU07RUFDRSxlQUFBO0VBQ0EsZUFBQTtBQ0FSO0FERU07RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtBQ0FSO0FEQ1E7RUFDRSxZQUFBO0FDQ1YiLCJmaWxlIjoic3JjL2FwcC9kb2N1bWVudG9zL2RvY3ZpZXcvZG9jdmlldy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tdGl0bGUge1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB9XHJcbiAgaW9uLWJ1dHRvbnMge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgfVxyXG4gIC5idG4tcmlnaHQge1xyXG4gICAgLmFsZXJ0LXRhZyB7XHJcbiAgICAgIHdpZHRoOiAxMnB4O1xyXG4gICAgICBoZWlnaHQ6IDEycHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNmYjRmMzM7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgcmlnaHQ6IC0zcHg7XHJcbiAgICAgIGJvdHRvbTogLTJweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi5zZWFyY2gtYXJlYXtcclxuICBtYXJnaW4tYm90dG9tOiA4cHg7XHJcbiAgLmNvbnRlbnQtc2VhcmNoIHtcclxuICAgIGJveC1zaGFkb3c6IGluc2V0IDAgMnB4IDEwcHggcmdiYSgwLCAwLCAwLCAwLjI1ODgyMzUyOTQxMTc2NDczKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICBwYWRkaW5nOiAxNXB4IDIycHg7XHJcbiAgICBzcGFuIHtcclxuICAgICAgY29sb3I6ICM4YzhiOGI7XHJcbiAgICAgIGltZyB7XHJcbiAgICAgICAgd2lkdGg6IDIwcHg7XHJcbiAgICAgICAgdmVydGljYWwtYWxpZ246IGJvdHRvbTtcclxuICAgICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuLmZpbHRlci1hcmVhIHtcclxuICBwYWRkaW5nOiAxMHB4IDAgNXB4O1xyXG4gIHAge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzhjYTNmMTtcclxuICAgIHBhZGRpbmc6IDEzcHggMjBweDtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGNvbG9yOiAjNzk3OTc5O1xyXG4gICAgc3BhbiB7XHJcbiAgICAgIGZsb2F0OiByaWdodDtcclxuICAgICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIHRvcDogMnB4O1xyXG4gICAgICBjb2xvcjogIzJkNWViNztcclxuICAgIH1cclxuICB9XHJcbn1cclxuLnRhYi1saXN0IHtcclxuICB0ZXh0LWFsaWduOiByaWdodDtcclxuICB1bCB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDA7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xyXG4gICAgbGkge1xyXG4gICAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XHJcbiAgICAgIGRpc3BsYXk6IGlubGluZS1mbGV4O1xyXG4gICAgICBwYWRkaW5nLWxlZnQ6IDlweDtcclxuICAgICAgaW1nIHtcclxuICAgICAgICB3aWR0aDogMzBweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4ubGlzdC1jYXRlZ29yeSB7XHJcbiAgdWwge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAwO1xyXG4gICAgbGkge1xyXG4gICAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XHJcbiAgICAgIHBhZGRpbmctbGVmdDogNHB4O1xyXG4gICAgICBoNSB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxuICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgICAgIH1cclxuICAgICAgcCB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG4gICAgICAgIGNvbG9yOiAjNzU3NDc0O1xyXG4gICAgICAgIG1hcmdpbjogNnB4IDA7XHJcbiAgICAgICAgc3BhbiB7XHJcbiAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuLmJsb2NrLWNhdGVnb3J5IHtcclxuICAuaXRlbV93cmFwIHtcclxuICAgIGJveC1zaGFkb3c6IDAgN3B4IDEycHggLTdweCByZ2JhKDAsIDAsIDAsIDAuNCk7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgIG1hcmdpbjogMnB4IDJweCAxNHB4O1xyXG4gICAgaW1nIHtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIGhlaWdodDogMTExcHg7XHJcbiAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAyMHB4IDIwcHggMCAwO1xyXG4gICAgfVxyXG4gICAgLmNvbnRlbnQge1xyXG4gICAgICBwYWRkaW5nOiAycHggN3B4O1xyXG4gICAgICBoNSB7XHJcbiAgICAgICAgbWFyZ2luOiA0cHggMCAwO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgfVxyXG4gICAgICBwIHtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDIwcHg7XHJcbiAgICAgICAgY29sb3I6ICM3NTc0NzQ7XHJcbiAgICAgICAgbWFyZ2luOiA2cHggMDtcclxuICAgICAgICBzcGFuIHtcclxuICAgICAgICAgIGZsb2F0OiByaWdodDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn0iLCJpb24taGVhZGVyIGlvbi10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5pb24taGVhZGVyIGlvbi1idXR0b25zIHtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG59XG5pb24taGVhZGVyIC5idG4tcmlnaHQgLmFsZXJ0LXRhZyB7XG4gIHdpZHRoOiAxMnB4O1xuICBoZWlnaHQ6IDEycHg7XG4gIGJhY2tncm91bmQ6ICNmYjRmMzM7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IC0zcHg7XG4gIGJvdHRvbTogLTJweDtcbn1cblxuLnNlYXJjaC1hcmVhIHtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufVxuLnNlYXJjaC1hcmVhIC5jb250ZW50LXNlYXJjaCB7XG4gIGJveC1zaGFkb3c6IGluc2V0IDAgMnB4IDEwcHggcmdiYSgwLCAwLCAwLCAwLjI1ODgyMzUyOTQpO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBwYWRkaW5nOiAxNXB4IDIycHg7XG59XG4uc2VhcmNoLWFyZWEgLmNvbnRlbnQtc2VhcmNoIHNwYW4ge1xuICBjb2xvcjogIzhjOGI4Yjtcbn1cbi5zZWFyY2gtYXJlYSAuY29udGVudC1zZWFyY2ggc3BhbiBpbWcge1xuICB3aWR0aDogMjBweDtcbiAgdmVydGljYWwtYWxpZ246IGJvdHRvbTtcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuXG4uZmlsdGVyLWFyZWEge1xuICBwYWRkaW5nOiAxMHB4IDAgNXB4O1xufVxuLmZpbHRlci1hcmVhIHAge1xuICBib3JkZXI6IDFweCBzb2xpZCAjOGNhM2YxO1xuICBwYWRkaW5nOiAxM3B4IDIwcHg7XG4gIG1hcmdpbjogMDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGNvbG9yOiAjNzk3OTc5O1xufVxuLmZpbHRlci1hcmVhIHAgc3BhbiB7XG4gIGZsb2F0OiByaWdodDtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogMnB4O1xuICBjb2xvcjogIzJkNWViNztcbn1cblxuLnRhYi1saXN0IHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG4udGFiLWxpc3QgdWwge1xuICBwYWRkaW5nLWxlZnQ6IDA7XG4gIG1hcmdpbi1ib3R0b206IDA7XG59XG4udGFiLWxpc3QgdWwgbGkge1xuICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XG4gIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICBwYWRkaW5nLWxlZnQ6IDlweDtcbn1cbi50YWItbGlzdCB1bCBsaSBpbWcge1xuICB3aWR0aDogMzBweDtcbn1cblxuLmxpc3QtY2F0ZWdvcnkgdWwge1xuICBwYWRkaW5nLWxlZnQ6IDA7XG59XG4ubGlzdC1jYXRlZ29yeSB1bCBsaSB7XG4gIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbiAgcGFkZGluZy1sZWZ0OiA0cHg7XG59XG4ubGlzdC1jYXRlZ29yeSB1bCBsaSBoNSB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbn1cbi5saXN0LWNhdGVnb3J5IHVsIGxpIHAge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMHB4O1xuICBjb2xvcjogIzc1NzQ3NDtcbiAgbWFyZ2luOiA2cHggMDtcbn1cbi5saXN0LWNhdGVnb3J5IHVsIGxpIHAgc3BhbiB7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4uYmxvY2stY2F0ZWdvcnkgLml0ZW1fd3JhcCB7XG4gIGJveC1zaGFkb3c6IDAgN3B4IDEycHggLTdweCByZ2JhKDAsIDAsIDAsIDAuNCk7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIG1hcmdpbjogMnB4IDJweCAxNHB4O1xufVxuLmJsb2NrLWNhdGVnb3J5IC5pdGVtX3dyYXAgaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTExcHg7XG4gIG9iamVjdC1maXQ6IGNvdmVyO1xuICBib3JkZXItcmFkaXVzOiAyMHB4IDIwcHggMCAwO1xufVxuLmJsb2NrLWNhdGVnb3J5IC5pdGVtX3dyYXAgLmNvbnRlbnQge1xuICBwYWRkaW5nOiAycHggN3B4O1xufVxuLmJsb2NrLWNhdGVnb3J5IC5pdGVtX3dyYXAgLmNvbnRlbnQgaDUge1xuICBtYXJnaW46IDRweCAwIDA7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cbi5ibG9jay1jYXRlZ29yeSAuaXRlbV93cmFwIC5jb250ZW50IHAge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMHB4O1xuICBjb2xvcjogIzc1NzQ3NDtcbiAgbWFyZ2luOiA2cHggMDtcbn1cbi5ibG9jay1jYXRlZ29yeSAuaXRlbV93cmFwIC5jb250ZW50IHAgc3BhbiB7XG4gIGZsb2F0OiByaWdodDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/documentos/docview/docview.page.ts":
/*!****************************************************!*\
  !*** ./src/app/documentos/docview/docview.page.ts ***!
  \****************************************************/
/*! exports provided: DocviewPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DocviewPage", function() { return DocviewPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");





let DocviewPage = class DocviewPage {
    constructor(router, menuCtrl, actionSheetController) {
        this.router = router;
        this.menuCtrl = menuCtrl;
        this.actionSheetController = actionSheetController;
        this.tab1 = true;
        this.tab2 = false;
        this.tab3 = true;
        this.tab4 = false;
        this.catList = false;
        this.catGrid = true;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
    showlist() {
        this.catList = true;
        this.catGrid = false;
        this.tab1 = false;
        this.tab2 = true;
        this.tab3 = false;
        this.tab4 = true;
    }
    showgrid() {
        this.catGrid = true;
        this.catList = false;
        this.tab3 = true;
        this.tab4 = false;
        this.tab1 = true;
        this.tab2 = false;
    }
    sortby() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: 'Sort By',
                mode: 'ios',
                buttons: [{
                        text: 'Oldest',
                        handler: () => {
                            console.log('Oldest clicked');
                        }
                    }, {
                        text: 'Newest',
                        handler: () => {
                            console.log('Newest clicked');
                        }
                    }, {
                        text: 'Recently Viewed',
                        handler: () => {
                            console.log('Recently Viewed clicked');
                        }
                    },
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        }
                    },]
            });
            yield actionSheet.present();
        });
    }
};
DocviewPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"] }
];
DocviewPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-docview',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./docview.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/documentos/docview/docview.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./docview.page.scss */ "./src/app/documentos/docview/docview.page.scss")).default]
    })
], DocviewPage);



/***/ })

}]);
//# sourceMappingURL=documentos-docview-docview-module-es2015.js.map