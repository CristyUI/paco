(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["encuestas-multichoicethree-multichoicethree-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/encuestas/multichoicethree/multichoicethree.page.html":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/encuestas/multichoicethree/multichoicethree.page.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\" (click)=\"PageRoute('encumain')\">\n      <ion-icon name=\"close\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"term-content\">\n    <h5>Pregunta 3 de 6</h5>\n    <h6>¿Sagittis ultricies quam nisl?</h6>\n    <p>Urna fames nunc, nisl at. Vel luctus velit massa amet.</p>\n    <ion-progress-bar color=\"primary\" value=\"0.5\"></ion-progress-bar>\n\n    <ion-slides pager=\"false\" [options]=\"slideOpts\" #slide (ionSlideDidChange)=\"SlideChanges(slide)\">\n      <ion-slide [ngClass]=\"{'active': (activeIndex == '1')}\">\n        <h6>1</h6>\n      </ion-slide >\n      <ion-slide [ngClass]=\"{'active': (activeIndex == '2')}\">\n        <h6>2</h6>\n      </ion-slide>\n      <ion-slide [ngClass]=\"{'active': (activeIndex == '3')}\">\n        <h6>3</h6>\n      </ion-slide>\n      <ion-slide [ngClass]=\"{'active': (activeIndex == '4')}\">\n        <h6>4</h6>\n      </ion-slide>\n      <ion-slide [ngClass]=\"{'active': (activeIndex == '5')}\">\n        <h6>5</h6>\n      </ion-slide>\n      <ion-slide [ngClass]=\"{'active': (activeIndex == '6')}\">\n        <h6>6</h6>\n      </ion-slide>\n      <ion-slide [ngClass]=\"{'active': (activeIndex == '7')}\">\n        <h6>7</h6>\n      </ion-slide>\n    </ion-slides>\n\n    <!--<ul>-->\n      <!--<li>3</li>-->\n      <!--<li>4</li>-->\n      <!--<li class=\"active\">5</li>-->\n      <!--<li>6</li>-->\n      <!--<li>7</li>-->\n    <!--</ul>-->\n\n    <div class=\"btn-bottom\">\n      <ion-row>\n        <ion-col size=\"6\">\n          <ion-button class=\"btn-transparent\" (click)=\"PageRoute('multichoicetwo')\">Anterior</ion-button>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-button (click)=\"PageRoute('multichoicefour')\">Continuar</ion-button>\n        </ion-col>\n      </ion-row>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/encuestas/multichoicethree/multichoicethree-routing.module.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/encuestas/multichoicethree/multichoicethree-routing.module.ts ***!
  \*******************************************************************************/
/*! exports provided: MultichoicethreePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultichoicethreePageRoutingModule", function() { return MultichoicethreePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _multichoicethree_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./multichoicethree.page */ "./src/app/encuestas/multichoicethree/multichoicethree.page.ts");




const routes = [
    {
        path: '',
        component: _multichoicethree_page__WEBPACK_IMPORTED_MODULE_3__["MultichoicethreePage"]
    }
];
let MultichoicethreePageRoutingModule = class MultichoicethreePageRoutingModule {
};
MultichoicethreePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MultichoicethreePageRoutingModule);



/***/ }),

/***/ "./src/app/encuestas/multichoicethree/multichoicethree.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/encuestas/multichoicethree/multichoicethree.module.ts ***!
  \***********************************************************************/
/*! exports provided: MultichoicethreePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultichoicethreePageModule", function() { return MultichoicethreePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _multichoicethree_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./multichoicethree-routing.module */ "./src/app/encuestas/multichoicethree/multichoicethree-routing.module.ts");
/* harmony import */ var _multichoicethree_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./multichoicethree.page */ "./src/app/encuestas/multichoicethree/multichoicethree.page.ts");







let MultichoicethreePageModule = class MultichoicethreePageModule {
};
MultichoicethreePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _multichoicethree_routing_module__WEBPACK_IMPORTED_MODULE_5__["MultichoicethreePageRoutingModule"]
        ],
        declarations: [_multichoicethree_page__WEBPACK_IMPORTED_MODULE_6__["MultichoicethreePage"]]
    })
], MultichoicethreePageModule);



/***/ }),

/***/ "./src/app/encuestas/multichoicethree/multichoicethree.page.scss":
/*!***********************************************************************!*\
  !*** ./src/app/encuestas/multichoicethree/multichoicethree.page.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-buttons {\n  margin-left: 20px;\n}\n\nion-content {\n  --background: #5176f3;\n}\n\nion-content .term-content {\n  background: #fff;\n  padding: 20px 25px;\n  margin: 16px 20px 20px;\n  text-align: center;\n  border-radius: 30px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\n\nion-content .term-content h5 {\n  font-size: 17px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n  text-align: left;\n}\n\nion-content .term-content h6 {\n  text-align: left;\n  font-size: 15px;\n  font-weight: 700;\n}\n\nion-content .term-content p {\n  text-align: left;\n  font-size: 14px;\n  line-height: 20px;\n  color: #808080;\n  margin-bottom: 2px;\n}\n\nion-content .term-content ion-progress-bar {\n  margin: 15px 0 8px;\n  height: 9px;\n  border-radius: 20px;\n}\n\nion-content .term-content ion-slides {\n  margin: 20px 0;\n}\n\nion-content .term-content ion-slides ion-slide h6 {\n  font-size: 16px;\n  font-weight: 100;\n}\n\nion-content .term-content .active {\n  width: 26% !important;\n  border-left: 1px solid #2c55e0;\n  border-right: 1px solid #2c55e0;\n  color: #2c55e0;\n  font-weight: 700;\n  font-size: 17px;\n}\n\nion-content .term-content .btn-bottom .btn-transparent {\n  color: #2c55e0;\n}\n\nion-content .term-content .btn-bottom ion-button {\n  margin-top: 10px;\n  width: 100% !important;\n  height: 3rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZW5jdWVzdGFzL211bHRpY2hvaWNldGhyZWUvRzpcXGlvbmljXFxGSVZFUlJcXHBhbnRhbGxhcy1wYWNvL3NyY1xcYXBwXFxlbmN1ZXN0YXNcXG11bHRpY2hvaWNldGhyZWVcXG11bHRpY2hvaWNldGhyZWUucGFnZS5zY3NzIiwic3JjL2FwcC9lbmN1ZXN0YXMvbXVsdGljaG9pY2V0aHJlZS9tdWx0aWNob2ljZXRocmVlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGlCQUFBO0FDQUo7O0FER0E7RUFDRSxxQkFBQTtBQ0FGOztBRENFO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLCtDQUFBO0FDQ0o7O0FEQUk7RUFDRSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FDRU47O0FEQUk7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ0VOOztBREFJO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUNFTjs7QURBSTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0FDRU47O0FEQUk7RUFDRSxjQUFBO0FDRU47O0FEQVE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7QUNFVjs7QURHSTtFQUNFLHFCQUFBO0VBQ0EsOEJBQUE7RUFDQSwrQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUNETjs7QURJTTtFQUNFLGNBQUE7QUNGUjs7QURJTTtFQUNFLGdCQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0FDRlIiLCJmaWxlIjoic3JjL2FwcC9lbmN1ZXN0YXMvbXVsdGljaG9pY2V0aHJlZS9tdWx0aWNob2ljZXRocmVlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xyXG4gIGlvbi1idXR0b25zIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gIH1cclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gIC50ZXJtLWNvbnRlbnQge1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIHBhZGRpbmc6IDIwcHggMjVweDtcclxuICAgIG1hcmdpbjogMTZweCAyMHB4IDIwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgYm94LXNoYWRvdzogMCA3cHggMTZweCAtN3B4IHJnYmEoMCwgMCwgMCwgMC42OSk7XHJcbiAgICBoNSB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTdweDtcclxuICAgICAgbWFyZ2luLXRvcDogNnB4O1xyXG4gICAgICBjb2xvcjogIzJjNTVlMDtcclxuICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIH1cclxuICAgIGg2IHtcclxuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgfVxyXG4gICAgcCB7XHJcbiAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDIwcHg7XHJcbiAgICAgIGNvbG9yOiAjODA4MDgwO1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAycHg7XHJcbiAgICB9XHJcbiAgICBpb24tcHJvZ3Jlc3MtYmFyIHtcclxuICAgICAgbWFyZ2luOiAxNXB4IDAgOHB4O1xyXG4gICAgICBoZWlnaHQ6IDlweDtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgIH1cclxuICAgIGlvbi1zbGlkZXMge1xyXG4gICAgICBtYXJnaW46IDIwcHggMDtcclxuICAgICAgaW9uLXNsaWRlIHtcclxuICAgICAgICBoNiB7XHJcbiAgICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgICBmb250LXdlaWdodDogMTAwO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIC5hY3RpdmUge1xyXG4gICAgICB3aWR0aDogMjYlIWltcG9ydGFudDtcclxuICAgICAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCAjMmM1NWUwO1xyXG4gICAgICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjMmM1NWUwO1xyXG4gICAgICBjb2xvcjogIzJjNTVlMDtcclxuICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgfVxyXG4gICAgLmJ0bi1ib3R0b20ge1xyXG4gICAgICAuYnRuLXRyYW5zcGFyZW50IHtcclxuICAgICAgICBjb2xvcjogIzJjNTVlMDtcclxuICAgICAgfVxyXG4gICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICAgIHdpZHRoOiAxMDAlIWltcG9ydGFudDtcclxuICAgICAgICBoZWlnaHQ6IDNyZW07XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn0iLCJpb24taGVhZGVyIGlvbi1idXR0b25zIHtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHBhZGRpbmc6IDIwcHggMjVweDtcbiAgbWFyZ2luOiAxNnB4IDIwcHggMjBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaDUge1xuICBmb250LXNpemU6IDE3cHg7XG4gIG1hcmdpbi10b3A6IDZweDtcbiAgY29sb3I6ICMyYzU1ZTA7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGg2IHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBmb250LXdlaWdodDogNzAwO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBwIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBsaW5lLWhlaWdodDogMjBweDtcbiAgY29sb3I6ICM4MDgwODA7XG4gIG1hcmdpbi1ib3R0b206IDJweDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaW9uLXByb2dyZXNzLWJhciB7XG4gIG1hcmdpbjogMTVweCAwIDhweDtcbiAgaGVpZ2h0OiA5cHg7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGlvbi1zbGlkZXMge1xuICBtYXJnaW46IDIwcHggMDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaW9uLXNsaWRlcyBpb24tc2xpZGUgaDYge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5hY3RpdmUge1xuICB3aWR0aDogMjYlICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1sZWZ0OiAxcHggc29saWQgIzJjNTVlMDtcbiAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgIzJjNTVlMDtcbiAgY29sb3I6ICMyYzU1ZTA7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIGZvbnQtc2l6ZTogMTdweDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgLmJ0bi1ib3R0b20gLmJ0bi10cmFuc3BhcmVudCB7XG4gIGNvbG9yOiAjMmM1NWUwO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCAuYnRuLWJvdHRvbSBpb24tYnV0dG9uIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgaGVpZ2h0OiAzcmVtO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/encuestas/multichoicethree/multichoicethree.page.ts":
/*!*********************************************************************!*\
  !*** ./src/app/encuestas/multichoicethree/multichoicethree.page.ts ***!
  \*********************************************************************/
/*! exports provided: MultichoicethreePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultichoicethreePage", function() { return MultichoicethreePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let MultichoicethreePage = class MultichoicethreePage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
        this.slideOpts = {
            initialSlide: 5,
            speed: 800,
            autoplay: false,
            slidesPerView: 5,
            spaceBetween: 0,
        };
    }
    ngOnInit() {
    }
    SlideChanges(slide) {
        slide.getActiveIndex().then((index) => {
            this.activeIndex = index + 3;
            console.log(this.activeIndex);
        });
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
};
MultichoicethreePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('slides')
], MultichoicethreePage.prototype, "slides", void 0);
MultichoicethreePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-multichoicethree',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./multichoicethree.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/encuestas/multichoicethree/multichoicethree.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./multichoicethree.page.scss */ "./src/app/encuestas/multichoicethree/multichoicethree.page.scss")).default]
    })
], MultichoicethreePage);



/***/ })

}]);
//# sourceMappingURL=encuestas-multichoicethree-multichoicethree-module-es2015.js.map