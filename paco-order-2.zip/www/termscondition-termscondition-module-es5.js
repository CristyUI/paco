function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["termscondition-termscondition-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/termscondition/termscondition.page.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/termscondition/termscondition.page.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTermsconditionTermsconditionPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n <div class=\"term-content\">\n    <h5>Términos y condiciones</h5>\n   <p>Ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum libero ante aliquam sapien sed sed vitae vitae. Commodo egestas dapibus eu vel consequat. Elit maecenas quam sodales congue pharetra. Sed vulputate fringilla in ut vestibulum a lorem. Iaculis eu imperdiet vestibulum velit nunc dictumst pulvinar.\n     Turpis erat ut aliquet dignissim molestie ullamcorper et sed. Suspendisse ultrices nibh integer viverra arcu egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum libero ante aliquam sapien sed sed vitae vitae. Commodo egestas dapibus eu vel consequat. Elit maecenas quam sodales congue pharetra.\n     Ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum libero ante aliquam sapien sed sed vitae vitae. Commodo egestas dapibus eu vel consequat. Elit maecenas quam sodales congue pharetra. Sed vulputate fringilla in ut vestibulum a lorem.\n     Iaculis eu imperdiet vestibulum velit nunc dictumst pulvinar.</p>\n\n     <p>Vestibulum libero ante aliquam sapien sed sed vitae vitae. Commodo egestas dapibus eu vel consequat.\n       Elit maecenas quam sodales congue pharetra. </p>\n </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/termscondition/termscondition-routing.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/termscondition/termscondition-routing.module.ts ***!
    \*****************************************************************/

  /*! exports provided: TermsconditionPageRoutingModule */

  /***/
  function srcAppTermsconditionTermsconditionRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TermsconditionPageRoutingModule", function () {
      return TermsconditionPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _termscondition_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./termscondition.page */
    "./src/app/termscondition/termscondition.page.ts");

    var routes = [{
      path: '',
      component: _termscondition_page__WEBPACK_IMPORTED_MODULE_3__["TermsconditionPage"]
    }];

    var TermsconditionPageRoutingModule = function TermsconditionPageRoutingModule() {
      _classCallCheck(this, TermsconditionPageRoutingModule);
    };

    TermsconditionPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], TermsconditionPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/termscondition/termscondition.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/termscondition/termscondition.module.ts ***!
    \*********************************************************/

  /*! exports provided: TermsconditionPageModule */

  /***/
  function srcAppTermsconditionTermsconditionModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TermsconditionPageModule", function () {
      return TermsconditionPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _termscondition_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./termscondition-routing.module */
    "./src/app/termscondition/termscondition-routing.module.ts");
    /* harmony import */


    var _termscondition_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./termscondition.page */
    "./src/app/termscondition/termscondition.page.ts");

    var TermsconditionPageModule = function TermsconditionPageModule() {
      _classCallCheck(this, TermsconditionPageModule);
    };

    TermsconditionPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _termscondition_routing_module__WEBPACK_IMPORTED_MODULE_5__["TermsconditionPageRoutingModule"]],
      declarations: [_termscondition_page__WEBPACK_IMPORTED_MODULE_6__["TermsconditionPage"]]
    })], TermsconditionPageModule);
    /***/
  },

  /***/
  "./src/app/termscondition/termscondition.page.scss":
  /*!*********************************************************!*\
    !*** ./src/app/termscondition/termscondition.page.scss ***!
    \*********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppTermsconditionTermsconditionPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-content {\n  --background: #5176f3;\n}\nion-content .term-content {\n  background: #fff;\n  padding: 20px 25px;\n  margin: 20px;\n  border-radius: 20px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\nion-content .term-content h5 {\n  font-size: 17px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGVybXNjb25kaXRpb24vRzpcXGlvbmljXFxGSVZFUlJcXHBhbnRhbGxhcy1wYWNvL3NyY1xcYXBwXFx0ZXJtc2NvbmRpdGlvblxcdGVybXNjb25kaXRpb24ucGFnZS5zY3NzIiwic3JjL2FwcC90ZXJtc2NvbmRpdGlvbi90ZXJtc2NvbmRpdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtBQ0NGO0FEQUU7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsK0NBQUE7QUNFSjtBRERJO0VBQ0UsZUFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUNHTiIsImZpbGUiOiJzcmMvYXBwL3Rlcm1zY29uZGl0aW9uL3Rlcm1zY29uZGl0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XHJcbiAgLnRlcm0tY29udGVudCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgcGFkZGluZzogMjBweCAyNXB4O1xyXG4gICAgbWFyZ2luOiAyMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgIGJveC1zaGFkb3c6IDAgN3B4IDE2cHggLTdweCByZ2JhKDAsIDAsIDAsIDAuNjkpO1xyXG4gICAgaDUge1xyXG4gICAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDZweDtcclxuICAgICAgY29sb3I6ICMyYzU1ZTA7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICB9XHJcbiAgfVxyXG59IiwiaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgcGFkZGluZzogMjBweCAyNXB4O1xuICBtYXJnaW46IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIGJveC1zaGFkb3c6IDAgN3B4IDE2cHggLTdweCByZ2JhKDAsIDAsIDAsIDAuNjkpO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBoNSB7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBjb2xvcjogIzJjNTVlMDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/termscondition/termscondition.page.ts":
  /*!*******************************************************!*\
    !*** ./src/app/termscondition/termscondition.page.ts ***!
    \*******************************************************/

  /*! exports provided: TermsconditionPage */

  /***/
  function srcAppTermsconditionTermsconditionPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TermsconditionPage", function () {
      return TermsconditionPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var TermsconditionPage = /*#__PURE__*/function () {
      function TermsconditionPage() {
        _classCallCheck(this, TermsconditionPage);
      }

      _createClass(TermsconditionPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return TermsconditionPage;
    }();

    TermsconditionPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-termscondition',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./termscondition.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/termscondition/termscondition.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./termscondition.page.scss */
      "./src/app/termscondition/termscondition.page.scss"))["default"]]
    })], TermsconditionPage);
    /***/
  }
}]);
//# sourceMappingURL=termscondition-termscondition-module-es5.js.map