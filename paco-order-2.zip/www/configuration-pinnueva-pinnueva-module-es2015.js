(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["configuration-pinnueva-pinnueva-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/pinnueva/pinnueva.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/pinnueva/pinnueva.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Crea tu nueva PIN</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <p>Vivamus sit amet diam rhoncus, porttitor ex a, semper arcu. Pellentesque imperdiet.</p>\n    <ion-list>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n    </ion-list>\n    <div class=\"ion-text-end\">\n      <ion-button class=\"btn-transparent\" (click)=\"PageRoute('pinconfirmation')\"><ion-icon name=\"checkmark-outline\"></ion-icon></ion-button>\n\n      <!-- AFTER BUTTON ACTIVE -->\n      <!--<ion-button class=\"btn-white\" (click)=\"PageRoute('pinconfirmation')\"><ion-icon name=\"checkmark-outline\"></ion-icon></ion-button>-->\n    </div>\n  </div>\n</ion-content>\n\n");

/***/ }),

/***/ "./src/app/configuration/pinnueva/pinnueva-routing.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/configuration/pinnueva/pinnueva-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: PinnuevaPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PinnuevaPageRoutingModule", function() { return PinnuevaPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _pinnueva_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pinnueva.page */ "./src/app/configuration/pinnueva/pinnueva.page.ts");




const routes = [
    {
        path: '',
        component: _pinnueva_page__WEBPACK_IMPORTED_MODULE_3__["PinnuevaPage"]
    }
];
let PinnuevaPageRoutingModule = class PinnuevaPageRoutingModule {
};
PinnuevaPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PinnuevaPageRoutingModule);



/***/ }),

/***/ "./src/app/configuration/pinnueva/pinnueva.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/configuration/pinnueva/pinnueva.module.ts ***!
  \***********************************************************/
/*! exports provided: PinnuevaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PinnuevaPageModule", function() { return PinnuevaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _pinnueva_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pinnueva-routing.module */ "./src/app/configuration/pinnueva/pinnueva-routing.module.ts");
/* harmony import */ var _pinnueva_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pinnueva.page */ "./src/app/configuration/pinnueva/pinnueva.page.ts");







let PinnuevaPageModule = class PinnuevaPageModule {
};
PinnuevaPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _pinnueva_routing_module__WEBPACK_IMPORTED_MODULE_5__["PinnuevaPageRoutingModule"]
        ],
        declarations: [_pinnueva_page__WEBPACK_IMPORTED_MODULE_6__["PinnuevaPage"]]
    })
], PinnuevaPageModule);



/***/ }),

/***/ "./src/app/configuration/pinnueva/pinnueva.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/configuration/pinnueva/pinnueva.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #5176f3;\n}\nion-content .ion-padding {\n  text-align: center;\n}\nion-content .ion-padding p {\n  color: #fff;\n  font-size: 15px;\n  line-height: 23px;\n  margin-top: 30px;\n}\nion-content .ion-padding ion-list {\n  margin: 30px 10px 5px;\n  background: transparent;\n}\nion-content .ion-padding ion-list ion-item {\n  --background: #fff;\n  --border-color: transparent;\n  border-radius: 5px;\n  display: inline-block;\n  width: 50px;\n  margin: 0 5px;\n}\nion-content .ion-padding ion-list ion-item ion-input {\n  font-size: 15px;\n  color: #fff;\n  --padding-start: 14px;\n}\nion-content .ion-padding ion-list ion-item ion-input::-moz-placeholder {\n  color: #fff;\n}\nion-content .ion-padding ion-list ion-item ion-input::-ms-input-placeholder {\n  color: #fff;\n}\nion-content .ion-padding ion-list ion-item ion-input::placeholder {\n  color: #fff;\n}\nion-content .ion-padding .ion-text-end {\n  padding: 40px 20px 0;\n}\nion-content .ion-padding .ion-text-end .btn-transparent {\n  --background: transparent;\n  color: #0c38ce;\n  --padding-end: 0;\n  --padding-start: 0;\n  width: 60px !important;\n  height: 60px;\n}\nion-content .ion-padding .ion-text-end .btn-transparent ion-icon {\n  font-size: 35px;\n}\nion-content .ion-padding .ion-text-end .btn-white {\n  --background: #fff;\n  color: #5176f3;\n  --padding-end: 0;\n  --padding-start: 0;\n  width: 60px !important;\n  height: 60px;\n}\nion-content .ion-padding .ion-text-end .btn-white ion-icon {\n  font-size: 35px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29uZmlndXJhdGlvbi9waW5udWV2YS9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXGNvbmZpZ3VyYXRpb25cXHBpbm51ZXZhXFxwaW5udWV2YS5wYWdlLnNjc3MiLCJzcmMvYXBwL2NvbmZpZ3VyYXRpb24vcGlubnVldmEvcGlubnVldmEucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQUE7QUNDRjtBREFFO0VBQ0Usa0JBQUE7QUNFSjtBRERJO0VBQ0UsV0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FDR047QURESTtFQUNFLHFCQUFBO0VBQ0EsdUJBQUE7QUNHTjtBREZNO0VBQ0Usa0JBQUE7RUFDQSwyQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtBQ0lSO0FESFE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0FDS1Y7QURKVTtFQUNFLFdBQUE7QUNNWjtBRFBVO0VBQ0UsV0FBQTtBQ01aO0FEUFU7RUFDRSxXQUFBO0FDTVo7QURESTtFQUNFLG9CQUFBO0FDR047QURGTTtFQUNFLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7QUNJUjtBREhRO0VBQ0UsZUFBQTtBQ0tWO0FERk07RUFDRSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0FDSVI7QURIUTtFQUNFLGVBQUE7QUNLViIsImZpbGUiOiJzcmMvYXBwL2NvbmZpZ3VyYXRpb24vcGlubnVldmEvcGlubnVldmEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcclxuICAuaW9uLXBhZGRpbmcge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcCB7XHJcbiAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgIGxpbmUtaGVpZ2h0OiAyM3B4O1xyXG4gICAgICBtYXJnaW4tdG9wOiAzMHB4O1xyXG4gICAgfVxyXG4gICAgaW9uLWxpc3Qge1xyXG4gICAgICBtYXJnaW46IDMwcHggMTBweCA1cHg7XHJcbiAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICBpb24taXRlbSB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgICAgIG1hcmdpbjogMCA1cHg7XHJcbiAgICAgICAgaW9uLWlucHV0IHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxNHB4O1xyXG4gICAgICAgICAgJjo6cGxhY2Vob2xkZXIge1xyXG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5pb24tdGV4dC1lbmQge1xyXG4gICAgICBwYWRkaW5nOiA0MHB4IDIwcHggMDtcclxuICAgICAgLmJ0bi10cmFuc3BhcmVudCB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgICBjb2xvcjogIzBjMzhjZTtcclxuICAgICAgICAtLXBhZGRpbmctZW5kOiAwO1xyXG4gICAgICAgIC0tcGFkZGluZy1zdGFydDogMDtcclxuICAgICAgICB3aWR0aDogNjBweCFpbXBvcnRhbnQ7XHJcbiAgICAgICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMzVweDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgLmJ0bi13aGl0ZSB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgICAgIGNvbG9yOiAjNTE3NmYzO1xyXG4gICAgICAgIC0tcGFkZGluZy1lbmQ6IDA7XHJcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xyXG4gICAgICAgIHdpZHRoOiA2MHB4IWltcG9ydGFudDtcclxuICAgICAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgZm9udC1zaXplOiAzNXB4O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufSIsImlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIHAge1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBsaW5lLWhlaWdodDogMjNweDtcbiAgbWFyZ2luLXRvcDogMzBweDtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyBpb24tbGlzdCB7XG4gIG1hcmdpbjogMzBweCAxMHB4IDVweDtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgaW9uLWxpc3QgaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6ICNmZmY7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiA1MHB4O1xuICBtYXJnaW46IDAgNXB4O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIGlvbi1saXN0IGlvbi1pdGVtIGlvbi1pbnB1dCB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgY29sb3I6ICNmZmY7XG4gIC0tcGFkZGluZy1zdGFydDogMTRweDtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyBpb24tbGlzdCBpb24taXRlbSBpb24taW5wdXQ6OnBsYWNlaG9sZGVyIHtcbiAgY29sb3I6ICNmZmY7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgLmlvbi10ZXh0LWVuZCB7XG4gIHBhZGRpbmc6IDQwcHggMjBweCAwO1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIC5pb24tdGV4dC1lbmQgLmJ0bi10cmFuc3BhcmVudCB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIGNvbG9yOiAjMGMzOGNlO1xuICAtLXBhZGRpbmctZW5kOiAwO1xuICAtLXBhZGRpbmctc3RhcnQ6IDA7XG4gIHdpZHRoOiA2MHB4ICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogNjBweDtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyAuaW9uLXRleHQtZW5kIC5idG4tdHJhbnNwYXJlbnQgaW9uLWljb24ge1xuICBmb250LXNpemU6IDM1cHg7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgLmlvbi10ZXh0LWVuZCAuYnRuLXdoaXRlIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xuICBjb2xvcjogIzUxNzZmMztcbiAgLS1wYWRkaW5nLWVuZDogMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICB3aWR0aDogNjBweCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDYwcHg7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgLmlvbi10ZXh0LWVuZCAuYnRuLXdoaXRlIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAzNXB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/configuration/pinnueva/pinnueva.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/configuration/pinnueva/pinnueva.page.ts ***!
  \*********************************************************/
/*! exports provided: PinnuevaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PinnuevaPage", function() { return PinnuevaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let PinnuevaPage = class PinnuevaPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
};
PinnuevaPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
PinnuevaPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-pinnueva',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./pinnueva.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/pinnueva/pinnueva.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./pinnueva.page.scss */ "./src/app/configuration/pinnueva/pinnueva.page.scss")).default]
    })
], PinnuevaPage);



/***/ })

}]);
//# sourceMappingURL=configuration-pinnueva-pinnueva-module-es2015.js.map