(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["recibosdenomia-recibomain-recibomain-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/recibosdenomia/recibomain/recibomain.page.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/recibosdenomia/recibomain/recibomain.page.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" (click)=\"PageRoute('home')\">\n      <ion-icon name=\"chevron-back-outline\" color=\"secondary\" style=\"margin-top: 4px;\"></ion-icon>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Recibos de nómina</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <div class=\"filter-area\" (click)=\"sortby()\">\n      <p>Ordenar por<span><ion-icon name=\"chevron-down-outline\"></ion-icon></span></p>\n    </div>\n    <h4>Septiembre</h4>\n    <div class=\"list-category\">\n      <ul>\n        <li (click)=\"PageRoute('recibodetails')\">\n          <h5>Del 01/SEP al 15/SEP<span><ion-icon name=\"chevron-forward-outline\" color=\"secondary\"></ion-icon></span></h5>\n          <p>06-06-2019 <span>18:24</span></p>\n        </li>\n      </ul>\n    </div>\n    <h4>Fondo</h4>\n    <div class=\"list-category\">\n      <ul>\n        <li (click)=\"PageRoute('recibodetails')\">\n          <h5>Del 16/AGO al 31/AGO<span><ion-icon name=\"chevron-forward-outline\" color=\"secondary\"></ion-icon></span></h5>\n          <p>27-01-2019 <span>18:24</span></p>\n        </li>\n        <li (click)=\"PageRoute('recibodetails')\">\n          <h5>Del 01/AGO al 15/AGO<span><ion-icon name=\"chevron-forward-outline\" color=\"secondary\"></ion-icon></span></h5>\n          <p>14-12-2018 <span>18:24</span></p>\n        </li>\n      </ul>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/recibosdenomia/recibomain/recibomain-routing.module.ts":
/*!************************************************************************!*\
  !*** ./src/app/recibosdenomia/recibomain/recibomain-routing.module.ts ***!
  \************************************************************************/
/*! exports provided: RecibomainPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecibomainPageRoutingModule", function() { return RecibomainPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _recibomain_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./recibomain.page */ "./src/app/recibosdenomia/recibomain/recibomain.page.ts");




const routes = [
    {
        path: '',
        component: _recibomain_page__WEBPACK_IMPORTED_MODULE_3__["RecibomainPage"]
    }
];
let RecibomainPageRoutingModule = class RecibomainPageRoutingModule {
};
RecibomainPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RecibomainPageRoutingModule);



/***/ }),

/***/ "./src/app/recibosdenomia/recibomain/recibomain.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/recibosdenomia/recibomain/recibomain.module.ts ***!
  \****************************************************************/
/*! exports provided: RecibomainPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecibomainPageModule", function() { return RecibomainPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _recibomain_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./recibomain-routing.module */ "./src/app/recibosdenomia/recibomain/recibomain-routing.module.ts");
/* harmony import */ var _recibomain_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./recibomain.page */ "./src/app/recibosdenomia/recibomain/recibomain.page.ts");







let RecibomainPageModule = class RecibomainPageModule {
};
RecibomainPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _recibomain_routing_module__WEBPACK_IMPORTED_MODULE_5__["RecibomainPageRoutingModule"]
        ],
        declarations: [_recibomain_page__WEBPACK_IMPORTED_MODULE_6__["RecibomainPage"]]
    })
], RecibomainPageModule);



/***/ }),

/***/ "./src/app/recibosdenomia/recibomain/recibomain.page.scss":
/*!****************************************************************!*\
  !*** ./src/app/recibosdenomia/recibomain/recibomain.page.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-title {\n  font-weight: 600;\n}\nion-header ion-buttons {\n  margin-left: 20px;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.filter-area {\n  padding: 10px 0 5px;\n}\n.filter-area p {\n  border: 1px solid #8ca3f1;\n  padding: 13px 20px;\n  margin: 0;\n  border-radius: 30px;\n  width: 48%;\n  color: #797979;\n}\n.filter-area p span {\n  float: right;\n  font-size: 17px;\n  position: relative;\n  top: 2px;\n  color: #2d5eb7;\n}\nh4 {\n  font-size: 15px;\n  padding-left: 4px;\n  margin-top: 22px;\n}\n.list-category ul {\n  padding-left: 0;\n  position: relative;\n  margin: 20px 0 36px;\n}\n.list-category ul li {\n  list-style-type: none;\n  padding-left: 4px;\n}\n.list-category ul li h5 {\n  font-weight: 600;\n  font-size: 15px;\n  margin-bottom: 5px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.list-category ul li h5 span {\n  position: absolute;\n  margin-top: 2px;\n  font-size: 18px;\n  right: 0;\n}\n.list-category ul li p {\n  font-size: 14px;\n  line-height: 20px;\n  color: #757474;\n  margin: 6px 0;\n}\n.list-category ul li p span {\n  margin-left: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVjaWJvc2Rlbm9taWEvcmVjaWJvbWFpbi9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXHJlY2lib3NkZW5vbWlhXFxyZWNpYm9tYWluXFxyZWNpYm9tYWluLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcmVjaWJvc2Rlbm9taWEvcmVjaWJvbWFpbi9yZWNpYm9tYWluLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGdCQUFBO0FDQUo7QURFRTtFQUNFLGlCQUFBO0FDQUo7QURHSTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDRE47QURLQTtFQUNFLG1CQUFBO0FDRkY7QURHRTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsbUJBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtBQ0RKO0FERUk7RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLGNBQUE7QUNBTjtBRElBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUNERjtBRElFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUNESjtBREVJO0VBQ0UscUJBQUE7RUFDQSxpQkFBQTtBQ0FOO0FEQ007RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQ0NSO0FEQVE7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBQ0EsUUFBQTtBQ0VWO0FEQ007RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtBQ0NSO0FEQVE7RUFDRSxpQkFBQTtBQ0VWIiwiZmlsZSI6InNyYy9hcHAvcmVjaWJvc2Rlbm9taWEvcmVjaWJvbWFpbi9yZWNpYm9tYWluLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xyXG4gIGlvbi10aXRsZSB7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gIH1cclxuICBpb24tYnV0dG9ucyB7XHJcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcclxuICB9XHJcbiAgLmJ0bi1yaWdodCB7XHJcbiAgICAuYWxlcnQtdGFnIHtcclxuICAgICAgd2lkdGg6IDEycHg7XHJcbiAgICAgIGhlaWdodDogMTJweDtcclxuICAgICAgYmFja2dyb3VuZDogI2ZiNGYzMztcclxuICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICByaWdodDogLTNweDtcclxuICAgICAgYm90dG9tOiAtMnB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4uZmlsdGVyLWFyZWEge1xyXG4gIHBhZGRpbmc6IDEwcHggMCA1cHg7XHJcbiAgcCB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjOGNhM2YxO1xyXG4gICAgcGFkZGluZzogMTNweCAyMHB4O1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIHdpZHRoOiA0OCU7XHJcbiAgICBjb2xvcjogIzc5Nzk3OTtcclxuICAgIHNwYW4ge1xyXG4gICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTdweDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICB0b3A6IDJweDtcclxuICAgICAgY29sb3I6ICMyZDVlYjc7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbmg0IHtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbiAgcGFkZGluZy1sZWZ0OiA0cHg7XHJcbiAgbWFyZ2luLXRvcDogMjJweDtcclxufVxyXG4ubGlzdC1jYXRlZ29yeSB7XHJcbiAgdWwge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAwO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgbWFyZ2luOiAyMHB4IDAgMzZweDtcclxuICAgIGxpIHtcclxuICAgICAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xyXG4gICAgICBwYWRkaW5nLWxlZnQ6IDRweDtcclxuICAgICAgaDUge1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxuICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgICAgICAgc3BhbiB7XHJcbiAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICBtYXJnaW4tdG9wOiAycHg7XHJcbiAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICByaWdodDogMDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgcCB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG4gICAgICAgIGNvbG9yOiAjNzU3NDc0O1xyXG4gICAgICAgIG1hcmdpbjogNnB4IDA7XHJcbiAgICAgICAgc3BhbiB7XHJcbiAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn0iLCJpb24taGVhZGVyIGlvbi10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5pb24taGVhZGVyIGlvbi1idXR0b25zIHtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG59XG5pb24taGVhZGVyIC5idG4tcmlnaHQgLmFsZXJ0LXRhZyB7XG4gIHdpZHRoOiAxMnB4O1xuICBoZWlnaHQ6IDEycHg7XG4gIGJhY2tncm91bmQ6ICNmYjRmMzM7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IC0zcHg7XG4gIGJvdHRvbTogLTJweDtcbn1cblxuLmZpbHRlci1hcmVhIHtcbiAgcGFkZGluZzogMTBweCAwIDVweDtcbn1cbi5maWx0ZXItYXJlYSBwIHtcbiAgYm9yZGVyOiAxcHggc29saWQgIzhjYTNmMTtcbiAgcGFkZGluZzogMTNweCAyMHB4O1xuICBtYXJnaW46IDA7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIHdpZHRoOiA0OCU7XG4gIGNvbG9yOiAjNzk3OTc5O1xufVxuLmZpbHRlci1hcmVhIHAgc3BhbiB7XG4gIGZsb2F0OiByaWdodDtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogMnB4O1xuICBjb2xvcjogIzJkNWViNztcbn1cblxuaDQge1xuICBmb250LXNpemU6IDE1cHg7XG4gIHBhZGRpbmctbGVmdDogNHB4O1xuICBtYXJnaW4tdG9wOiAyMnB4O1xufVxuXG4ubGlzdC1jYXRlZ29yeSB1bCB7XG4gIHBhZGRpbmctbGVmdDogMDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBtYXJnaW46IDIwcHggMCAzNnB4O1xufVxuLmxpc3QtY2F0ZWdvcnkgdWwgbGkge1xuICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XG4gIHBhZGRpbmctbGVmdDogNHB4O1xufVxuLmxpc3QtY2F0ZWdvcnkgdWwgbGkgaDUge1xuICBmb250LXdlaWdodDogNjAwO1xuICBmb250LXNpemU6IDE1cHg7XG4gIG1hcmdpbi1ib3R0b206IDVweDtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG59XG4ubGlzdC1jYXRlZ29yeSB1bCBsaSBoNSBzcGFuIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBtYXJnaW4tdG9wOiAycHg7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgcmlnaHQ6IDA7XG59XG4ubGlzdC1jYXRlZ29yeSB1bCBsaSBwIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBsaW5lLWhlaWdodDogMjBweDtcbiAgY29sb3I6ICM3NTc0NzQ7XG4gIG1hcmdpbjogNnB4IDA7XG59XG4ubGlzdC1jYXRlZ29yeSB1bCBsaSBwIHNwYW4ge1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/recibosdenomia/recibomain/recibomain.page.ts":
/*!**************************************************************!*\
  !*** ./src/app/recibosdenomia/recibomain/recibomain.page.ts ***!
  \**************************************************************/
/*! exports provided: RecibomainPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecibomainPage", function() { return RecibomainPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");





let RecibomainPage = class RecibomainPage {
    constructor(router, menuCtrl, actionSheetController) {
        this.router = router;
        this.menuCtrl = menuCtrl;
        this.actionSheetController = actionSheetController;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
    sortby() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: 'Sort By',
                mode: 'ios',
                buttons: [{
                        text: 'Oldest',
                        handler: () => {
                            console.log('Oldest clicked');
                        }
                    }, {
                        text: 'Newest',
                        handler: () => {
                            console.log('Newest clicked');
                        }
                    }, {
                        text: 'Recently Viewed',
                        handler: () => {
                            console.log('Recently Viewed clicked');
                        }
                    },
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        }
                    },]
            });
            yield actionSheet.present();
        });
    }
};
RecibomainPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"] }
];
RecibomainPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-recibomain',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./recibomain.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/recibosdenomia/recibomain/recibomain.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./recibomain.page.scss */ "./src/app/recibosdenomia/recibomain/recibomain.page.scss")).default]
    })
], RecibomainPage);



/***/ })

}]);
//# sourceMappingURL=recibosdenomia-recibomain-recibomain-module-es2015.js.map