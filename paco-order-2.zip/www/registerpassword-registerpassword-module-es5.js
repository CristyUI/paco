function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["registerpassword-registerpassword-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/registerpassword/registerpassword.page.html":
  /*!***************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/registerpassword/registerpassword.page.html ***!
    \***************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRegisterpasswordRegisterpasswordPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Crea tu contraseña</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"help-circle-outline\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <img src=\"assets/imgs/reg-pass.png\" alt=\"\">\n    <p>Usarás tu contraseña para ingresar a la app.</p>\n    <ion-list>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"{{type}}\" placeholder=\"Contraña\"></ion-input>\n        <button *ngIf=\"!showPass\" type=\"button\" class=\"eye-btn\" (click)=\"showPassword()\">\n          <ion-icon name=\"eye-outline\"></ion-icon>\n        </button>\n        <button *ngIf=\"showPass\" type=\"button\" class=\"eye-btn\" (click)=\"showPassword()\">\n          <ion-icon name=\"eye-off-outline\"></ion-icon>\n        </button>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"{{type}}\" placeholder=\"Confirmar contraña\"></ion-input>\n        <button *ngIf=\"!showPass\" type=\"button\" class=\"eye-btn\" (click)=\"showPassword()\">\n          <ion-icon name=\"eye-outline\"></ion-icon>\n        </button>\n        <button *ngIf=\"showPass\" type=\"button\" class=\"eye-btn\" (click)=\"showPassword()\">\n          <ion-icon name=\"eye-off-outline\"></ion-icon>\n        </button>\n      </ion-item>\n    </ion-list>\n    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris congue nunc lectus, quis tristique.</p>\n     <div class=\"check-link\" [ngClass]=\"{'active': !active}\">\n       <ion-list>\n         <ion-item>\n           <ion-label>He leído y acepto  el <ion-button (click)=\"PageRoute('termscondition')\">aviso de privacidad</ion-button> y <ion-button (click)=\"PageRoute('termscondition')\">términos y condiciones</ion-button>.</ion-label>\n           <ion-checkbox (ionChange)=\"changeEvent($event)\"></ion-checkbox>\n         </ion-item>\n       </ion-list>\n     </div>\n\n  </div>\n</ion-content>\n\n<ion-footer>\n   <div class=\"ion-text-end\">\n     <ion-button class=\"btn-inactive\" [ngClass]=\"{'btn-white': !active}\" (click)=\"PageRoute('pincreate')\">Continuar</ion-button>\n   </div>\n</ion-footer>\n";
    /***/
  },

  /***/
  "./src/app/registerpassword/registerpassword-routing.module.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/registerpassword/registerpassword-routing.module.ts ***!
    \*********************************************************************/

  /*! exports provided: RegisterpasswordPageRoutingModule */

  /***/
  function srcAppRegisterpasswordRegisterpasswordRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RegisterpasswordPageRoutingModule", function () {
      return RegisterpasswordPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _registerpassword_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./registerpassword.page */
    "./src/app/registerpassword/registerpassword.page.ts");

    var routes = [{
      path: '',
      component: _registerpassword_page__WEBPACK_IMPORTED_MODULE_3__["RegisterpasswordPage"]
    }];

    var RegisterpasswordPageRoutingModule = function RegisterpasswordPageRoutingModule() {
      _classCallCheck(this, RegisterpasswordPageRoutingModule);
    };

    RegisterpasswordPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], RegisterpasswordPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/registerpassword/registerpassword.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/registerpassword/registerpassword.module.ts ***!
    \*************************************************************/

  /*! exports provided: RegisterpasswordPageModule */

  /***/
  function srcAppRegisterpasswordRegisterpasswordModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RegisterpasswordPageModule", function () {
      return RegisterpasswordPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _registerpassword_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./registerpassword-routing.module */
    "./src/app/registerpassword/registerpassword-routing.module.ts");
    /* harmony import */


    var _registerpassword_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./registerpassword.page */
    "./src/app/registerpassword/registerpassword.page.ts");

    var RegisterpasswordPageModule = function RegisterpasswordPageModule() {
      _classCallCheck(this, RegisterpasswordPageModule);
    };

    RegisterpasswordPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _registerpassword_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegisterpasswordPageRoutingModule"]],
      declarations: [_registerpassword_page__WEBPACK_IMPORTED_MODULE_6__["RegisterpasswordPage"]]
    })], RegisterpasswordPageModule);
    /***/
  },

  /***/
  "./src/app/registerpassword/registerpassword.page.scss":
  /*!*************************************************************!*\
    !*** ./src/app/registerpassword/registerpassword.page.scss ***!
    \*************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRegisterpasswordRegisterpasswordPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header .btn-right ion-icon {\n  font-size: 24px;\n}\n\nion-content {\n  --background: #5176f3;\n}\n\nion-content .ion-padding {\n  text-align: center;\n}\n\nion-content .ion-padding img {\n  margin: 0 0 10px;\n  width: 150px;\n}\n\nion-content .ion-padding p {\n  color: #fff;\n  margin-top: 0;\n  font-size: 14px;\n  line-height: 22px;\n  margin-bottom: 4px;\n  text-align: left;\n  padding: 0 6px;\n}\n\nion-content .ion-padding ion-list {\n  margin: 16px 2px 0;\n  background: transparent;\n}\n\nion-content .ion-padding ion-list ion-item {\n  --background: transparent;\n  margin-bottom: 12px;\n  --border-color: transparent;\n  border: 1px solid #fff;\n  border-radius: 30px;\n}\n\nion-content .ion-padding ion-list ion-item ion-input {\n  font-size: 15px;\n  color: #fff;\n  --padding-start: 14px;\n}\n\nion-content .ion-padding ion-list ion-item ion-input::-moz-placeholder {\n  color: #fff;\n}\n\nion-content .ion-padding ion-list ion-item ion-input::-ms-input-placeholder {\n  color: #fff;\n}\n\nion-content .ion-padding ion-list ion-item ion-input::placeholder {\n  color: #fff;\n}\n\nion-content .ion-padding ion-list .eye-btn {\n  background: transparent;\n}\n\nion-content .ion-padding ion-list .eye-btn ion-icon {\n  font-size: 25px;\n  color: #fff;\n}\n\nion-content .ion-padding .check-link ion-item {\n  border: 1px solid transparent;\n  --padding-end: 0;\n  --padding-start: 0;\n  border-radius: 30px;\n  --min-height: 46px;\n}\n\nion-content .ion-padding .check-link ion-item ion-label {\n  color: #fff;\n  white-space: inherit;\n  font-size: 14px;\n  margin: 0 6px 0 4px;\n  text-align: center;\n  padding: 6px;\n}\n\nion-content .ion-padding .check-link ion-item ion-label ion-button {\n  --background: transparent;\n  --box-shadow: none;\n  --border-radius: 0;\n  --padding-start: 0;\n  --padding-end: 0;\n  font-weight: 100;\n  border-bottom: 1px solid #fff;\n  height: auto;\n  margin: 0;\n  font-size: 13px;\n  position: relative;\n  top: -5px;\n}\n\nion-content .ion-padding .check-link ion-item ion-checkbox {\n  --border-radius: 50%;\n}\n\nion-content .ion-padding .active ion-item {\n  --background: #fff;\n}\n\nion-content .ion-padding .active ion-item ion-label {\n  color: #041e77;\n}\n\nion-content .ion-padding .active ion-item ion-label ion-button {\n  color: #041e77;\n  border-bottom: 1px solid #041e77;\n}\n\nion-footer {\n  text-align: center;\n  background: #5176f3;\n}\n\nion-footer::before {\n  background-image: none !important;\n}\n\nion-footer .ion-text-end {\n  padding: 5px 20px;\n}\n\nion-footer .btn-inactive {\n  margin-top: 5px;\n  --background: transparent;\n  color: #14329a;\n  --box-shadow: none;\n  width: 40% !important;\n  font-size: 1rem;\n}\n\nion-footer .btn-white {\n  --background: #fff;\n  color: #2f57de;\n  width: 40% !important;\n  margin-top: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVnaXN0ZXJwYXNzd29yZC9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXHJlZ2lzdGVycGFzc3dvcmRcXHJlZ2lzdGVycGFzc3dvcmQucGFnZS5zY3NzIiwic3JjL2FwcC9yZWdpc3RlcnBhc3N3b3JkL3JlZ2lzdGVycGFzc3dvcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQ0UsZUFBQTtBQ0ROOztBREtBO0VBQ0UscUJBQUE7QUNGRjs7QURHRTtFQUNFLGtCQUFBO0FDREo7O0FERUk7RUFDRSxnQkFBQTtFQUNBLFlBQUE7QUNBTjs7QURFSTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNBTjs7QURFSTtFQUNFLGtCQUFBO0VBQ0EsdUJBQUE7QUNBTjs7QURDTTtFQUNFLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQkFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7QUNDUjs7QURBUTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7QUNFVjs7QUREVTtFQUNFLFdBQUE7QUNHWjs7QURKVTtFQUNFLFdBQUE7QUNHWjs7QURKVTtFQUNFLFdBQUE7QUNHWjs7QURDTTtFQUNFLHVCQUFBO0FDQ1I7O0FEQVE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtBQ0VWOztBREdNO0VBQ0UsNkJBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQ0RSOztBREVRO0VBQ0UsV0FBQTtFQUNBLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FDQVY7O0FEQ1U7RUFDRSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2QkFBQTtFQUNBLFlBQUE7RUFDQSxTQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtBQ0NaOztBREVRO0VBQ0Usb0JBQUE7QUNBVjs7QURLTTtFQUNFLGtCQUFBO0FDSFI7O0FESVE7RUFDRSxjQUFBO0FDRlY7O0FER1U7RUFDRSxjQUFBO0VBQ0EsZ0NBQUE7QUNEWjs7QURTQTtFQUlFLGtCQUFBO0VBQ0EsbUJBQUE7QUNURjs7QURLRTtFQUNFLGlDQUFBO0FDSEo7O0FET0U7RUFDRSxpQkFBQTtBQ0xKOztBRE9FO0VBQ0UsZUFBQTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0FDTEo7O0FET0U7RUFDRSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxxQkFBQTtFQUNBLGVBQUE7QUNMSiIsImZpbGUiOiJzcmMvYXBwL3JlZ2lzdGVycGFzc3dvcmQvcmVnaXN0ZXJwYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICAuYnRuLXJpZ2h0IHtcclxuICAgIGlvbi1pY29uIHtcclxuICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gIC5pb24tcGFkZGluZyB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBpbWcge1xyXG4gICAgICBtYXJnaW46IDAgMCAxMHB4O1xyXG4gICAgICB3aWR0aDogMTUwcHg7XHJcbiAgICB9XHJcbiAgICBwIHtcclxuICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgIG1hcmdpbi10b3A6IDA7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDRweDtcclxuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgcGFkZGluZzogMCA2cHg7XHJcbiAgICB9XHJcbiAgICBpb24tbGlzdCB7XHJcbiAgICAgIG1hcmdpbjogMTZweCAycHggMDtcclxuICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgIGlvbi1pdGVtIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDEycHg7XHJcbiAgICAgICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgICAgICBpb24taW5wdXQge1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDE0cHg7XHJcbiAgICAgICAgICAmOjpwbGFjZWhvbGRlciB7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAuZXllLWJ0biB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgZm9udC1zaXplOjI1cHg7XHJcbiAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5jaGVjay1saW5rIHtcclxuICAgICAgaW9uLWl0ZW0ge1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gICAgICAgIC0tcGFkZGluZy1lbmQ6IDA7XHJcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICAgICAgLS1taW4taGVpZ2h0OiA0NnB4O1xyXG4gICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICAgIHdoaXRlLXNwYWNlOiBpbmhlcml0O1xyXG4gICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgICAgbWFyZ2luOiAwIDZweCAwIDRweDtcclxuICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgIHBhZGRpbmc6IDZweDtcclxuICAgICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogMDtcclxuICAgICAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xyXG4gICAgICAgICAgICAtLXBhZGRpbmctZW5kOiAwO1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogMTAwO1xyXG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2ZmZjtcclxuICAgICAgICAgICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgICB0b3A6IC01cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlvbi1jaGVja2JveCB7XHJcbiAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5hY3RpdmUge1xyXG4gICAgICBpb24taXRlbSB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICBjb2xvcjogIzA0MWU3NztcclxuICAgICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgICBjb2xvcjogIzA0MWU3NztcclxuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMwNDFlNzc7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5pb24tZm9vdGVyIHtcclxuICAmOjpiZWZvcmUge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogbm9uZSFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gIC5pb24tdGV4dC1lbmQge1xyXG4gICAgcGFkZGluZzogNXB4IDIwcHg7XHJcbiAgfVxyXG4gIC5idG4taW5hY3RpdmUge1xyXG4gICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGNvbG9yOiAjMTQzMjlhO1xyXG4gICAgLS1ib3gtc2hhZG93OiBub25lO1xyXG4gICAgd2lkdGg6IDQwJSFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXNpemU6IDFyZW07XHJcbiAgfVxyXG4gIC5idG4td2hpdGUge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgY29sb3I6ICMyZjU3ZGU7XHJcbiAgICB3aWR0aDogNDAlIWltcG9ydGFudDtcclxuICAgIG1hcmdpbi10b3A6IDVweDtcclxuICB9XHJcbn0iLCJpb24taGVhZGVyIC5idG4tcmlnaHQgaW9uLWljb24ge1xuICBmb250LXNpemU6IDI0cHg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIGltZyB7XG4gIG1hcmdpbjogMCAwIDEwcHg7XG4gIHdpZHRoOiAxNTBweDtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyBwIHtcbiAgY29sb3I6ICNmZmY7XG4gIG1hcmdpbi10b3A6IDA7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgbGluZS1oZWlnaHQ6IDIycHg7XG4gIG1hcmdpbi1ib3R0b206IDRweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgcGFkZGluZzogMCA2cHg7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgaW9uLWxpc3Qge1xuICBtYXJnaW46IDE2cHggMnB4IDA7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIGlvbi1saXN0IGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgbWFyZ2luLWJvdHRvbTogMTJweDtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZmZmO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIGlvbi1saXN0IGlvbi1pdGVtIGlvbi1pbnB1dCB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgY29sb3I6ICNmZmY7XG4gIC0tcGFkZGluZy1zdGFydDogMTRweDtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyBpb24tbGlzdCBpb24taXRlbSBpb24taW5wdXQ6OnBsYWNlaG9sZGVyIHtcbiAgY29sb3I6ICNmZmY7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgaW9uLWxpc3QgLmV5ZS1idG4ge1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyBpb24tbGlzdCAuZXllLWJ0biBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjVweDtcbiAgY29sb3I6ICNmZmY7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgLmNoZWNrLWxpbmsgaW9uLWl0ZW0ge1xuICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDtcbiAgLS1wYWRkaW5nLWVuZDogMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICAtLW1pbi1oZWlnaHQ6IDQ2cHg7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgLmNoZWNrLWxpbmsgaW9uLWl0ZW0gaW9uLWxhYmVsIHtcbiAgY29sb3I6ICNmZmY7XG4gIHdoaXRlLXNwYWNlOiBpbmhlcml0O1xuICBmb250LXNpemU6IDE0cHg7XG4gIG1hcmdpbjogMCA2cHggMCA0cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogNnB4O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIC5jaGVjay1saW5rIGlvbi1pdGVtIGlvbi1sYWJlbCBpb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgLS1ib3gtc2hhZG93OiBub25lO1xuICAtLWJvcmRlci1yYWRpdXM6IDA7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgLS1wYWRkaW5nLWVuZDogMDtcbiAgZm9udC13ZWlnaHQ6IDEwMDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNmZmY7XG4gIGhlaWdodDogYXV0bztcbiAgbWFyZ2luOiAwO1xuICBmb250LXNpemU6IDEzcHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdG9wOiAtNXB4O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIC5jaGVjay1saW5rIGlvbi1pdGVtIGlvbi1jaGVja2JveCB7XG4gIC0tYm9yZGVyLXJhZGl1czogNTAlO1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIC5hY3RpdmUgaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6ICNmZmY7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgLmFjdGl2ZSBpb24taXRlbSBpb24tbGFiZWwge1xuICBjb2xvcjogIzA0MWU3Nztcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyAuYWN0aXZlIGlvbi1pdGVtIGlvbi1sYWJlbCBpb24tYnV0dG9uIHtcbiAgY29sb3I6ICMwNDFlNzc7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMDQxZTc3O1xufVxuXG5pb24tZm9vdGVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiAjNTE3NmYzO1xufVxuaW9uLWZvb3Rlcjo6YmVmb3JlIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZSAhaW1wb3J0YW50O1xufVxuaW9uLWZvb3RlciAuaW9uLXRleHQtZW5kIHtcbiAgcGFkZGluZzogNXB4IDIwcHg7XG59XG5pb24tZm9vdGVyIC5idG4taW5hY3RpdmUge1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIGNvbG9yOiAjMTQzMjlhO1xuICAtLWJveC1zaGFkb3c6IG5vbmU7XG4gIHdpZHRoOiA0MCUgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxcmVtO1xufVxuaW9uLWZvb3RlciAuYnRuLXdoaXRlIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xuICBjb2xvcjogIzJmNTdkZTtcbiAgd2lkdGg6IDQwJSAhaW1wb3J0YW50O1xuICBtYXJnaW4tdG9wOiA1cHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/registerpassword/registerpassword.page.ts":
  /*!***********************************************************!*\
    !*** ./src/app/registerpassword/registerpassword.page.ts ***!
    \***********************************************************/

  /*! exports provided: RegisterpasswordPage */

  /***/
  function srcAppRegisterpasswordRegisterpasswordPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RegisterpasswordPage", function () {
      return RegisterpasswordPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var RegisterpasswordPage = /*#__PURE__*/function () {
      function RegisterpasswordPage(router, menuCtrl) {
        _classCallCheck(this, RegisterpasswordPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
        this.type = 'password';
        this.showPass = false;
        this.isToggled = false;
        this.active = true;
      }

      _createClass(RegisterpasswordPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "showPassword",
        value: function showPassword() {
          this.showPass = !this.showPass;

          if (this.showPass) {
            this.type = 'text';
          } else {
            this.type = 'password';
          }
        }
      }, {
        key: "changeEvent",
        value: function changeEvent(event) {
          console.log(this.isToggled);
          this.isToggled = !this.isToggled;
          this.active = !this.active;
        }
      }, {
        key: "PageRoute",
        value: function PageRoute(urlSlug) {
          this.router.navigateByUrl('/' + urlSlug);
        }
      }]);

      return RegisterpasswordPage;
    }();

    RegisterpasswordPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    RegisterpasswordPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-registerpassword',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./registerpassword.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/registerpassword/registerpassword.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./registerpassword.page.scss */
      "./src/app/registerpassword/registerpassword.page.scss"))["default"]]
    })], RegisterpasswordPage);
    /***/
  }
}]);
//# sourceMappingURL=registerpassword-registerpassword-module-es5.js.map