(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["comunicacion-mensaje-mensaje-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/comunicacion/mensaje/mensaje.page.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/comunicacion/mensaje/mensaje.page.html ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"secondary\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Mensaje</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <h4> Nullam dictum at metus at semper.</h4>\n    <h6>Enviado por<span><img src=\"assets/imgs/comunicacion/clock.png\" alt=\"\">Ayer - 17:00</span></h6>\n    <h5><img src=\"assets/imgs/comunicacion/user.jpg\" alt=\"\">Jeanette K. Stockton</h5>\n    <p>Vitae et eu sagittis ut volutpat enim. Massa quam dolor scelerisque ante consequat viverra ultrices aliquet. Varius metus viverra vivamus sed ut adipiscing dictum non pharetra. Tempus lorem velit elementum praesent ipsum elit quam ultricies. Lorem vulputate justo, scelerisque nascetur.</p>\n\n    <p>Varius metus viverra vivamus sed ut adipiscing dictum non pharetra. Tempus lorem velit elementum praesent ipsum elit quam ultricies. Lorem vulputate justo, scelerisque nascetur.Varius metus viverra vivamus sed ut adipiscing dictum non pharetra.\n        Fcing dictum non pharetra. Tempus lorem velit elementum praesent.</p>\n  </div>\n  <div class=\"place_slider\">\n    <ion-slides [options]=\"slidePlace\">\n      <ion-slide>\n        <div class=\"cat-single\">\n          <img src=\"assets/imgs/comunicacion/place.png\">\n          <div class=\"img-content\">\n             <p>logotipo-empresa.png</p>\n            <p>138kb</p>\n          </div>\n        </div>\n      </ion-slide>\n      <ion-slide>\n        <div class=\"cat-single\">\n          <img src=\"assets/imgs/comunicacion/place.png\">\n          <div class=\"img-content\">\n            <p>logotipo-empresa.png</p>\n            <p>138kb</p>\n          </div>\n        </div>\n      </ion-slide>\n      <ion-slide>\n        <div class=\"cat-single\">\n          <img src=\"assets/imgs/comunicacion/place.png\">\n          <div class=\"img-content\">\n            <p>logotipo-empresa.png</p>\n            <p>138kb</p>\n          </div>\n        </div>\n      </ion-slide>\n      <ion-slide>\n        <div class=\"cat-single\">\n          <img src=\"assets/imgs/comunicacion/place.png\">\n          <div class=\"img-content\">\n            <p>logotipo-empresa.png</p>\n            <p>138kb</p>\n          </div>\n        </div>\n      </ion-slide>\n    </ion-slides>\n  </div>\n\n  <div class=\"btn-bottom\">\n    <div class=\"ion-text-end\">\n      <ion-button> <img src=\"assets/imgs/comunicacion/btn_react_like.png\"></ion-button>\n      <ion-button><img src=\"assets/imgs/comunicacion/btn_react_dislike.png\"></ion-button>\n    </div>\n  </div>\n</ion-content>\n\n\n");

/***/ }),

/***/ "./src/app/comunicacion/mensaje/mensaje-routing.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/comunicacion/mensaje/mensaje-routing.module.ts ***!
  \****************************************************************/
/*! exports provided: MensajePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MensajePageRoutingModule", function() { return MensajePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _mensaje_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mensaje.page */ "./src/app/comunicacion/mensaje/mensaje.page.ts");




const routes = [
    {
        path: '',
        component: _mensaje_page__WEBPACK_IMPORTED_MODULE_3__["MensajePage"]
    }
];
let MensajePageRoutingModule = class MensajePageRoutingModule {
};
MensajePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MensajePageRoutingModule);



/***/ }),

/***/ "./src/app/comunicacion/mensaje/mensaje.module.ts":
/*!********************************************************!*\
  !*** ./src/app/comunicacion/mensaje/mensaje.module.ts ***!
  \********************************************************/
/*! exports provided: MensajePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MensajePageModule", function() { return MensajePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _mensaje_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./mensaje-routing.module */ "./src/app/comunicacion/mensaje/mensaje-routing.module.ts");
/* harmony import */ var _mensaje_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./mensaje.page */ "./src/app/comunicacion/mensaje/mensaje.page.ts");







let MensajePageModule = class MensajePageModule {
};
MensajePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _mensaje_routing_module__WEBPACK_IMPORTED_MODULE_5__["MensajePageRoutingModule"]
        ],
        declarations: [_mensaje_page__WEBPACK_IMPORTED_MODULE_6__["MensajePage"]]
    })
], MensajePageModule);



/***/ }),

/***/ "./src/app/comunicacion/mensaje/mensaje.page.scss":
/*!********************************************************!*\
  !*** ./src/app/comunicacion/mensaje/mensaje.page.scss ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-title {\n  font-weight: 600;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.ion-padding {\n  padding: 16px 20px;\n}\nh4 {\n  font-size: 16px;\n  font-weight: 600;\n  margin-top: 3px;\n}\nh4 span {\n  font-size: 16px;\n  font-weight: 700;\n}\nh6 {\n  font-size: 14px;\n  color: #737171;\n  margin: 25px 0;\n}\nh6 span {\n  float: right;\n  color: #5076f3;\n  margin-top: 0;\n  margin-bottom: 4px;\n}\nh6 span img {\n  width: 25px;\n  vertical-align: middle;\n  margin-right: 4px;\n}\nh5 {\n  font-size: 15px;\n  margin: 20px 0;\n}\nh5 img {\n  width: 42px;\n  height: 42px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 50%;\n  vertical-align: middle;\n  margin-right: 16px;\n}\np {\n  font-size: 14px;\n  line-height: 20px;\n  margin-top: 18px;\n  color: #8e8e8e;\n}\n.place_slider {\n  padding: 4px 0 16px 20px;\n}\n.place_slider ion-slides ion-slide {\n  display: block;\n  margin-bottom: 20px;\n}\n.place_slider ion-slides ion-slide .cat-single img {\n  border-radius: 30px 30px 0 0;\n  -o-object-fit: cover;\n     object-fit: cover;\n  height: 134px;\n  width: 100%;\n}\n.place_slider ion-slides ion-slide .cat-single .img-content {\n  background: #fff;\n  text-align: left;\n  padding: 3px 12px 10px;\n  position: relative;\n  top: -10px;\n  border-radius: 0 0 30px 30px;\n  box-shadow: 0 7px 12px -7px rgba(0, 0, 0, 0.4);\n}\n.place_slider ion-slides ion-slide .cat-single .img-content p {\n  font-size: 13px;\n  color: #8e8e8e;\n  margin: 4px 0;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n.btn-bottom {\n  padding: 0 18px 18px 10px;\n}\n.btn-bottom ion-button {\n  width: 60px !important;\n  height: 60px !important;\n  --padding-start: 0;\n  --padding-end: 0;\n  margin: 0 0 0 10px;\n}\n.btn-bottom ion-button img {\n  width: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tdW5pY2FjaW9uL21lbnNhamUvRzpcXGlvbmljXFxGSVZFUlJcXHBhbnRhbGxhcy1wYWNvL3NyY1xcYXBwXFxjb211bmljYWNpb25cXG1lbnNhamVcXG1lbnNhamUucGFnZS5zY3NzIiwic3JjL2FwcC9jb211bmljYWNpb24vbWVuc2FqZS9tZW5zYWplLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGdCQUFBO0FDQUo7QURHSTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDRE47QURLQTtFQUNFLGtCQUFBO0FDRkY7QURJQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUNERjtBREVFO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FDQUo7QURHQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtBQ0FGO0FEQ0U7RUFDRSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtBQ0NKO0FEQUk7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtBQ0VOO0FERUE7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQ0NGO0FEQUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7QUNFSjtBRENBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FDRUY7QURBQTtFQUNFLHdCQUFBO0FDR0Y7QURESTtFQUNFLGNBQUE7RUFFQSxtQkFBQTtBQ0VOO0FEQVE7RUFDRSw0QkFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7RUFDQSxhQUFBO0VBQ0EsV0FBQTtBQ0VWO0FEQVE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSw0QkFBQTtFQUNBLDhDQUFBO0FDRVY7QUREVTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQ0daO0FESUE7RUFDRSx5QkFBQTtBQ0RGO0FERUU7RUFDRSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FDQUo7QURDSTtFQUNFLFdBQUE7QUNDTiIsImZpbGUiOiJzcmMvYXBwL2NvbXVuaWNhY2lvbi9tZW5zYWplL21lbnNhamUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgaW9uLXRpdGxlIHtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgfVxyXG4gIC5idG4tcmlnaHQge1xyXG4gICAgLmFsZXJ0LXRhZyB7XHJcbiAgICAgIHdpZHRoOiAxMnB4O1xyXG4gICAgICBoZWlnaHQ6IDEycHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNmYjRmMzM7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgcmlnaHQ6IC0zcHg7XHJcbiAgICAgIGJvdHRvbTogLTJweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuLmlvbi1wYWRkaW5nIHtcclxuICBwYWRkaW5nOiAxNnB4IDIwcHg7XHJcbn1cclxuaDQge1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIG1hcmdpbi10b3A6IDNweDtcclxuICBzcGFuIHtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgfVxyXG59XHJcbmg2IHtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgY29sb3I6ICM3MzcxNzE7XHJcbiAgbWFyZ2luOiAyNXB4IDA7XHJcbiAgc3BhbiB7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICBjb2xvcjogIzUwNzZmMztcclxuICAgIG1hcmdpbi10b3A6IDA7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA0cHg7XHJcbiAgICBpbWcge1xyXG4gICAgICB3aWR0aDogMjVweDtcclxuICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiA0cHg7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbmg1IHtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbiAgbWFyZ2luOiAyMHB4IDA7XHJcbiAgaW1nIHtcclxuICAgIHdpZHRoOiA0MnB4O1xyXG4gICAgaGVpZ2h0OiA0MnB4O1xyXG4gICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxNnB4O1xyXG4gIH1cclxufVxyXG5wIHtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDIwcHg7XHJcbiAgbWFyZ2luLXRvcDogMThweDtcclxuICBjb2xvcjogIzhlOGU4ZTtcclxufVxyXG4ucGxhY2Vfc2xpZGVyIHtcclxuICBwYWRkaW5nOiA0cHggMCAxNnB4IDIwcHg7XHJcbiAgaW9uLXNsaWRlcyB7XHJcbiAgICBpb24tc2xpZGUge1xyXG4gICAgICBkaXNwbGF5OiBibG9jaztcclxuXHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbiAgICAgIC5jYXQtc2luZ2xlIHtcclxuICAgICAgICBpbWcge1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogMzBweCAzMHB4IDAgMDtcclxuICAgICAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgICAgICAgaGVpZ2h0OiAxMzRweDtcclxuICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuaW1nLWNvbnRlbnQge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICAgICAgICBwYWRkaW5nOiAzcHggMTJweCAxMHB4O1xyXG4gICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgdG9wOiAtMTBweDtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDAgMCAzMHB4IDMwcHg7XHJcbiAgICAgICAgICBib3gtc2hhZG93OiAwIDdweCAxMnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjQpO1xyXG4gICAgICAgICAgcCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgY29sb3I6ICM4ZThlOGU7XHJcbiAgICAgICAgICAgIG1hcmdpbjogNHB4IDA7XHJcbiAgICAgICAgICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4uYnRuLWJvdHRvbSB7XHJcbiAgcGFkZGluZzogMCAxOHB4IDE4cHggMTBweDtcclxuICBpb24tYnV0dG9uIHtcclxuICAgIHdpZHRoOiA2MHB4IWltcG9ydGFudDtcclxuICAgIGhlaWdodDogNjBweCFpbXBvcnRhbnQ7XHJcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDA7XHJcbiAgICAtLXBhZGRpbmctZW5kOiAwO1xyXG4gICAgbWFyZ2luOiAwIDAgMCAxMHB4O1xyXG4gICAgaW1nIHtcclxuICAgICAgd2lkdGg6IDMwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiIsImlvbi1oZWFkZXIgaW9uLXRpdGxlIHtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbmlvbi1oZWFkZXIgLmJ0bi1yaWdodCAuYWxlcnQtdGFnIHtcbiAgd2lkdGg6IDEycHg7XG4gIGhlaWdodDogMTJweDtcbiAgYmFja2dyb3VuZDogI2ZiNGYzMztcbiAgZGlzcGxheTogYmxvY2s7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogLTNweDtcbiAgYm90dG9tOiAtMnB4O1xufVxuXG4uaW9uLXBhZGRpbmcge1xuICBwYWRkaW5nOiAxNnB4IDIwcHg7XG59XG5cbmg0IHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBtYXJnaW4tdG9wOiAzcHg7XG59XG5oNCBzcGFuIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogNzAwO1xufVxuXG5oNiB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICM3MzcxNzE7XG4gIG1hcmdpbjogMjVweCAwO1xufVxuaDYgc3BhbiB7XG4gIGZsb2F0OiByaWdodDtcbiAgY29sb3I6ICM1MDc2ZjM7XG4gIG1hcmdpbi10b3A6IDA7XG4gIG1hcmdpbi1ib3R0b206IDRweDtcbn1cbmg2IHNwYW4gaW1nIHtcbiAgd2lkdGg6IDI1cHg7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIG1hcmdpbi1yaWdodDogNHB4O1xufVxuXG5oNSB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWFyZ2luOiAyMHB4IDA7XG59XG5oNSBpbWcge1xuICB3aWR0aDogNDJweDtcbiAgaGVpZ2h0OiA0MnB4O1xuICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBtYXJnaW4tcmlnaHQ6IDE2cHg7XG59XG5cbnAge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMHB4O1xuICBtYXJnaW4tdG9wOiAxOHB4O1xuICBjb2xvcjogIzhlOGU4ZTtcbn1cblxuLnBsYWNlX3NsaWRlciB7XG4gIHBhZGRpbmc6IDRweCAwIDE2cHggMjBweDtcbn1cbi5wbGFjZV9zbGlkZXIgaW9uLXNsaWRlcyBpb24tc2xpZGUge1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbn1cbi5wbGFjZV9zbGlkZXIgaW9uLXNsaWRlcyBpb24tc2xpZGUgLmNhdC1zaW5nbGUgaW1nIHtcbiAgYm9yZGVyLXJhZGl1czogMzBweCAzMHB4IDAgMDtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG4gIGhlaWdodDogMTM0cHg7XG4gIHdpZHRoOiAxMDAlO1xufVxuLnBsYWNlX3NsaWRlciBpb24tc2xpZGVzIGlvbi1zbGlkZSAuY2F0LXNpbmdsZSAuaW1nLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBwYWRkaW5nOiAzcHggMTJweCAxMHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogLTEwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDAgMCAzMHB4IDMwcHg7XG4gIGJveC1zaGFkb3c6IDAgN3B4IDEycHggLTdweCByZ2JhKDAsIDAsIDAsIDAuNCk7XG59XG4ucGxhY2Vfc2xpZGVyIGlvbi1zbGlkZXMgaW9uLXNsaWRlIC5jYXQtc2luZ2xlIC5pbWctY29udGVudCBwIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBjb2xvcjogIzhlOGU4ZTtcbiAgbWFyZ2luOiA0cHggMDtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG59XG5cbi5idG4tYm90dG9tIHtcbiAgcGFkZGluZzogMCAxOHB4IDE4cHggMTBweDtcbn1cbi5idG4tYm90dG9tIGlvbi1idXR0b24ge1xuICB3aWR0aDogNjBweCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDYwcHggIWltcG9ydGFudDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICAtLXBhZGRpbmctZW5kOiAwO1xuICBtYXJnaW46IDAgMCAwIDEwcHg7XG59XG4uYnRuLWJvdHRvbSBpb24tYnV0dG9uIGltZyB7XG4gIHdpZHRoOiAzMHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/comunicacion/mensaje/mensaje.page.ts":
/*!******************************************************!*\
  !*** ./src/app/comunicacion/mensaje/mensaje.page.ts ***!
  \******************************************************/
/*! exports provided: MensajePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MensajePage", function() { return MensajePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let MensajePage = class MensajePage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
        this.slidePlace = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1.5,
            spaceBetween: 20,
        };
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
};
MensajePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
MensajePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-mensaje',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./mensaje.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/comunicacion/mensaje/mensaje.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./mensaje.page.scss */ "./src/app/comunicacion/mensaje/mensaje.page.scss")).default]
    })
], MensajePage);



/***/ })

}]);
//# sourceMappingURL=comunicacion-mensaje-mensaje-module-es2015.js.map