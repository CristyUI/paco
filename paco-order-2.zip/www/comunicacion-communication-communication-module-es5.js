function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["comunicacion-communication-communication-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/comunicacion/communication/communication.page.html":
  /*!**********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/comunicacion/communication/communication.page.html ***!
    \**********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppComunicacionCommunicationCommunicationPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"secondary\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Comunicación</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <div class=\"ion-padding\">\n\n    <div class=\"search-area\">\n      <div class=\"content-search\" (click)=\"PageRoute('search')\">\n        <span>Buscar<img src=\"assets/imgs/search-icon.png\" alt=\"\"></span>\n      </div>\n    </div>\n\n    <div class=\"filter-area\" (click)=\"sortby()\">\n      <p>Ordenar por<span><ion-icon name=\"chevron-down-outline\"></ion-icon></span></p>\n    </div>\n\n    <div class=\"list-wrapper\">\n      <!------ Single_List -------->\n      <div class=\"single_list\">\n        <div class=\"top-bar\">\n          <ion-row>\n            <ion-col size=\"11\" (click)=\"PageRoute('mensaje')\">\n              <h4><span>(No leido)</span> Nullam dictum at metus at semper.</h4>\n            </ion-col>\n            <ion-col size=\"1\" class=\"ion-text-end\">\n                <ion-button class=\"btn-transparent\" (click)=\"showHide()\"><ion-icon name=\"ellipsis-vertical\"></ion-icon></ion-button>\n            </ion-col>\n          </ion-row>\n          <div class=\"hidden-list\" *ngIf=\"BtnClick\">\n            <ul>\n              <li>Marcarar como leído</li>\n              <li>Marcarar como no leído</li>\n            </ul>\n          </div>\n        </div>\n        <div class=\"mid-content\" (click)=\"PageRoute('mensaje')\">\n          <h5><img src=\"assets/imgs/comunicacion/user.jpg\" alt=\"\">Jeanette K. Stockton</h5>\n          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec dui dui, posuere nec sem et,\n            rhoncus sollicitudin elit. Praesent nec dignissim enim. Done...</p>\n        </div>\n        <div class=\"bottom-bar\"(click)=\"PageRoute('mensaje')\">\n          <ion-row>\n            <ion-col size=\"4\">\n              <h6><img src=\"assets/imgs/comunicacion/paper-clip.png\" alt=\"\">2</h6>\n            </ion-col>\n            <ion-col size=\"8\">\n              <ul>\n                <li><h6><img src=\"assets/imgs/comunicacion/clock.png\" alt=\"\">Ayer - 17:00</h6></li>\n              </ul>\n            </ion-col>\n          </ion-row>\n        </div>\n      </div>\n      <!------ /Single_List -------->\n\n      <!------ Single_List -------->\n      <div class=\"single_list\">\n        <div class=\"top-bar\">\n          <ion-row>\n            <ion-col size=\"11\" (click)=\"PageRoute('mensaje')\">\n              <h4>Nullam dictum at metus at semper.</h4>\n            </ion-col>\n            <ion-col size=\"1\" class=\"ion-text-end\">\n              <ion-button class=\"btn-transparent\" (click)=\"showHide2()\"><ion-icon name=\"ellipsis-vertical\"></ion-icon></ion-button>\n            </ion-col>\n          </ion-row>\n          <div class=\"hidden-list\" *ngIf=\"BtnClick2\">\n            <ul>\n              <li>Marcarar como leído</li>\n              <li>Marcarar como no leído</li>\n            </ul>\n          </div>\n        </div>\n        <div class=\"mid-content\" (click)=\"PageRoute('mensaje')\">\n          <h5><img src=\"assets/imgs/comunicacion/user.jpg\" alt=\"\">Jeanette K. Stockton</h5>\n          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec dui dui, posuere nec sem et,\n            rhoncus sollicitudin elit. Praesent nec dignissim enim. Done...</p>\n        </div>\n        <div class=\"bottom-bar\" (click)=\"PageRoute('mensaje')\">\n          <ion-row>\n            <ion-col size=\"4\">\n              <h6><img src=\"assets/imgs/comunicacion/paper-clip.png\" alt=\"\">2</h6>\n            </ion-col>\n            <ion-col size=\"8\">\n              <ul>\n                <li><h6><img src=\"assets/imgs/comunicacion/like.png\" alt=\"\"></h6></li>\n                <li><h6><img src=\"assets/imgs/comunicacion/clock.png\" alt=\"\">Ayer - 17:00</h6></li>\n              </ul>\n            </ion-col>\n          </ion-row>\n        </div>\n      </div>\n      <!------ /Single_List -------->\n\n      <!------ Single_List -------->\n      <div class=\"single_list\">\n        <div class=\"top-bar\">\n          <ion-row>\n            <ion-col size=\"11\" (click)=\"PageRoute('mensaje')\">\n              <h4>Nullam dictum at metus at semper.</h4>\n            </ion-col>\n            <ion-col size=\"1\" class=\"ion-text-end\">\n              <ion-button class=\"btn-transparent\"><ion-icon name=\"ellipsis-vertical\"></ion-icon></ion-button>\n            </ion-col>\n          </ion-row>\n        </div>\n        <div class=\"mid-content\" (click)=\"PageRoute('mensaje')\">\n          <h5><img src=\"assets/imgs/comunicacion/user.jpg\" alt=\"\">Jeanette K. Stockton</h5>\n          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec dui dui, posuere nec sem et,\n            rhoncus sollicitudin elit. Praesent nec dignissim enim. Done...</p>\n        </div>\n        <div class=\"bottom-bar\" (click)=\"PageRoute('mensaje')\">\n          <ion-row>\n            <ion-col size=\"4\">\n              <h6><img src=\"assets/imgs/comunicacion/paper-clip.png\" alt=\"\">2</h6>\n            </ion-col>\n            <ion-col size=\"8\">\n              <ul>\n                <li><h6><img src=\"assets/imgs/comunicacion/dislike.png\" alt=\"\"></h6></li>\n                <li><h6><img src=\"assets/imgs/comunicacion/clock.png\" alt=\"\">Ayer - 17:00</h6></li>\n              </ul>\n            </ion-col>\n          </ion-row>\n        </div>\n      </div>\n      <!------ /Single_List -------->\n    </div>\n\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/comunicacion/communication/communication-routing.module.ts":
  /*!****************************************************************************!*\
    !*** ./src/app/comunicacion/communication/communication-routing.module.ts ***!
    \****************************************************************************/

  /*! exports provided: CommunicationPageRoutingModule */

  /***/
  function srcAppComunicacionCommunicationCommunicationRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CommunicationPageRoutingModule", function () {
      return CommunicationPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _communication_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./communication.page */
    "./src/app/comunicacion/communication/communication.page.ts");

    var routes = [{
      path: '',
      component: _communication_page__WEBPACK_IMPORTED_MODULE_3__["CommunicationPage"]
    }];

    var CommunicationPageRoutingModule = function CommunicationPageRoutingModule() {
      _classCallCheck(this, CommunicationPageRoutingModule);
    };

    CommunicationPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CommunicationPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/comunicacion/communication/communication.module.ts":
  /*!********************************************************************!*\
    !*** ./src/app/comunicacion/communication/communication.module.ts ***!
    \********************************************************************/

  /*! exports provided: CommunicationPageModule */

  /***/
  function srcAppComunicacionCommunicationCommunicationModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CommunicationPageModule", function () {
      return CommunicationPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _communication_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./communication-routing.module */
    "./src/app/comunicacion/communication/communication-routing.module.ts");
    /* harmony import */


    var _communication_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./communication.page */
    "./src/app/comunicacion/communication/communication.page.ts");

    var CommunicationPageModule = function CommunicationPageModule() {
      _classCallCheck(this, CommunicationPageModule);
    };

    CommunicationPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _communication_routing_module__WEBPACK_IMPORTED_MODULE_5__["CommunicationPageRoutingModule"]],
      declarations: [_communication_page__WEBPACK_IMPORTED_MODULE_6__["CommunicationPage"]]
    })], CommunicationPageModule);
    /***/
  },

  /***/
  "./src/app/comunicacion/communication/communication.page.scss":
  /*!********************************************************************!*\
    !*** ./src/app/comunicacion/communication/communication.page.scss ***!
    \********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppComunicacionCommunicationCommunicationPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header ion-title {\n  font-weight: 600;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.ion-padding {\n  padding: 16px 18px;\n}\n.search-area .content-search {\n  box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.2588235294);\n  border-radius: 30px;\n  padding: 15px 22px;\n}\n.search-area .content-search span {\n  color: #8c8b8b;\n}\n.search-area .content-search span img {\n  width: 20px;\n  vertical-align: bottom;\n  float: right;\n}\n.filter-area {\n  padding: 16px 0 5px;\n}\n.filter-area p {\n  border: 1px solid #7995f3;\n  padding: 12px 20px;\n  margin: 0;\n  border-radius: 30px;\n  width: 50%;\n  color: #797979;\n}\n.filter-area p span {\n  float: right;\n  font-size: 17px;\n  position: relative;\n  top: 2px;\n  color: #2d5eb7;\n}\n.list-wrapper .single_list {\n  margin: 20px 0 0;\n  border-radius: 30px;\n  padding: 15px 20px;\n  box-shadow: 0 5px 14px -1px rgba(0, 0, 0, 0.2);\n}\n.list-wrapper .single_list .top-bar {\n  position: relative;\n}\n.list-wrapper .single_list .top-bar h4 {\n  font-size: 15px;\n  font-weight: 600;\n}\n.list-wrapper .single_list .top-bar h4 span {\n  font-size: 16px;\n  font-weight: 700;\n}\n.list-wrapper .single_list .top-bar ion-button {\n  --padding-end: 0;\n  --padding-start: 0;\n  color: #5669d2;\n  font-size: 16px !important;\n}\n.list-wrapper .single_list .top-bar .hidden-list {\n  width: 70%;\n  position: absolute;\n  top: 16px;\n  right: 15px;\n  background: #fff;\n  padding: 20px;\n  z-index: 99;\n  box-shadow: 0 5px 14px -1px rgba(0, 0, 0, 0.2);\n  border-radius: 20px;\n}\n.list-wrapper .single_list .top-bar .hidden-list ul {\n  margin: 0;\n  padding: 0;\n}\n.list-wrapper .single_list .top-bar .hidden-list ul li {\n  list-style-type: none;\n  font-size: 14px;\n  padding: 7px 0;\n}\n.list-wrapper .single_list .mid-content {\n  padding: 0 8px;\n}\n.list-wrapper .single_list .mid-content h5 {\n  font-size: 15px;\n  margin-top: 2px;\n  color: #5a5a5a;\n}\n.list-wrapper .single_list .mid-content h5 img {\n  width: 32px;\n  height: 32px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 50%;\n  vertical-align: middle;\n  margin-right: 12px;\n}\n.list-wrapper .single_list .mid-content p {\n  font-size: 14px;\n  line-height: 20px;\n  margin-top: 18px;\n  color: #8e8e8e;\n}\n.list-wrapper .single_list .bottom-bar ul {\n  padding: 0;\n  margin: 0;\n  text-align: right;\n}\n.list-wrapper .single_list .bottom-bar ul li {\n  list-style-type: none;\n  display: inline-block;\n  margin-left: 10px;\n}\n.list-wrapper .single_list .bottom-bar h6 {\n  font-size: 14px;\n  color: #5076f3;\n  margin-top: 0;\n  margin-bottom: 4px;\n}\n.list-wrapper .single_list .bottom-bar h6 img {\n  width: 25px;\n  vertical-align: middle;\n  margin-right: 4px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tdW5pY2FjaW9uL2NvbW11bmljYXRpb24vRzpcXGlvbmljXFxGSVZFUlJcXHBhbnRhbGxhcy1wYWNvL3NyY1xcYXBwXFxjb211bmljYWNpb25cXGNvbW11bmljYXRpb25cXGNvbW11bmljYXRpb24ucGFnZS5zY3NzIiwic3JjL2FwcC9jb211bmljYWNpb24vY29tbXVuaWNhdGlvbi9jb21tdW5pY2F0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGdCQUFBO0FDQUo7QURHSTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDRE47QURLQTtFQUNFLGtCQUFBO0FDRkY7QURLRTtFQUNFLHdEQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQ0ZKO0FER0k7RUFDRSxjQUFBO0FDRE47QURFTTtFQUNFLFdBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7QUNBUjtBRE1BO0VBQ0UsbUJBQUE7QUNIRjtBRElFO0VBQ0UseUJBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxtQkFBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0FDRko7QURHSTtFQUNFLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsY0FBQTtBQ0ROO0FET0U7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSw4Q0FBQTtBQ0pKO0FES0k7RUFDRSxrQkFBQTtBQ0hOO0FESU07RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7QUNGUjtBREdRO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FDRFY7QURJTTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7QUNGUjtBRElNO0VBQ0UsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0EsOENBQUE7RUFDQSxtQkFBQTtBQ0ZSO0FER1E7RUFDRSxTQUFBO0VBQ0EsVUFBQTtBQ0RWO0FERVU7RUFDRSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FDQVo7QURLSTtFQUNFLGNBQUE7QUNITjtBRElNO0VBQ0UsZUFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FDRlI7QURHUTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtBQ0RWO0FESU07RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNGUjtBRE1NO0VBQ0UsVUFBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtBQ0pSO0FES1E7RUFDRSxxQkFBQTtFQUNBLHFCQUFBO0VBQ0EsaUJBQUE7QUNIVjtBRE1NO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7QUNKUjtBREtRO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0EsaUJBQUE7QUNIViIsImZpbGUiOiJzcmMvYXBwL2NvbXVuaWNhY2lvbi9jb21tdW5pY2F0aW9uL2NvbW11bmljYXRpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgaW9uLXRpdGxlIHtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgfVxyXG4gIC5idG4tcmlnaHQge1xyXG4gICAgLmFsZXJ0LXRhZyB7XHJcbiAgICAgIHdpZHRoOiAxMnB4O1xyXG4gICAgICBoZWlnaHQ6IDEycHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNmYjRmMzM7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgcmlnaHQ6IC0zcHg7XHJcbiAgICAgIGJvdHRvbTogLTJweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuLmlvbi1wYWRkaW5nIHtcclxuICBwYWRkaW5nOiAxNnB4IDE4cHg7XHJcbn1cclxuLnNlYXJjaC1hcmVhe1xyXG4gIC5jb250ZW50LXNlYXJjaCB7XHJcbiAgICBib3gtc2hhZG93OiBpbnNldCAwIDJweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yNTg4MjM1Mjk0MTE3NjQ3Myk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgcGFkZGluZzogMTVweCAyMnB4O1xyXG4gICAgc3BhbiB7XHJcbiAgICAgIGNvbG9yOiAjOGM4YjhiO1xyXG4gICAgICBpbWcge1xyXG4gICAgICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiBib3R0b207XHJcbiAgICAgICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG4uZmlsdGVyLWFyZWEge1xyXG4gIHBhZGRpbmc6IDE2cHggMCA1cHg7XHJcbiAgcCB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjNzk5NWYzO1xyXG4gICAgcGFkZGluZzogMTJweCAyMHB4O1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIHdpZHRoOiA1MCU7XHJcbiAgICBjb2xvcjogIzc5Nzk3OTtcclxuICAgIHNwYW4ge1xyXG4gICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTdweDtcclxuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICB0b3A6IDJweDtcclxuICAgICAgY29sb3I6ICMyZDVlYjc7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG4ubGlzdC13cmFwcGVyIHtcclxuICAuc2luZ2xlX2xpc3Qge1xyXG4gICAgbWFyZ2luOiAyMHB4IDAgMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICBwYWRkaW5nOiAxNXB4IDIwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDVweCAxNHB4IC0xcHggcmdiYSgwLCAwLCAwLCAwLjIpO1xyXG4gICAgLnRvcC1iYXIge1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIGg0IHtcclxuICAgICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICBzcGFuIHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgIC0tcGFkZGluZy1lbmQ6IDA7XHJcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xyXG4gICAgICAgIGNvbG9yOiAjNTY2OWQyO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTZweCFpbXBvcnRhbnQ7XHJcbiAgICAgIH1cclxuICAgICAgLmhpZGRlbi1saXN0IHtcclxuICAgICAgICB3aWR0aDogNzAlO1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICB0b3A6IDE2cHg7XHJcbiAgICAgICAgcmlnaHQ6IDE1cHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgICAgIHotaW5kZXg6IDk5O1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDAgNXB4IDE0cHggLTFweCByZ2JhKDAsIDAsIDAsIDAuMik7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgICAgICB1bCB7XHJcbiAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgbGkge1xyXG4gICAgICAgICAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgICAgcGFkZGluZzogN3B4IDA7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAubWlkLWNvbnRlbnQge1xyXG4gICAgICBwYWRkaW5nOiAwIDhweDtcclxuICAgICAgaDUge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgICBtYXJnaW4tdG9wOiAycHg7XHJcbiAgICAgICAgY29sb3I6ICM1YTVhNWE7XHJcbiAgICAgICAgaW1nIHtcclxuICAgICAgICAgIHdpZHRoOiAzMnB4O1xyXG4gICAgICAgICAgaGVpZ2h0OiAzMnB4O1xyXG4gICAgICAgICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG4gICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMnB4O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBwIHtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgbGluZS1oZWlnaHQ6IDIwcHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMThweDtcclxuICAgICAgICBjb2xvcjogIzhlOGU4ZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmJvdHRvbS1iYXIge1xyXG4gICAgICB1bCB7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICAgICAgbGkge1xyXG4gICAgICAgICAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xyXG4gICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGg2IHtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgY29sb3I6ICM1MDc2ZjM7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMDtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiA0cHg7XHJcbiAgICAgICAgaW1nIHtcclxuICAgICAgICAgIHdpZHRoOiAyNXB4O1xyXG4gICAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICAgICAgICAgIG1hcmdpbi1yaWdodDogNHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICB9XHJcbn0iLCJpb24taGVhZGVyIGlvbi10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5pb24taGVhZGVyIC5idG4tcmlnaHQgLmFsZXJ0LXRhZyB7XG4gIHdpZHRoOiAxMnB4O1xuICBoZWlnaHQ6IDEycHg7XG4gIGJhY2tncm91bmQ6ICNmYjRmMzM7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IC0zcHg7XG4gIGJvdHRvbTogLTJweDtcbn1cblxuLmlvbi1wYWRkaW5nIHtcbiAgcGFkZGluZzogMTZweCAxOHB4O1xufVxuXG4uc2VhcmNoLWFyZWEgLmNvbnRlbnQtc2VhcmNoIHtcbiAgYm94LXNoYWRvdzogaW5zZXQgMCAycHggMTBweCByZ2JhKDAsIDAsIDAsIDAuMjU4ODIzNTI5NCk7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIHBhZGRpbmc6IDE1cHggMjJweDtcbn1cbi5zZWFyY2gtYXJlYSAuY29udGVudC1zZWFyY2ggc3BhbiB7XG4gIGNvbG9yOiAjOGM4YjhiO1xufVxuLnNlYXJjaC1hcmVhIC5jb250ZW50LXNlYXJjaCBzcGFuIGltZyB7XG4gIHdpZHRoOiAyMHB4O1xuICB2ZXJ0aWNhbC1hbGlnbjogYm90dG9tO1xuICBmbG9hdDogcmlnaHQ7XG59XG5cbi5maWx0ZXItYXJlYSB7XG4gIHBhZGRpbmc6IDE2cHggMCA1cHg7XG59XG4uZmlsdGVyLWFyZWEgcCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICM3OTk1ZjM7XG4gIHBhZGRpbmc6IDEycHggMjBweDtcbiAgbWFyZ2luOiAwO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICB3aWR0aDogNTAlO1xuICBjb2xvcjogIzc5Nzk3OTtcbn1cbi5maWx0ZXItYXJlYSBwIHNwYW4ge1xuICBmbG9hdDogcmlnaHQ7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IDJweDtcbiAgY29sb3I6ICMyZDVlYjc7XG59XG5cbi5saXN0LXdyYXBwZXIgLnNpbmdsZV9saXN0IHtcbiAgbWFyZ2luOiAyMHB4IDAgMDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgcGFkZGluZzogMTVweCAyMHB4O1xuICBib3gtc2hhZG93OiAwIDVweCAxNHB4IC0xcHggcmdiYSgwLCAwLCAwLCAwLjIpO1xufVxuLmxpc3Qtd3JhcHBlciAuc2luZ2xlX2xpc3QgLnRvcC1iYXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4ubGlzdC13cmFwcGVyIC5zaW5nbGVfbGlzdCAudG9wLWJhciBoNCB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbi5saXN0LXdyYXBwZXIgLnNpbmdsZV9saXN0IC50b3AtYmFyIGg0IHNwYW4ge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG59XG4ubGlzdC13cmFwcGVyIC5zaW5nbGVfbGlzdCAudG9wLWJhciBpb24tYnV0dG9uIHtcbiAgLS1wYWRkaW5nLWVuZDogMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICBjb2xvcjogIzU2NjlkMjtcbiAgZm9udC1zaXplOiAxNnB4ICFpbXBvcnRhbnQ7XG59XG4ubGlzdC13cmFwcGVyIC5zaW5nbGVfbGlzdCAudG9wLWJhciAuaGlkZGVuLWxpc3Qge1xuICB3aWR0aDogNzAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMTZweDtcbiAgcmlnaHQ6IDE1cHg7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIHotaW5kZXg6IDk5O1xuICBib3gtc2hhZG93OiAwIDVweCAxNHB4IC0xcHggcmdiYSgwLCAwLCAwLCAwLjIpO1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xufVxuLmxpc3Qtd3JhcHBlciAuc2luZ2xlX2xpc3QgLnRvcC1iYXIgLmhpZGRlbi1saXN0IHVsIHtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwO1xufVxuLmxpc3Qtd3JhcHBlciAuc2luZ2xlX2xpc3QgLnRvcC1iYXIgLmhpZGRlbi1saXN0IHVsIGxpIHtcbiAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xuICBmb250LXNpemU6IDE0cHg7XG4gIHBhZGRpbmc6IDdweCAwO1xufVxuLmxpc3Qtd3JhcHBlciAuc2luZ2xlX2xpc3QgLm1pZC1jb250ZW50IHtcbiAgcGFkZGluZzogMCA4cHg7XG59XG4ubGlzdC13cmFwcGVyIC5zaW5nbGVfbGlzdCAubWlkLWNvbnRlbnQgaDUge1xuICBmb250LXNpemU6IDE1cHg7XG4gIG1hcmdpbi10b3A6IDJweDtcbiAgY29sb3I6ICM1YTVhNWE7XG59XG4ubGlzdC13cmFwcGVyIC5zaW5nbGVfbGlzdCAubWlkLWNvbnRlbnQgaDUgaW1nIHtcbiAgd2lkdGg6IDMycHg7XG4gIGhlaWdodDogMzJweDtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgbWFyZ2luLXJpZ2h0OiAxMnB4O1xufVxuLmxpc3Qtd3JhcHBlciAuc2luZ2xlX2xpc3QgLm1pZC1jb250ZW50IHAge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMHB4O1xuICBtYXJnaW4tdG9wOiAxOHB4O1xuICBjb2xvcjogIzhlOGU4ZTtcbn1cbi5saXN0LXdyYXBwZXIgLnNpbmdsZV9saXN0IC5ib3R0b20tYmFyIHVsIHtcbiAgcGFkZGluZzogMDtcbiAgbWFyZ2luOiAwO1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cbi5saXN0LXdyYXBwZXIgLnNpbmdsZV9saXN0IC5ib3R0b20tYmFyIHVsIGxpIHtcbiAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuLmxpc3Qtd3JhcHBlciAuc2luZ2xlX2xpc3QgLmJvdHRvbS1iYXIgaDYge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjNTA3NmYzO1xuICBtYXJnaW4tdG9wOiAwO1xuICBtYXJnaW4tYm90dG9tOiA0cHg7XG59XG4ubGlzdC13cmFwcGVyIC5zaW5nbGVfbGlzdCAuYm90dG9tLWJhciBoNiBpbWcge1xuICB3aWR0aDogMjVweDtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgbWFyZ2luLXJpZ2h0OiA0cHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/comunicacion/communication/communication.page.ts":
  /*!******************************************************************!*\
    !*** ./src/app/comunicacion/communication/communication.page.ts ***!
    \******************************************************************/

  /*! exports provided: CommunicationPage */

  /***/
  function srcAppComunicacionCommunicationCommunicationPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CommunicationPage", function () {
      return CommunicationPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var CommunicationPage = /*#__PURE__*/function () {
      function CommunicationPage(router, menuCtrl, actionSheetController) {
        _classCallCheck(this, CommunicationPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
        this.actionSheetController = actionSheetController;
        this.BtnClick = false;
        this.BtnClick2 = false;
      }

      _createClass(CommunicationPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "sortby",
        value: function sortby() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var actionSheet;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.actionSheetController.create({
                      header: 'Sort By',
                      mode: 'ios',
                      buttons: [{
                        text: 'Oldest',
                        handler: function handler() {
                          console.log('Oldest clicked');
                        }
                      }, {
                        text: 'Newest',
                        handler: function handler() {
                          console.log('Newest clicked');
                        }
                      }, {
                        text: 'Recently Viewed',
                        handler: function handler() {
                          console.log('Recently Viewed clicked');
                        }
                      }, {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Cancel clicked');
                        }
                      }]
                    });

                  case 2:
                    actionSheet = _context.sent;
                    _context.next = 5;
                    return actionSheet.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "PageRoute",
        value: function PageRoute(urlSlug) {
          this.router.navigateByUrl('/' + urlSlug);
        }
      }, {
        key: "showHide",
        value: function showHide() {
          this.BtnClick = !this.BtnClick;
        }
      }, {
        key: "showHide2",
        value: function showHide2() {
          this.BtnClick2 = !this.BtnClick2;
        }
      }]);

      return CommunicationPage;
    }();

    CommunicationPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]
      }];
    };

    CommunicationPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-communication',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./communication.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/comunicacion/communication/communication.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./communication.page.scss */
      "./src/app/comunicacion/communication/communication.page.scss"))["default"]]
    })], CommunicationPage);
    /***/
  }
}]);
//# sourceMappingURL=comunicacion-communication-communication-module-es5.js.map