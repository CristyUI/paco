(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ayuda-ayudamain-ayudamain-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/ayuda/ayudamain/ayudamain.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/ayuda/ayudamain/ayudamain.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" (click)=\"PageRoute('home')\">\n      <ion-icon name=\"chevron-back-outline\" color=\"secondary\" style=\"margin-top: 4px;\"></ion-icon>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Ayuda</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <div class=\"search-area\">\n      <div class=\"content-search\" (click)=\"PageRoute('search')\">\n        <span>Buscar<img src=\"assets/imgs/search-icon.png\" alt=\"\"></span>\n      </div>\n    </div>\n\n    <div class=\"tab-section\">\n      <ul>\n        <li *ngFor=\"let tab of TabsData\" (click)=\"tabsElement(tab)\" [ngClass]=\"{'active': (SelectedData == tab.name)}\">\n          {{tab.name}}\n        </li>\n      </ul>\n    </div>\n\n    <div class=\"ayuda-list\">\n      <div id=\"content-pagos\" *ngIf=\"SelectedData == 'Pagos'\">\n        <ul>\n          <li>Convallis at cras gravida pharetra, tellus, pulvinar ut. Placerat sed urna, vitae, nec morbi ut massa?</li>\n          <li>Convallis at cras gravida pharetra, tellus, pulvinar ut. Placerat sed urna, vitae, nec morbi ut massa?</li>\n          <li>Convallis at cras gravida pharetra, tellus, pulvinar ut. Placerat sed urna, vitae, nec morbi ut massa? Placerat\n          sed urna, vitae, nec morbi ut massa?</li>\n          <li>Convallis at cras gravida pharetra, tellus, pulvinar ut. Placerat sed urna, vitae, nec morbi ut massa?</li>\n          <li>Convallis at cras gravida pharetra, tellus, pulvinar ut. Placerat sed urna, vitae, nec morbi ut massa?</li>\n          <li>Convallis at cras gravida pharetra, tellus, pulvinar ut. Placerat sed urna, vitae, nec morbi ut massa? Placerat\n          sed urna, vitae, nec morbi ut massa?</li>\n        </ul>\n      </div>\n      <div id=\"content-seguros\" *ngIf=\"SelectedData == 'Seguros'\">\n        <ul>\n          <li>Convallis at cras gravida pharetra, tellus, pulvinar ut. Placerat sed urna, vitae, nec morbi ut massa? Placerat\n          sed urna, vitae, nec morbi ut massa?</li>\n        </ul>\n      </div>\n      <div id=\"content-nominas\" *ngIf=\"SelectedData == 'Nominas'\">\n        <ul>\n          <li>Convallis at cras gravida pharetra, tellus, pulvinar ut. Placerat sed urna, vitae, nec morbi ut massa?</li>\n          <li>Convallis at cras gravida pharetra, tellus, pulvinar ut. Placerat sed urna, vitae, nec morbi ut massa?</li>\n          <li>Convallis at cras gravida pharetra, tellus, pulvinar ut. Placerat sed urna, vitae, nec morbi ut massa? Placerat\n          sed urna, vitae, nec morbi ut massa?</li>\n        </ul>\n      </div>\n      <div id=\"content-descuentos\" *ngIf=\"SelectedData == 'Descuentos'\">\n        <ul>\n          <li>Convallis at cras gravida pharetra, tellus, pulvinar ut. Placerat sed urna, vitae, nec morbi ut massa? Placerat\n          sed urna, vitae, nec morbi ut massa?</li>\n          <li>Convallis at cras gravida pharetra, tellus, pulvinar ut. Placerat sed urna, vitae, nec morbi ut massa?</li>\n\n        </ul>\n      </div>\n    </div>\n\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/ayuda/ayudamain/ayudamain-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/ayuda/ayudamain/ayudamain-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: AyudamainPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AyudamainPageRoutingModule", function() { return AyudamainPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ayudamain_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ayudamain.page */ "./src/app/ayuda/ayudamain/ayudamain.page.ts");




const routes = [
    {
        path: '',
        component: _ayudamain_page__WEBPACK_IMPORTED_MODULE_3__["AyudamainPage"]
    }
];
let AyudamainPageRoutingModule = class AyudamainPageRoutingModule {
};
AyudamainPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AyudamainPageRoutingModule);



/***/ }),

/***/ "./src/app/ayuda/ayudamain/ayudamain.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/ayuda/ayudamain/ayudamain.module.ts ***!
  \*****************************************************/
/*! exports provided: AyudamainPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AyudamainPageModule", function() { return AyudamainPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ayudamain_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ayudamain-routing.module */ "./src/app/ayuda/ayudamain/ayudamain-routing.module.ts");
/* harmony import */ var _ayudamain_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ayudamain.page */ "./src/app/ayuda/ayudamain/ayudamain.page.ts");







let AyudamainPageModule = class AyudamainPageModule {
};
AyudamainPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _ayudamain_routing_module__WEBPACK_IMPORTED_MODULE_5__["AyudamainPageRoutingModule"]
        ],
        declarations: [_ayudamain_page__WEBPACK_IMPORTED_MODULE_6__["AyudamainPage"]]
    })
], AyudamainPageModule);



/***/ }),

/***/ "./src/app/ayuda/ayudamain/ayudamain.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/ayuda/ayudamain/ayudamain.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-title {\n  font-weight: 600;\n}\nion-header ion-buttons {\n  margin-left: 20px;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.search-area {\n  margin-bottom: 25px;\n}\n.search-area .content-search {\n  box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.2588235294);\n  border-radius: 30px;\n  padding: 15px 22px;\n}\n.search-area .content-search span {\n  color: #8c8b8b;\n}\n.search-area .content-search span img {\n  width: 20px;\n  vertical-align: bottom;\n  float: right;\n}\n.ayuda-list ul {\n  padding-left: 0;\n}\n.ayuda-list ul li {\n  list-style-type: none;\n  color: #5176F3;\n  box-shadow: 0px 5px 15px rgba(47, 47, 47, 0.15), 0px 2px 2px rgba(47, 47, 47, 0.2);\n  padding: 14px 20px;\n  margin-bottom: 18px;\n  border-radius: 30px;\n}\n.tab-section ul {\n  padding-left: 0;\n  box-shadow: inset 0 5px 15px rgba(50, 72, 200, 0.15), inset 0 2px 2px rgba(50, 72, 200, 0.2);\n  border-radius: 30px;\n}\n.tab-section ul li {\n  list-style-type: none;\n  display: inline-block;\n  font-size: 14px;\n  text-align: center;\n  color: #5d5b5b;\n  padding: 14px 14.5px;\n}\n.tab-section ul .active {\n  background: #5176F3;\n  color: #fff;\n  border-radius: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXl1ZGEvYXl1ZGFtYWluL0c6XFxpb25pY1xcRklWRVJSXFxwYW50YWxsYXMtcGFjby9zcmNcXGFwcFxcYXl1ZGFcXGF5dWRhbWFpblxcYXl1ZGFtYWluLnBhZ2Uuc2NzcyIsInNyYy9hcHAvYXl1ZGEvYXl1ZGFtYWluL2F5dWRhbWFpbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxnQkFBQTtBQ0FKO0FERUU7RUFDRSxpQkFBQTtBQ0FKO0FER0k7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQ0ROO0FETUE7RUFDRSxtQkFBQTtBQ0hGO0FESUU7RUFDRSx3REFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUNGSjtBREdJO0VBQ0UsY0FBQTtBQ0ROO0FERU07RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0FDQVI7QURNRTtFQUNFLGVBQUE7QUNISjtBRElJO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0ZBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUNGTjtBRE9FO0VBQ0UsZUFBQTtFQUNBLDRGQUFBO0VBQ0EsbUJBQUE7QUNKSjtBREtJO0VBQ0UscUJBQUE7RUFDQSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxvQkFBQTtBQ0hOO0FES0k7RUFDRSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtBQ0hOIiwiZmlsZSI6InNyYy9hcHAvYXl1ZGEvYXl1ZGFtYWluL2F5dWRhbWFpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tdGl0bGUge1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB9XHJcbiAgaW9uLWJ1dHRvbnMge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgfVxyXG4gIC5idG4tcmlnaHQge1xyXG4gICAgLmFsZXJ0LXRhZyB7XHJcbiAgICAgIHdpZHRoOiAxMnB4O1xyXG4gICAgICBoZWlnaHQ6IDEycHg7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNmYjRmMzM7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgcmlnaHQ6IC0zcHg7XHJcbiAgICAgIGJvdHRvbTogLTJweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi5zZWFyY2gtYXJlYXtcclxuICBtYXJnaW4tYm90dG9tOiAyNXB4O1xyXG4gIC5jb250ZW50LXNlYXJjaCB7XHJcbiAgICBib3gtc2hhZG93OiBpbnNldCAwIDJweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yNTg4MjM1Mjk0MTE3NjQ3Myk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgcGFkZGluZzogMTVweCAyMnB4O1xyXG4gICAgc3BhbiB7XHJcbiAgICAgIGNvbG9yOiAjOGM4YjhiO1xyXG4gICAgICBpbWcge1xyXG4gICAgICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiBib3R0b207XHJcbiAgICAgICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbi5heXVkYS1saXN0IHtcclxuICB1bCB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDA7XHJcbiAgICBsaSB7XHJcbiAgICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcclxuICAgICAgY29sb3I6ICM1MTc2RjM7XHJcbiAgICAgIGJveC1zaGFkb3c6IDBweCA1cHggMTVweCByZ2JhKDQ3LCA0NywgNDcsIDAuMTUpLCAwcHggMnB4IDJweCByZ2JhKDQ3LCA0NywgNDcsIDAuMik7XHJcbiAgICAgIHBhZGRpbmc6IDE0cHggMjBweDtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogMThweDtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuLnRhYi1zZWN0aW9uIHtcclxuICB1bCB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDA7XHJcbiAgICBib3gtc2hhZG93OiBpbnNldCAwIDVweCAxNXB4IHJnYmEoNTAsIDcyLCAyMDAsIDAuMTUpLCBpbnNldCAwIDJweCAycHggcmdiYSg1MCwgNzIsIDIwMCwgMC4yKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICBsaSB7XHJcbiAgICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcclxuICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgY29sb3I6ICM1ZDViNWI7XHJcbiAgICAgIHBhZGRpbmc6IDE0cHggMTQuNXB4O1xyXG4gICAgfVxyXG4gICAgLmFjdGl2ZSB7XHJcbiAgICAgIGJhY2tncm91bmQ6ICM1MTc2RjM7XHJcbiAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpb24taGVhZGVyIGlvbi10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5pb24taGVhZGVyIGlvbi1idXR0b25zIHtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG59XG5pb24taGVhZGVyIC5idG4tcmlnaHQgLmFsZXJ0LXRhZyB7XG4gIHdpZHRoOiAxMnB4O1xuICBoZWlnaHQ6IDEycHg7XG4gIGJhY2tncm91bmQ6ICNmYjRmMzM7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IC0zcHg7XG4gIGJvdHRvbTogLTJweDtcbn1cblxuLnNlYXJjaC1hcmVhIHtcbiAgbWFyZ2luLWJvdHRvbTogMjVweDtcbn1cbi5zZWFyY2gtYXJlYSAuY29udGVudC1zZWFyY2gge1xuICBib3gtc2hhZG93OiBpbnNldCAwIDJweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yNTg4MjM1Mjk0KTtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgcGFkZGluZzogMTVweCAyMnB4O1xufVxuLnNlYXJjaC1hcmVhIC5jb250ZW50LXNlYXJjaCBzcGFuIHtcbiAgY29sb3I6ICM4YzhiOGI7XG59XG4uc2VhcmNoLWFyZWEgLmNvbnRlbnQtc2VhcmNoIHNwYW4gaW1nIHtcbiAgd2lkdGg6IDIwcHg7XG4gIHZlcnRpY2FsLWFsaWduOiBib3R0b207XG4gIGZsb2F0OiByaWdodDtcbn1cblxuLmF5dWRhLWxpc3QgdWwge1xuICBwYWRkaW5nLWxlZnQ6IDA7XG59XG4uYXl1ZGEtbGlzdCB1bCBsaSB7XG4gIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbiAgY29sb3I6ICM1MTc2RjM7XG4gIGJveC1zaGFkb3c6IDBweCA1cHggMTVweCByZ2JhKDQ3LCA0NywgNDcsIDAuMTUpLCAwcHggMnB4IDJweCByZ2JhKDQ3LCA0NywgNDcsIDAuMik7XG4gIHBhZGRpbmc6IDE0cHggMjBweDtcbiAgbWFyZ2luLWJvdHRvbTogMThweDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbn1cblxuLnRhYi1zZWN0aW9uIHVsIHtcbiAgcGFkZGluZy1sZWZ0OiAwO1xuICBib3gtc2hhZG93OiBpbnNldCAwIDVweCAxNXB4IHJnYmEoNTAsIDcyLCAyMDAsIDAuMTUpLCBpbnNldCAwIDJweCAycHggcmdiYSg1MCwgNzIsIDIwMCwgMC4yKTtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbn1cbi50YWItc2VjdGlvbiB1bCBsaSB7XG4gIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBmb250LXNpemU6IDE0cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICM1ZDViNWI7XG4gIHBhZGRpbmc6IDE0cHggMTQuNXB4O1xufVxuLnRhYi1zZWN0aW9uIHVsIC5hY3RpdmUge1xuICBiYWNrZ3JvdW5kOiAjNTE3NkYzO1xuICBjb2xvcjogI2ZmZjtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/ayuda/ayudamain/ayudamain.page.ts":
/*!***************************************************!*\
  !*** ./src/app/ayuda/ayudamain/ayudamain.page.ts ***!
  \***************************************************/
/*! exports provided: AyudamainPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AyudamainPage", function() { return AyudamainPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let AyudamainPage = class AyudamainPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
        this.SelectedData = 'Pagos';
        this.TabsData = [
            {
                name: 'Pagos',
            },
            {
                name: 'Seguros',
            },
            {
                name: 'Nominas',
            },
            {
                name: 'Descuentos',
            },
        ];
    }
    ngOnInit() {
    }
    tabsElement(tab) {
        this.SelectedData = tab.name;
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
};
AyudamainPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
AyudamainPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-ayudamain',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./ayudamain.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/ayuda/ayudamain/ayudamain.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./ayudamain.page.scss */ "./src/app/ayuda/ayudamain/ayudamain.page.scss")).default]
    })
], AyudamainPage);



/***/ })

}]);
//# sourceMappingURL=ayuda-ayudamain-ayudamain-module-es2015.js.map