function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["onboardslider-onboardslider-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/onboardslider/onboardslider.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/onboardslider/onboardslider.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppOnboardsliderOnboardsliderPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"help-circle-outline\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <ion-slides pager=\"true\" [options]=\"slideboard\">\n\n    <ion-slide>\n      <div class=\"slider-content\">\n        <img src=\"assets/imgs/board-slide-1.png\" alt=\"\">\n        <div class=\"text-area\">\n          <h5>¡Hola soy Paco!</h5>\n          <p>A partir de hoy me voy a encargar de hacer más fácil tu día a día dentro y fuera del trabajo. </p>\n        </div>\n        <ion-button>Siguiente</ion-button>\n      </div>\n    </ion-slide>\n\n    <ion-slide>\n      <div class=\"slider-content\">\n        <img src=\"assets/imgs/board-slide-2.png\" alt=\"\">\n        <div class=\"text-area\">\n          <h5>¿Qué es Paco?</h5>\n          <p>La aplicación donde podrás encontrar beneficios, comunicaciones de tu empresa y herramientas\n            para que tu opinión sea escuchada en el trabajo. </p>\n        </div>\n        <ion-button>Siguiente</ion-button>\n      </div>\n    </ion-slide>\n\n    <ion-slide>\n      <div class=\"slider-content\">\n        <img src=\"assets/imgs/board-slide-3.png\" alt=\"\">\n        <div class=\"text-area\">\n          <h5>¡Paco te ayuda!</h5>\n          <p>Te puedo adelantar la quincena, recargar tu celular, pagar la luz, darte acceso a servicios médicos privados\n            24/7 para toda tu familia y ofrecerte descuentos en cientos de establecimientos.</p>\n        </div>\n        <ion-button>Siguiente</ion-button>\n      </div>\n    </ion-slide>\n\n    <ion-slide>\n      <div class=\"slider-content\">\n        <img src=\"assets/imgs/board-slide-4.png\" alt=\"\">\n        <div class=\"text-area\">\n          <h5>¡Paco te escucha!</h5>\n          <p>Tu opinión es muy importante para mí. Podrás enviarme comentarios anónimos, reconocer a tus compañeros y sobre todo\n            participar en difrentes encuestas para mejorar tus condiciones de trabajo.</p>\n        </div>\n        <ion-button (click)=\"PageRoute('home')\">Comenzar</ion-button>\n      </div>\n    </ion-slide>\n\n  </ion-slides>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/onboardslider/onboardslider-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/onboardslider/onboardslider-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: OnboardsliderPageRoutingModule */

  /***/
  function srcAppOnboardsliderOnboardsliderRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OnboardsliderPageRoutingModule", function () {
      return OnboardsliderPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _onboardslider_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./onboardslider.page */
    "./src/app/onboardslider/onboardslider.page.ts");

    var routes = [{
      path: '',
      component: _onboardslider_page__WEBPACK_IMPORTED_MODULE_3__["OnboardsliderPage"]
    }];

    var OnboardsliderPageRoutingModule = function OnboardsliderPageRoutingModule() {
      _classCallCheck(this, OnboardsliderPageRoutingModule);
    };

    OnboardsliderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], OnboardsliderPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/onboardslider/onboardslider.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/onboardslider/onboardslider.module.ts ***!
    \*******************************************************/

  /*! exports provided: OnboardsliderPageModule */

  /***/
  function srcAppOnboardsliderOnboardsliderModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OnboardsliderPageModule", function () {
      return OnboardsliderPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _onboardslider_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./onboardslider-routing.module */
    "./src/app/onboardslider/onboardslider-routing.module.ts");
    /* harmony import */


    var _onboardslider_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./onboardslider.page */
    "./src/app/onboardslider/onboardslider.page.ts");

    var OnboardsliderPageModule = function OnboardsliderPageModule() {
      _classCallCheck(this, OnboardsliderPageModule);
    };

    OnboardsliderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _onboardslider_routing_module__WEBPACK_IMPORTED_MODULE_5__["OnboardsliderPageRoutingModule"]],
      declarations: [_onboardslider_page__WEBPACK_IMPORTED_MODULE_6__["OnboardsliderPage"]]
    })], OnboardsliderPageModule);
    /***/
  },

  /***/
  "./src/app/onboardslider/onboardslider.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/onboardslider/onboardslider.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppOnboardsliderOnboardsliderPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header::after {\n  background-image: none !important;\n}\nion-header .btn-right ion-icon {\n  font-size: 24px;\n}\nion-content {\n  --background: #5176f3;\n}\nion-content .slider-content {\n  padding: 20px;\n}\nion-content .slider-content img {\n  margin: 0 0 30px;\n  width: 150px;\n}\nion-content .slider-content .text-area {\n  height: 156px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\nion-content .slider-content h5 {\n  color: #fff;\n  margin-bottom: 18px;\n  font-weight: 600;\n}\nion-content .slider-content p {\n  color: #fff;\n}\nion-content .slider-content ion-button {\n  --background: #fff;\n  color: #2f57de;\n  margin-top: 120px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvb25ib2FyZHNsaWRlci9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXG9uYm9hcmRzbGlkZXJcXG9uYm9hcmRzbGlkZXIucGFnZS5zY3NzIiwic3JjL2FwcC9vbmJvYXJkc2xpZGVyL29uYm9hcmRzbGlkZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UsaUNBQUE7QUNBSjtBREdJO0VBQ0UsZUFBQTtBQ0ROO0FES0E7RUFDRSxxQkFBQTtBQ0ZGO0FER0U7RUFDRSxhQUFBO0FDREo7QURFSTtFQUNFLGdCQUFBO0VBQ0EsWUFBQTtBQ0FOO0FERUk7RUFDRSxhQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQ0FOO0FERUk7RUFDRSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQ0FOO0FERUk7RUFDRSxXQUFBO0FDQU47QURFSTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0FDQU4iLCJmaWxlIjoic3JjL2FwcC9vbmJvYXJkc2xpZGVyL29uYm9hcmRzbGlkZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgJjo6YWZ0ZXIge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogbm9uZSFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIC5idG4tcmlnaHQge1xyXG4gICAgaW9uLWljb24ge1xyXG4gICAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbmlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XHJcbiAgLnNsaWRlci1jb250ZW50IHtcclxuICAgIHBhZGRpbmc6IDIwcHg7XHJcbiAgICBpbWcge1xyXG4gICAgICBtYXJnaW46IDAgMCAzMHB4O1xyXG4gICAgICB3aWR0aDogMTUwcHg7XHJcbiAgICB9XHJcbiAgICAudGV4dC1hcmVhIHtcclxuICAgICAgaGVpZ2h0OiAxNTZweDtcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICBoNSB7XHJcbiAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAxOHB4O1xyXG4gICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgfVxyXG4gICAgcCB7XHJcbiAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgfVxyXG4gICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgIC0tYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgY29sb3I6ICMyZjU3ZGU7XHJcbiAgICAgIG1hcmdpbi10b3A6IDEyMHB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpb24taGVhZGVyOjphZnRlciB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmUgIWltcG9ydGFudDtcbn1cbmlvbi1oZWFkZXIgLmJ0bi1yaWdodCBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjRweDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XG59XG5pb24tY29udGVudCAuc2xpZGVyLWNvbnRlbnQge1xuICBwYWRkaW5nOiAyMHB4O1xufVxuaW9uLWNvbnRlbnQgLnNsaWRlci1jb250ZW50IGltZyB7XG4gIG1hcmdpbjogMCAwIDMwcHg7XG4gIHdpZHRoOiAxNTBweDtcbn1cbmlvbi1jb250ZW50IC5zbGlkZXItY29udGVudCAudGV4dC1hcmVhIHtcbiAgaGVpZ2h0OiAxNTZweDtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5pb24tY29udGVudCAuc2xpZGVyLWNvbnRlbnQgaDUge1xuICBjb2xvcjogI2ZmZjtcbiAgbWFyZ2luLWJvdHRvbTogMThweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbmlvbi1jb250ZW50IC5zbGlkZXItY29udGVudCBwIHtcbiAgY29sb3I6ICNmZmY7XG59XG5pb24tY29udGVudCAuc2xpZGVyLWNvbnRlbnQgaW9uLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZDogI2ZmZjtcbiAgY29sb3I6ICMyZjU3ZGU7XG4gIG1hcmdpbi10b3A6IDEyMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/onboardslider/onboardslider.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/onboardslider/onboardslider.page.ts ***!
    \*****************************************************/

  /*! exports provided: OnboardsliderPage */

  /***/
  function srcAppOnboardsliderOnboardsliderPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OnboardsliderPage", function () {
      return OnboardsliderPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var OnboardsliderPage = /*#__PURE__*/function () {
      function OnboardsliderPage(router, menuCtrl) {
        _classCallCheck(this, OnboardsliderPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
        this.slideboard = {
          initialSlide: 0,
          speed: 800,
          autoplay: false,
          slidesPerView: 1,
          spaceBetween: 2,
          cssClass: 'board-slider'
        };
      }

      _createClass(OnboardsliderPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "PageRoute",
        value: function PageRoute(urlSlug) {
          this.router.navigateByUrl('/' + urlSlug);
        }
      }]);

      return OnboardsliderPage;
    }();

    OnboardsliderPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    OnboardsliderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-onboardslider',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./onboardslider.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/onboardslider/onboardslider.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./onboardslider.page.scss */
      "./src/app/onboardslider/onboardslider.page.scss"))["default"]]
    })], OnboardsliderPage);
    /***/
  }
}]);
//# sourceMappingURL=onboardslider-onboardslider-module-es5.js.map