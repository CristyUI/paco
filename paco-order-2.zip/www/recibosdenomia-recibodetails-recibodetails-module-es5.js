function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["recibosdenomia-recibodetails-recibodetails-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/recibosdenomia/recibodetails/recibodetails.page.html":
  /*!************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/recibosdenomia/recibodetails/recibodetails.page.html ***!
    \************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRecibosdenomiaRecibodetailsRecibodetailsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"secondary\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Del 01/SEP al 15/SEP</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <img src=\"assets/imgs/documentation/doc-full.png\" alt=\"\">\n  <ion-fab slot=\"fixed\" (click)=\"PageRoute('home')\">\n    <ion-fab-button color=\"secondary\">Compartir</ion-fab-button>\n  </ion-fab>\n</ion-content>\n\n";
    /***/
  },

  /***/
  "./src/app/recibosdenomia/recibodetails/recibodetails-routing.module.ts":
  /*!******************************************************************************!*\
    !*** ./src/app/recibosdenomia/recibodetails/recibodetails-routing.module.ts ***!
    \******************************************************************************/

  /*! exports provided: RecibodetailsPageRoutingModule */

  /***/
  function srcAppRecibosdenomiaRecibodetailsRecibodetailsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RecibodetailsPageRoutingModule", function () {
      return RecibodetailsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _recibodetails_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./recibodetails.page */
    "./src/app/recibosdenomia/recibodetails/recibodetails.page.ts");

    var routes = [{
      path: '',
      component: _recibodetails_page__WEBPACK_IMPORTED_MODULE_3__["RecibodetailsPage"]
    }];

    var RecibodetailsPageRoutingModule = function RecibodetailsPageRoutingModule() {
      _classCallCheck(this, RecibodetailsPageRoutingModule);
    };

    RecibodetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], RecibodetailsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/recibosdenomia/recibodetails/recibodetails.module.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/recibosdenomia/recibodetails/recibodetails.module.ts ***!
    \**********************************************************************/

  /*! exports provided: RecibodetailsPageModule */

  /***/
  function srcAppRecibosdenomiaRecibodetailsRecibodetailsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RecibodetailsPageModule", function () {
      return RecibodetailsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _recibodetails_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./recibodetails-routing.module */
    "./src/app/recibosdenomia/recibodetails/recibodetails-routing.module.ts");
    /* harmony import */


    var _recibodetails_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./recibodetails.page */
    "./src/app/recibosdenomia/recibodetails/recibodetails.page.ts");

    var RecibodetailsPageModule = function RecibodetailsPageModule() {
      _classCallCheck(this, RecibodetailsPageModule);
    };

    RecibodetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _recibodetails_routing_module__WEBPACK_IMPORTED_MODULE_5__["RecibodetailsPageRoutingModule"]],
      declarations: [_recibodetails_page__WEBPACK_IMPORTED_MODULE_6__["RecibodetailsPage"]]
    })], RecibodetailsPageModule);
    /***/
  },

  /***/
  "./src/app/recibosdenomia/recibodetails/recibodetails.page.scss":
  /*!**********************************************************************!*\
    !*** ./src/app/recibosdenomia/recibodetails/recibodetails.page.scss ***!
    \**********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRecibosdenomiaRecibodetailsRecibodetailsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-fab {\n  position: fixed;\n  right: 24px;\n  bottom: 42px;\n}\nion-fab ion-fab-button {\n  width: 123px !important;\n  height: 49px !important;\n  --border-radius: 30px;\n  font-family: \"Lato\", sans-serif;\n  font-size: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVjaWJvc2Rlbm9taWEvcmVjaWJvZGV0YWlscy9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXHJlY2lib3NkZW5vbWlhXFxyZWNpYm9kZXRhaWxzXFxyZWNpYm9kZXRhaWxzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcmVjaWJvc2Rlbm9taWEvcmVjaWJvZGV0YWlscy9yZWNpYm9kZXRhaWxzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQ0NGO0FEQUU7RUFDRSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0EscUJBQUE7RUFDQSwrQkFBQTtFQUNBLGVBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL3JlY2lib3NkZW5vbWlhL3JlY2lib2RldGFpbHMvcmVjaWJvZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tZmFiIHtcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgcmlnaHQ6IDI0cHg7XHJcbiAgYm90dG9tOiA0MnB4O1xyXG4gIGlvbi1mYWItYnV0dG9uIHtcclxuICAgIHdpZHRoOiAxMjNweCAhaW1wb3J0YW50O1xyXG4gICAgaGVpZ2h0OiA0OXB4ICFpbXBvcnRhbnQ7XHJcbiAgICAtLWJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICBmb250LWZhbWlseTogXCJMYXRvXCIsIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgfVxyXG59IiwiaW9uLWZhYiB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgcmlnaHQ6IDI0cHg7XG4gIGJvdHRvbTogNDJweDtcbn1cbmlvbi1mYWIgaW9uLWZhYi1idXR0b24ge1xuICB3aWR0aDogMTIzcHggIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA0OXB4ICFpbXBvcnRhbnQ7XG4gIC0tYm9yZGVyLXJhZGl1czogMzBweDtcbiAgZm9udC1mYW1pbHk6IFwiTGF0b1wiLCBzYW5zLXNlcmlmO1xuICBmb250LXNpemU6IDE2cHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/recibosdenomia/recibodetails/recibodetails.page.ts":
  /*!********************************************************************!*\
    !*** ./src/app/recibosdenomia/recibodetails/recibodetails.page.ts ***!
    \********************************************************************/

  /*! exports provided: RecibodetailsPage */

  /***/
  function srcAppRecibosdenomiaRecibodetailsRecibodetailsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RecibodetailsPage", function () {
      return RecibodetailsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var RecibodetailsPage = /*#__PURE__*/function () {
      function RecibodetailsPage(router, menuCtrl) {
        _classCallCheck(this, RecibodetailsPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
      }

      _createClass(RecibodetailsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "PageRoute",
        value: function PageRoute(urlSlug) {
          this.router.navigateByUrl('/' + urlSlug);
        }
      }]);

      return RecibodetailsPage;
    }();

    RecibodetailsPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    RecibodetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-recibodetails',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./recibodetails.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/recibosdenomia/recibodetails/recibodetails.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./recibodetails.page.scss */
      "./src/app/recibosdenomia/recibodetails/recibodetails.page.scss"))["default"]]
    })], RecibodetailsPage);
    /***/
  }
}]);
//# sourceMappingURL=recibosdenomia-recibodetails-recibodetails-module-es5.js.map