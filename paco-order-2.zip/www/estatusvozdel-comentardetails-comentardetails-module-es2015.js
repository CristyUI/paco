(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["estatusvozdel-comentardetails-comentardetails-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/estatusvozdel/comentardetails/comentardetails.page.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/estatusvozdel/comentardetails/comentardetails.page.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"term-content\">\n    <h3>(TEMA)</h3>\n    <h5><span class=\"stat-tag green\"></span>Atendido <span class=\"title-right\">Ayer - 17:00</span></h5>\n    <h4>Nullam dictum at metus at semper.</h4>\n    <p>Vitae et eu sagittis ut volutpat enim. Massa quam dolor scelerisque ante consequat viverra ultrices aliquet.\n      Varius metus viverra vivamus sed ut adipiscing dictum non pharetra. Tempus lorem velit elementum praesent\n      ipsum elit quam ultricies. Lorem vulputate justo, scelerisque nascetur.</p>\n\n      <p>Varius metus viverra vivamus sed ut adipiscing dictum non pharetra. Tempus lorem velit elementum praesent\n      ipsum elit quam ultricies. Lorem vulputate justo, scelerisque nascetur.Varius metus viverra vivamus sed ut\n      adipiscing dictum non pharetra. Fcing dictum non pharetra. Tempus lorem velit elementum praesent.</p>\n\n    <h6>Respuesta</h6>\n\n    <h4>Nullam dictum at metus at semper.</h4>\n    <p>Vitae et eu sagittis ut volutpat enim. Massa quam dolor scelerisque ante consequat viverra ultrices aliquet.\n      Varius metus viverra vivamus sed ut adipiscing dictum non pharetra. Tempus lorem velit elementum praesent\n      ipsum elit quam ultricies. Lorem vulputate justo, scelerisque nascetur.</p>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/estatusvozdel/comentardetails/comentardetails-routing.module.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/estatusvozdel/comentardetails/comentardetails-routing.module.ts ***!
  \*********************************************************************************/
/*! exports provided: ComentardetailsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComentardetailsPageRoutingModule", function() { return ComentardetailsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _comentardetails_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./comentardetails.page */ "./src/app/estatusvozdel/comentardetails/comentardetails.page.ts");




const routes = [
    {
        path: '',
        component: _comentardetails_page__WEBPACK_IMPORTED_MODULE_3__["ComentardetailsPage"]
    }
];
let ComentardetailsPageRoutingModule = class ComentardetailsPageRoutingModule {
};
ComentardetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ComentardetailsPageRoutingModule);



/***/ }),

/***/ "./src/app/estatusvozdel/comentardetails/comentardetails.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/estatusvozdel/comentardetails/comentardetails.module.ts ***!
  \*************************************************************************/
/*! exports provided: ComentardetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComentardetailsPageModule", function() { return ComentardetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _comentardetails_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./comentardetails-routing.module */ "./src/app/estatusvozdel/comentardetails/comentardetails-routing.module.ts");
/* harmony import */ var _comentardetails_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./comentardetails.page */ "./src/app/estatusvozdel/comentardetails/comentardetails.page.ts");







let ComentardetailsPageModule = class ComentardetailsPageModule {
};
ComentardetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _comentardetails_routing_module__WEBPACK_IMPORTED_MODULE_5__["ComentardetailsPageRoutingModule"]
        ],
        declarations: [_comentardetails_page__WEBPACK_IMPORTED_MODULE_6__["ComentardetailsPage"]]
    })
], ComentardetailsPageModule);



/***/ }),

/***/ "./src/app/estatusvozdel/comentardetails/comentardetails.page.scss":
/*!*************************************************************************!*\
  !*** ./src/app/estatusvozdel/comentardetails/comentardetails.page.scss ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #5176f3;\n}\nion-content .term-content {\n  background: #fff;\n  padding: 20px 21px;\n  margin: 8px 20px 20px;\n  border-radius: 20px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\nion-content .term-content h4 {\n  font-size: 17px;\n  font-weight: 800;\n}\nion-content .term-content h3 {\n  font-size: 18px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n  text-transform: uppercase;\n}\nion-content .term-content h5 {\n  font-size: 15px;\n  color: #737171;\n}\nion-content .term-content h5 .stat-tag {\n  width: 20px;\n  height: 20px;\n  display: inline-block;\n  border-radius: 50%;\n  position: relative;\n  top: 4px;\n  margin-right: 12px;\n}\nion-content .term-content h5 .green {\n  background: #20A39E;\n}\nion-content .term-content h5 .yellow {\n  background: #FFBA49;\n}\nion-content .term-content h5 .orange {\n  background: #FF8643;\n}\nion-content .term-content h5 .title-right {\n  float: right;\n  padding-top: 3px;\n}\nion-content .term-content h6 {\n  color: #4f74ee;\n}\nion-content .term-content p {\n  color: #737171;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZXN0YXR1c3ZvemRlbC9jb21lbnRhcmRldGFpbHMvRzpcXGlvbmljXFxGSVZFUlJcXHBhbnRhbGxhcy1wYWNvL3NyY1xcYXBwXFxlc3RhdHVzdm96ZGVsXFxjb21lbnRhcmRldGFpbHNcXGNvbWVudGFyZGV0YWlscy5wYWdlLnNjc3MiLCJzcmMvYXBwL2VzdGF0dXN2b3pkZWwvY29tZW50YXJkZXRhaWxzL2NvbWVudGFyZGV0YWlscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtBQ0NGO0FEQUU7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLCtDQUFBO0FDRUo7QURESTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQ0dOO0FEREk7RUFDRSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0FDR047QURESTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDR047QURGTTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLGtCQUFBO0FDSVI7QURGTTtFQUNFLG1CQUFBO0FDSVI7QURGTTtFQUNFLG1CQUFBO0FDSVI7QURGTTtFQUNFLG1CQUFBO0FDSVI7QURGTTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtBQ0lSO0FEREk7RUFDRSxjQUFBO0FDR047QURESTtFQUNFLGNBQUE7QUNHTiIsImZpbGUiOiJzcmMvYXBwL2VzdGF0dXN2b3pkZWwvY29tZW50YXJkZXRhaWxzL2NvbWVudGFyZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gIC50ZXJtLWNvbnRlbnQge1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIHBhZGRpbmc6IDIwcHggMjFweDtcclxuICAgIG1hcmdpbjogOHB4IDIwcHggMjBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcclxuICAgIGg0IHtcclxuICAgICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgICBmb250LXdlaWdodDogODAwO1xyXG4gICAgfVxyXG4gICAgaDMge1xyXG4gICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDZweDtcclxuICAgICAgY29sb3I6ICMyYzU1ZTA7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICB9XHJcbiAgICBoNSB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgY29sb3I6ICM3MzcxNzE7XHJcbiAgICAgIC5zdGF0LXRhZyB7XHJcbiAgICAgICAgd2lkdGg6IDIwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiAyMHB4O1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHRvcDogNHB4O1xyXG4gICAgICAgIG1hcmdpbi1yaWdodDogMTJweDtcclxuICAgICAgfVxyXG4gICAgICAuZ3JlZW4ge1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICMyMEEzOUU7XHJcbiAgICAgIH1cclxuICAgICAgLnllbGxvdyB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI0ZGQkE0OTtcclxuICAgICAgfVxyXG4gICAgICAub3JhbmdlIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjRkY4NjQzO1xyXG4gICAgICB9XHJcbiAgICAgIC50aXRsZS1yaWdodCB7XHJcbiAgICAgICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAzcHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGg2IHtcclxuICAgICAgY29sb3I6ICM0Zjc0ZWU7XHJcbiAgICB9XHJcbiAgICBwIHtcclxuICAgICAgY29sb3I6ICM3MzcxNzE7XHJcbiAgICB9XHJcbiAgfVxyXG59IiwiaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgcGFkZGluZzogMjBweCAyMXB4O1xuICBtYXJnaW46IDhweCAyMHB4IDIwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIGJveC1zaGFkb3c6IDAgN3B4IDE2cHggLTdweCByZ2JhKDAsIDAsIDAsIDAuNjkpO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBoNCB7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaDMge1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbi10b3A6IDZweDtcbiAgY29sb3I6ICMyYzU1ZTA7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGg1IHtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBjb2xvcjogIzczNzE3MTtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaDUgLnN0YXQtdGFnIHtcbiAgd2lkdGg6IDIwcHg7XG4gIGhlaWdodDogMjBweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdG9wOiA0cHg7XG4gIG1hcmdpbi1yaWdodDogMTJweDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaDUgLmdyZWVuIHtcbiAgYmFja2dyb3VuZDogIzIwQTM5RTtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaDUgLnllbGxvdyB7XG4gIGJhY2tncm91bmQ6ICNGRkJBNDk7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGg1IC5vcmFuZ2Uge1xuICBiYWNrZ3JvdW5kOiAjRkY4NjQzO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBoNSAudGl0bGUtcmlnaHQge1xuICBmbG9hdDogcmlnaHQ7XG4gIHBhZGRpbmctdG9wOiAzcHg7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGg2IHtcbiAgY29sb3I6ICM0Zjc0ZWU7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IHAge1xuICBjb2xvcjogIzczNzE3MTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/estatusvozdel/comentardetails/comentardetails.page.ts":
/*!***********************************************************************!*\
  !*** ./src/app/estatusvozdel/comentardetails/comentardetails.page.ts ***!
  \***********************************************************************/
/*! exports provided: ComentardetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComentardetailsPage", function() { return ComentardetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let ComentardetailsPage = class ComentardetailsPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
};
ComentardetailsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
ComentardetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-comentardetails',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./comentardetails.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/estatusvozdel/comentardetails/comentardetails.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./comentardetails.page.scss */ "./src/app/estatusvozdel/comentardetails/comentardetails.page.scss")).default]
    })
], ComentardetailsPage);



/***/ })

}]);
//# sourceMappingURL=estatusvozdel-comentardetails-comentardetails-module-es2015.js.map