function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["estatusvozdel-comentarios-comentarios-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/estatusvozdel/comentarios/comentarios.page.html":
  /*!*******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/estatusvozdel/comentarios/comentarios.page.html ***!
    \*******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppEstatusvozdelComentariosComentariosPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" (click)=\"PageRoute('home')\">\n      <ion-icon name=\"chevron-back-outline\" color=\"secondary\" style=\"margin-top: 4px;\"></ion-icon>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Estatus voz del empleado</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <div class=\"ion-padding\">\n\n    <div class=\"search-area\">\n      <div class=\"content-search\" (click)=\"PageRoute('search')\">\n        <span>Buscar<img src=\"assets/imgs/search-icon.png\" alt=\"\"></span>\n      </div>\n    </div>\n\n    <ion-row>\n      <ion-col size=\"6\">\n        <div class=\"filter-area\" (click)=\"sortby()\">\n          <p>Ordenar por<span><ion-icon name=\"chevron-down-outline\"></ion-icon></span></p>\n        </div>\n      </ion-col>\n      <ion-col size=\"6\">\n        <div class=\"filter-area\">\n          <p>Estatus<span><ion-icon name=\"chevron-down-outline\"></ion-icon></span></p>\n        </div>\n      </ion-col>\n    </ion-row>\n\n\n    <div class=\"list-display\">\n\n      <div class=\"item-single\" (click)=\"PageRoute('comentardetails')\">\n        <ul>\n          <li class=\"title\">(Tema) </li>\n          <li class=\"sub-title\">Atendido </li>\n          <li class=\"status\"><span class=\"stat-tag green\"></span></li>\n          <li class=\"icon-link\"><ion-icon name=\"chevron-forward-outline\" color=\"secondary\"></ion-icon> </li>\n        </ul>\n        <p>Convallis at cras gravida pharetra, tellus, pulvinar</p>\n      </div>\n\n      <div class=\"item-single\" (click)=\"PageRoute('comentardetails')\">\n        <ul>\n          <li class=\"title\">(Tema) </li>\n          <li class=\"sub-title\">En proceso </li>\n          <li class=\"status\"><span class=\"stat-tag yellow\"></span></li>\n          <li class=\"icon-link\"><ion-icon name=\"chevron-forward-outline\" color=\"secondary\"></ion-icon> </li>\n        </ul>\n        <p>Convallis at cras gravida pharetra, tellus, pulvinar</p>\n      </div>\n\n      <div class=\"item-single\" (click)=\"PageRoute('comentardetails')\">\n        <ul>\n          <li class=\"title\">(Tema) </li>\n          <li class=\"sub-title\">Recibido</li>\n          <li class=\"status\"><span class=\"stat-tag orange\"></span></li>\n          <li class=\"icon-link\"><ion-icon name=\"chevron-forward-outline\" color=\"secondary\"></ion-icon> </li>\n        </ul>\n        <p>Convallis at cras gravida pharetra, tellus, pulvinar</p>\n      </div>\n\n\n    </div>\n\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/estatusvozdel/comentarios/comentarios-routing.module.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/estatusvozdel/comentarios/comentarios-routing.module.ts ***!
    \*************************************************************************/

  /*! exports provided: ComentariosPageRoutingModule */

  /***/
  function srcAppEstatusvozdelComentariosComentariosRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ComentariosPageRoutingModule", function () {
      return ComentariosPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _comentarios_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./comentarios.page */
    "./src/app/estatusvozdel/comentarios/comentarios.page.ts");

    var routes = [{
      path: '',
      component: _comentarios_page__WEBPACK_IMPORTED_MODULE_3__["ComentariosPage"]
    }];

    var ComentariosPageRoutingModule = function ComentariosPageRoutingModule() {
      _classCallCheck(this, ComentariosPageRoutingModule);
    };

    ComentariosPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ComentariosPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/estatusvozdel/comentarios/comentarios.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/estatusvozdel/comentarios/comentarios.module.ts ***!
    \*****************************************************************/

  /*! exports provided: ComentariosPageModule */

  /***/
  function srcAppEstatusvozdelComentariosComentariosModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ComentariosPageModule", function () {
      return ComentariosPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _comentarios_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./comentarios-routing.module */
    "./src/app/estatusvozdel/comentarios/comentarios-routing.module.ts");
    /* harmony import */


    var _comentarios_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./comentarios.page */
    "./src/app/estatusvozdel/comentarios/comentarios.page.ts");

    var ComentariosPageModule = function ComentariosPageModule() {
      _classCallCheck(this, ComentariosPageModule);
    };

    ComentariosPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _comentarios_routing_module__WEBPACK_IMPORTED_MODULE_5__["ComentariosPageRoutingModule"]],
      declarations: [_comentarios_page__WEBPACK_IMPORTED_MODULE_6__["ComentariosPage"]]
    })], ComentariosPageModule);
    /***/
  },

  /***/
  "./src/app/estatusvozdel/comentarios/comentarios.page.scss":
  /*!*****************************************************************!*\
    !*** ./src/app/estatusvozdel/comentarios/comentarios.page.scss ***!
    \*****************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppEstatusvozdelComentariosComentariosPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header ion-title {\n  font-weight: 600;\n}\nion-header ion-buttons {\n  margin-left: 20px;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.search-area {\n  margin-bottom: 14px;\n}\n.search-area .content-search {\n  box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.2588235294);\n  border-radius: 30px;\n  padding: 15px 22px;\n}\n.search-area .content-search span {\n  color: #8c8b8b;\n}\n.search-area .content-search span img {\n  width: 20px;\n  vertical-align: bottom;\n  float: right;\n}\n.filter-area {\n  padding: 5px 0;\n}\n.filter-area p {\n  border: 1px solid #7995f3;\n  padding: 12px 14px;\n  margin: 0;\n  border-radius: 30px;\n  width: 92%;\n  color: #797979;\n}\n.filter-area p span {\n  float: right;\n  font-size: 17px;\n  position: relative;\n  top: 2px;\n  color: #2d5eb7;\n}\n.list-display {\n  padding: 1px 2px;\n}\n.list-display .item-single {\n  padding-top: 8px;\n}\n.list-display .item-single p {\n  margin: 3px 0;\n  color: #737171;\n  width: 84%;\n}\n.list-display .item-single ul {\n  padding-left: 0;\n  margin-bottom: 8px;\n}\n.list-display .item-single ul li {\n  list-style-type: none;\n  display: inline-block;\n}\n.list-display .item-single ul li:nth-child(1) {\n  width: 57%;\n}\n.list-display .item-single ul li:nth-child(2) {\n  width: 27%;\n}\n.list-display .item-single ul li:nth-child(3) {\n  width: 10%;\n}\n.list-display .item-single ul li:nth-child(4) {\n  width: 6%;\n}\n.list-display .item-single ul li:nth-child(4) ion-icon {\n  font-size: 22px;\n}\n.list-display .item-single ul .title {\n  font-weight: 600;\n  font-size: 18px;\n}\n.list-display .item-single ul .sub-title {\n  color: #737171;\n}\n.list-display .item-single ul .status .stat-tag {\n  width: 20px;\n  height: 20px;\n  display: inline-block;\n  border-radius: 50%;\n  position: relative;\n  top: 4px;\n}\n.list-display .item-single ul .status .green {\n  background: #20A39E;\n}\n.list-display .item-single ul .status .yellow {\n  background: #FFBA49;\n}\n.list-display .item-single ul .status .orange {\n  background: #FF8643;\n}\n.list-display .item-single ul .icon-link ion-icon {\n  position: relative;\n  top: 4px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZXN0YXR1c3ZvemRlbC9jb21lbnRhcmlvcy9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXGVzdGF0dXN2b3pkZWxcXGNvbWVudGFyaW9zXFxjb21lbnRhcmlvcy5wYWdlLnNjc3MiLCJzcmMvYXBwL2VzdGF0dXN2b3pkZWwvY29tZW50YXJpb3MvY29tZW50YXJpb3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UsZ0JBQUE7QUNBSjtBREVFO0VBQ0UsaUJBQUE7QUNBSjtBREdJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNETjtBREtBO0VBQ0UsbUJBQUE7QUNGRjtBREdFO0VBQ0Usd0RBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FDREo7QURFSTtFQUNFLGNBQUE7QUNBTjtBRENNO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQ0NSO0FESUE7RUFDRSxjQUFBO0FDREY7QURFRTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsbUJBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtBQ0FKO0FEQ0k7RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLGNBQUE7QUNDTjtBREdBO0VBQ0UsZ0JBQUE7QUNBRjtBRENFO0VBQ0UsZ0JBQUE7QUNDSjtBREFJO0VBQ0UsYUFBQTtFQUNBLGNBQUE7RUFDQSxVQUFBO0FDRU47QURBSTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQ0VOO0FERE07RUFDRSxxQkFBQTtFQUNBLHFCQUFBO0FDR1I7QURGUTtFQUNFLFVBQUE7QUNJVjtBREZRO0VBQ0UsVUFBQTtBQ0lWO0FERlE7RUFDRSxVQUFBO0FDSVY7QURGUTtFQUNFLFNBQUE7QUNJVjtBREhVO0VBQ0UsZUFBQTtBQ0taO0FERE07RUFDRSxnQkFBQTtFQUNBLGVBQUE7QUNHUjtBRERNO0VBQ0UsY0FBQTtBQ0dSO0FEQVE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7QUNFVjtBREFRO0VBQ0UsbUJBQUE7QUNFVjtBREFRO0VBQ0UsbUJBQUE7QUNFVjtBREFRO0VBQ0UsbUJBQUE7QUNFVjtBREVRO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0FDQVYiLCJmaWxlIjoic3JjL2FwcC9lc3RhdHVzdm96ZGVsL2NvbWVudGFyaW9zL2NvbWVudGFyaW9zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xyXG4gIGlvbi10aXRsZSB7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gIH1cclxuICBpb24tYnV0dG9ucyB7XHJcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcclxuICB9XHJcbiAgLmJ0bi1yaWdodCB7XHJcbiAgICAuYWxlcnQtdGFnIHtcclxuICAgICAgd2lkdGg6IDEycHg7XHJcbiAgICAgIGhlaWdodDogMTJweDtcclxuICAgICAgYmFja2dyb3VuZDogI2ZiNGYzMztcclxuICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICByaWdodDogLTNweDtcclxuICAgICAgYm90dG9tOiAtMnB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4uc2VhcmNoLWFyZWF7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTRweDtcclxuICAuY29udGVudC1zZWFyY2gge1xyXG4gICAgYm94LXNoYWRvdzogaW5zZXQgMCAycHggMTBweCByZ2JhKDAsIDAsIDAsIDAuMjU4ODIzNTI5NDExNzY0NzMpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIHBhZGRpbmc6IDE1cHggMjJweDtcclxuICAgIHNwYW4ge1xyXG4gICAgICBjb2xvcjogIzhjOGI4YjtcclxuICAgICAgaW1nIHtcclxuICAgICAgICB3aWR0aDogMjBweDtcclxuICAgICAgICB2ZXJ0aWNhbC1hbGlnbjogYm90dG9tO1xyXG4gICAgICAgIGZsb2F0OiByaWdodDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4uZmlsdGVyLWFyZWEge1xyXG4gIHBhZGRpbmc6IDVweCAwO1xyXG4gIHAge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzc5OTVmMztcclxuICAgIHBhZGRpbmc6IDEycHggMTRweDtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICB3aWR0aDogOTIlO1xyXG4gICAgY29sb3I6ICM3OTc5Nzk7XHJcbiAgICBzcGFuIHtcclxuICAgICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgdG9wOiAycHg7XHJcbiAgICAgIGNvbG9yOiAjMmQ1ZWI3O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4ubGlzdC1kaXNwbGF5IHtcclxuICBwYWRkaW5nOiAxcHggMnB4O1xyXG4gIC5pdGVtLXNpbmdsZSB7XHJcbiAgICBwYWRkaW5nLXRvcDogOHB4O1xyXG4gICAgcCB7XHJcbiAgICAgIG1hcmdpbjogM3B4IDA7XHJcbiAgICAgIGNvbG9yOiAjNzM3MTcxO1xyXG4gICAgICB3aWR0aDogODQlO1xyXG4gICAgfVxyXG4gICAgdWwge1xyXG4gICAgICBwYWRkaW5nLWxlZnQ6IDA7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDhweDtcclxuICAgICAgbGkge1xyXG4gICAgICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgJjpudGgtY2hpbGQoMSl7XHJcbiAgICAgICAgICB3aWR0aDogNTclO1xyXG4gICAgICAgIH1cclxuICAgICAgICAmOm50aC1jaGlsZCgyKXtcclxuICAgICAgICAgIHdpZHRoOiAyNyU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICY6bnRoLWNoaWxkKDMpe1xyXG4gICAgICAgICAgd2lkdGg6IDEwJTtcclxuICAgICAgICB9XHJcbiAgICAgICAgJjpudGgtY2hpbGQoNCl7XHJcbiAgICAgICAgICB3aWR0aDogNiU7XHJcbiAgICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgLnRpdGxlIHtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgfVxyXG4gICAgICAuc3ViLXRpdGxlIHtcclxuICAgICAgICBjb2xvcjogIzczNzE3MTtcclxuICAgICAgfVxyXG4gICAgICAuc3RhdHVzIHtcclxuICAgICAgICAuc3RhdC10YWcge1xyXG4gICAgICAgICAgd2lkdGg6IDIwcHg7XHJcbiAgICAgICAgICBoZWlnaHQ6IDIwcHg7XHJcbiAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICB0b3A6IDRweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmdyZWVuIHtcclxuICAgICAgICAgIGJhY2tncm91bmQ6ICMyMEEzOUU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC55ZWxsb3cge1xyXG4gICAgICAgICAgYmFja2dyb3VuZDogI0ZGQkE0OTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLm9yYW5nZSB7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kOiAjRkY4NjQzO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAuaWNvbi1saW5rIHtcclxuICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICB0b3A6IDRweDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn0iLCJpb24taGVhZGVyIGlvbi10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5pb24taGVhZGVyIGlvbi1idXR0b25zIHtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG59XG5pb24taGVhZGVyIC5idG4tcmlnaHQgLmFsZXJ0LXRhZyB7XG4gIHdpZHRoOiAxMnB4O1xuICBoZWlnaHQ6IDEycHg7XG4gIGJhY2tncm91bmQ6ICNmYjRmMzM7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IC0zcHg7XG4gIGJvdHRvbTogLTJweDtcbn1cblxuLnNlYXJjaC1hcmVhIHtcbiAgbWFyZ2luLWJvdHRvbTogMTRweDtcbn1cbi5zZWFyY2gtYXJlYSAuY29udGVudC1zZWFyY2gge1xuICBib3gtc2hhZG93OiBpbnNldCAwIDJweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yNTg4MjM1Mjk0KTtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgcGFkZGluZzogMTVweCAyMnB4O1xufVxuLnNlYXJjaC1hcmVhIC5jb250ZW50LXNlYXJjaCBzcGFuIHtcbiAgY29sb3I6ICM4YzhiOGI7XG59XG4uc2VhcmNoLWFyZWEgLmNvbnRlbnQtc2VhcmNoIHNwYW4gaW1nIHtcbiAgd2lkdGg6IDIwcHg7XG4gIHZlcnRpY2FsLWFsaWduOiBib3R0b207XG4gIGZsb2F0OiByaWdodDtcbn1cblxuLmZpbHRlci1hcmVhIHtcbiAgcGFkZGluZzogNXB4IDA7XG59XG4uZmlsdGVyLWFyZWEgcCB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICM3OTk1ZjM7XG4gIHBhZGRpbmc6IDEycHggMTRweDtcbiAgbWFyZ2luOiAwO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICB3aWR0aDogOTIlO1xuICBjb2xvcjogIzc5Nzk3OTtcbn1cbi5maWx0ZXItYXJlYSBwIHNwYW4ge1xuICBmbG9hdDogcmlnaHQ7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IDJweDtcbiAgY29sb3I6ICMyZDVlYjc7XG59XG5cbi5saXN0LWRpc3BsYXkge1xuICBwYWRkaW5nOiAxcHggMnB4O1xufVxuLmxpc3QtZGlzcGxheSAuaXRlbS1zaW5nbGUge1xuICBwYWRkaW5nLXRvcDogOHB4O1xufVxuLmxpc3QtZGlzcGxheSAuaXRlbS1zaW5nbGUgcCB7XG4gIG1hcmdpbjogM3B4IDA7XG4gIGNvbG9yOiAjNzM3MTcxO1xuICB3aWR0aDogODQlO1xufVxuLmxpc3QtZGlzcGxheSAuaXRlbS1zaW5nbGUgdWwge1xuICBwYWRkaW5nLWxlZnQ6IDA7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cbi5saXN0LWRpc3BsYXkgLml0ZW0tc2luZ2xlIHVsIGxpIHtcbiAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG4ubGlzdC1kaXNwbGF5IC5pdGVtLXNpbmdsZSB1bCBsaTpudGgtY2hpbGQoMSkge1xuICB3aWR0aDogNTclO1xufVxuLmxpc3QtZGlzcGxheSAuaXRlbS1zaW5nbGUgdWwgbGk6bnRoLWNoaWxkKDIpIHtcbiAgd2lkdGg6IDI3JTtcbn1cbi5saXN0LWRpc3BsYXkgLml0ZW0tc2luZ2xlIHVsIGxpOm50aC1jaGlsZCgzKSB7XG4gIHdpZHRoOiAxMCU7XG59XG4ubGlzdC1kaXNwbGF5IC5pdGVtLXNpbmdsZSB1bCBsaTpudGgtY2hpbGQoNCkge1xuICB3aWR0aDogNiU7XG59XG4ubGlzdC1kaXNwbGF5IC5pdGVtLXNpbmdsZSB1bCBsaTpudGgtY2hpbGQoNCkgaW9uLWljb24ge1xuICBmb250LXNpemU6IDIycHg7XG59XG4ubGlzdC1kaXNwbGF5IC5pdGVtLXNpbmdsZSB1bCAudGl0bGUge1xuICBmb250LXdlaWdodDogNjAwO1xuICBmb250LXNpemU6IDE4cHg7XG59XG4ubGlzdC1kaXNwbGF5IC5pdGVtLXNpbmdsZSB1bCAuc3ViLXRpdGxlIHtcbiAgY29sb3I6ICM3MzcxNzE7XG59XG4ubGlzdC1kaXNwbGF5IC5pdGVtLXNpbmdsZSB1bCAuc3RhdHVzIC5zdGF0LXRhZyB7XG4gIHdpZHRoOiAyMHB4O1xuICBoZWlnaHQ6IDIwcHg7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogNHB4O1xufVxuLmxpc3QtZGlzcGxheSAuaXRlbS1zaW5nbGUgdWwgLnN0YXR1cyAuZ3JlZW4ge1xuICBiYWNrZ3JvdW5kOiAjMjBBMzlFO1xufVxuLmxpc3QtZGlzcGxheSAuaXRlbS1zaW5nbGUgdWwgLnN0YXR1cyAueWVsbG93IHtcbiAgYmFja2dyb3VuZDogI0ZGQkE0OTtcbn1cbi5saXN0LWRpc3BsYXkgLml0ZW0tc2luZ2xlIHVsIC5zdGF0dXMgLm9yYW5nZSB7XG4gIGJhY2tncm91bmQ6ICNGRjg2NDM7XG59XG4ubGlzdC1kaXNwbGF5IC5pdGVtLXNpbmdsZSB1bCAuaWNvbi1saW5rIGlvbi1pY29uIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IDRweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/estatusvozdel/comentarios/comentarios.page.ts":
  /*!***************************************************************!*\
    !*** ./src/app/estatusvozdel/comentarios/comentarios.page.ts ***!
    \***************************************************************/

  /*! exports provided: ComentariosPage */

  /***/
  function srcAppEstatusvozdelComentariosComentariosPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ComentariosPage", function () {
      return ComentariosPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var ComentariosPage = /*#__PURE__*/function () {
      function ComentariosPage(router, menuCtrl, actionSheetController) {
        _classCallCheck(this, ComentariosPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
        this.actionSheetController = actionSheetController;
      }

      _createClass(ComentariosPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "PageRoute",
        value: function PageRoute(urlSlug) {
          this.router.navigateByUrl('/' + urlSlug);
        }
      }, {
        key: "sortby",
        value: function sortby() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var actionSheet;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.actionSheetController.create({
                      header: 'Sort By',
                      mode: 'ios',
                      buttons: [{
                        text: 'Oldest',
                        handler: function handler() {
                          console.log('Oldest clicked');
                        }
                      }, {
                        text: 'Newest',
                        handler: function handler() {
                          console.log('Newest clicked');
                        }
                      }, {
                        text: 'Recently Viewed',
                        handler: function handler() {
                          console.log('Recently Viewed clicked');
                        }
                      }, {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: function handler() {
                          console.log('Cancel clicked');
                        }
                      }]
                    });

                  case 2:
                    actionSheet = _context.sent;
                    _context.next = 5;
                    return actionSheet.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }]);

      return ComentariosPage;
    }();

    ComentariosPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]
      }];
    };

    ComentariosPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-comentarios',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./comentarios.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/estatusvozdel/comentarios/comentarios.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./comentarios.page.scss */
      "./src/app/estatusvozdel/comentarios/comentarios.page.scss"))["default"]]
    })], ComentariosPage);
    /***/
  }
}]);
//# sourceMappingURL=estatusvozdel-comentarios-comentarios-module-es5.js.map