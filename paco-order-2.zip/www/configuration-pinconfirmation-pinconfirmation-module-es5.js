function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["configuration-pinconfirmation-pinconfirmation-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/pinconfirmation/pinconfirmation.page.html":
  /*!***************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/pinconfirmation/pinconfirmation.page.html ***!
    \***************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppConfigurationPinconfirmationPinconfirmationPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Confirma tu PIN</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <p>Vivamus sit amet diam rhoncus, porttitor ex a, semper arcu. Pellentesque imperdiet.</p>\n    <ion-list>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n    </ion-list>\n    <div class=\"ion-text-end\">\n      <ion-button class=\"btn-transparent\" (click)=\"PageRoute('modificado')\"><ion-icon name=\"checkmark-outline\"></ion-icon></ion-button>\n\n      <!-- AFTER BUTTON ACTIVE -->\n      <!--<ion-button class=\"btn-white\" (click)=\"PageRoute('modificado')\"><ion-icon name=\"checkmark-outline\"></ion-icon></ion-button>-->\n    </div>\n  </div>\n</ion-content>\n\n";
    /***/
  },

  /***/
  "./src/app/configuration/pinconfirmation/pinconfirmation-routing.module.ts":
  /*!*********************************************************************************!*\
    !*** ./src/app/configuration/pinconfirmation/pinconfirmation-routing.module.ts ***!
    \*********************************************************************************/

  /*! exports provided: PinconfirmationPageRoutingModule */

  /***/
  function srcAppConfigurationPinconfirmationPinconfirmationRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PinconfirmationPageRoutingModule", function () {
      return PinconfirmationPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _pinconfirmation_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./pinconfirmation.page */
    "./src/app/configuration/pinconfirmation/pinconfirmation.page.ts");

    var routes = [{
      path: '',
      component: _pinconfirmation_page__WEBPACK_IMPORTED_MODULE_3__["PinconfirmationPage"]
    }];

    var PinconfirmationPageRoutingModule = function PinconfirmationPageRoutingModule() {
      _classCallCheck(this, PinconfirmationPageRoutingModule);
    };

    PinconfirmationPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], PinconfirmationPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/configuration/pinconfirmation/pinconfirmation.module.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/configuration/pinconfirmation/pinconfirmation.module.ts ***!
    \*************************************************************************/

  /*! exports provided: PinconfirmationPageModule */

  /***/
  function srcAppConfigurationPinconfirmationPinconfirmationModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PinconfirmationPageModule", function () {
      return PinconfirmationPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _pinconfirmation_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./pinconfirmation-routing.module */
    "./src/app/configuration/pinconfirmation/pinconfirmation-routing.module.ts");
    /* harmony import */


    var _pinconfirmation_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./pinconfirmation.page */
    "./src/app/configuration/pinconfirmation/pinconfirmation.page.ts");

    var PinconfirmationPageModule = function PinconfirmationPageModule() {
      _classCallCheck(this, PinconfirmationPageModule);
    };

    PinconfirmationPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _pinconfirmation_routing_module__WEBPACK_IMPORTED_MODULE_5__["PinconfirmationPageRoutingModule"]],
      declarations: [_pinconfirmation_page__WEBPACK_IMPORTED_MODULE_6__["PinconfirmationPage"]]
    })], PinconfirmationPageModule);
    /***/
  },

  /***/
  "./src/app/configuration/pinconfirmation/pinconfirmation.page.scss":
  /*!*************************************************************************!*\
    !*** ./src/app/configuration/pinconfirmation/pinconfirmation.page.scss ***!
    \*************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppConfigurationPinconfirmationPinconfirmationPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-content {\n  --background: #5176f3;\n}\nion-content .ion-padding {\n  text-align: center;\n}\nion-content .ion-padding p {\n  color: #fff;\n  font-size: 15px;\n  line-height: 23px;\n  margin-top: 30px;\n}\nion-content .ion-padding ion-list {\n  margin: 30px 10px 5px;\n  background: transparent;\n}\nion-content .ion-padding ion-list ion-item {\n  --background: #fff;\n  --border-color: transparent;\n  border-radius: 5px;\n  display: inline-block;\n  width: 50px;\n  margin: 0 5px;\n}\nion-content .ion-padding ion-list ion-item ion-input {\n  font-size: 15px;\n  color: #fff;\n  --padding-start: 14px;\n}\nion-content .ion-padding ion-list ion-item ion-input::-moz-placeholder {\n  color: #fff;\n}\nion-content .ion-padding ion-list ion-item ion-input::-ms-input-placeholder {\n  color: #fff;\n}\nion-content .ion-padding ion-list ion-item ion-input::placeholder {\n  color: #fff;\n}\nion-content .ion-padding .ion-text-end {\n  padding: 40px 20px 0;\n}\nion-content .ion-padding .ion-text-end .btn-transparent {\n  --background: transparent;\n  color: #0c38ce;\n  --padding-end: 0;\n  --padding-start: 0;\n  width: 60px !important;\n  height: 60px;\n}\nion-content .ion-padding .ion-text-end .btn-transparent ion-icon {\n  font-size: 35px;\n}\nion-content .ion-padding .ion-text-end .btn-white {\n  --background: #fff;\n  color: #5176f3;\n  --padding-end: 0;\n  --padding-start: 0;\n  width: 60px !important;\n  height: 60px;\n}\nion-content .ion-padding .ion-text-end .btn-white ion-icon {\n  font-size: 35px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29uZmlndXJhdGlvbi9waW5jb25maXJtYXRpb24vRzpcXGlvbmljXFxGSVZFUlJcXHBhbnRhbGxhcy1wYWNvL3NyY1xcYXBwXFxjb25maWd1cmF0aW9uXFxwaW5jb25maXJtYXRpb25cXHBpbmNvbmZpcm1hdGlvbi5wYWdlLnNjc3MiLCJzcmMvYXBwL2NvbmZpZ3VyYXRpb24vcGluY29uZmlybWF0aW9uL3BpbmNvbmZpcm1hdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtBQ0NGO0FEQUU7RUFDRSxrQkFBQTtBQ0VKO0FEREk7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUNHTjtBRERJO0VBQ0UscUJBQUE7RUFDQSx1QkFBQTtBQ0dOO0FERk07RUFDRSxrQkFBQTtFQUNBLDJCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0FDSVI7QURIUTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7QUNLVjtBREpVO0VBQ0UsV0FBQTtBQ01aO0FEUFU7RUFDRSxXQUFBO0FDTVo7QURQVTtFQUNFLFdBQUE7QUNNWjtBRERJO0VBQ0Usb0JBQUE7QUNHTjtBREZNO0VBQ0UseUJBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQ0lSO0FESFE7RUFDRSxlQUFBO0FDS1Y7QURGTTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7QUNJUjtBREhRO0VBQ0UsZUFBQTtBQ0tWIiwiZmlsZSI6InNyYy9hcHAvY29uZmlndXJhdGlvbi9waW5jb25maXJtYXRpb24vcGluY29uZmlybWF0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XHJcbiAgLmlvbi1wYWRkaW5nIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHAge1xyXG4gICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICBsaW5lLWhlaWdodDogMjNweDtcclxuICAgICAgbWFyZ2luLXRvcDogMzBweDtcclxuICAgIH1cclxuICAgIGlvbi1saXN0IHtcclxuICAgICAgbWFyZ2luOiAzMHB4IDEwcHggNXB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgaW9uLWl0ZW0ge1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICB3aWR0aDogNTBweDtcclxuICAgICAgICBtYXJnaW46IDAgNXB4O1xyXG4gICAgICAgIGlvbi1pbnB1dCB7XHJcbiAgICAgICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICAgIC0tcGFkZGluZy1zdGFydDogMTRweDtcclxuICAgICAgICAgICY6OnBsYWNlaG9sZGVyIHtcclxuICAgICAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAuaW9uLXRleHQtZW5kIHtcclxuICAgICAgcGFkZGluZzogNDBweCAyMHB4IDA7XHJcbiAgICAgIC5idG4tdHJhbnNwYXJlbnQge1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgY29sb3I6ICMwYzM4Y2U7XHJcbiAgICAgICAgLS1wYWRkaW5nLWVuZDogMDtcclxuICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDA7XHJcbiAgICAgICAgd2lkdGg6IDYwcHghaW1wb3J0YW50O1xyXG4gICAgICAgIGhlaWdodDogNjBweDtcclxuICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICBmb250LXNpemU6IDM1cHg7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIC5idG4td2hpdGUge1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICBjb2xvcjogIzUxNzZmMztcclxuICAgICAgICAtLXBhZGRpbmctZW5kOiAwO1xyXG4gICAgICAgIC0tcGFkZGluZy1zdGFydDogMDtcclxuICAgICAgICB3aWR0aDogNjBweCFpbXBvcnRhbnQ7XHJcbiAgICAgICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMzVweDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn0iLCJpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyBwIHtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbGluZS1oZWlnaHQ6IDIzcHg7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgaW9uLWxpc3Qge1xuICBtYXJnaW46IDMwcHggMTBweCA1cHg7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIGlvbi1saXN0IGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xuICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogNTBweDtcbiAgbWFyZ2luOiAwIDVweDtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyBpb24tbGlzdCBpb24taXRlbSBpb24taW5wdXQge1xuICBmb250LXNpemU6IDE1cHg7XG4gIGNvbG9yOiAjZmZmO1xuICAtLXBhZGRpbmctc3RhcnQ6IDE0cHg7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgaW9uLWxpc3QgaW9uLWl0ZW0gaW9uLWlucHV0OjpwbGFjZWhvbGRlciB7XG4gIGNvbG9yOiAjZmZmO1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIC5pb24tdGV4dC1lbmQge1xuICBwYWRkaW5nOiA0MHB4IDIwcHggMDtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyAuaW9uLXRleHQtZW5kIC5idG4tdHJhbnNwYXJlbnQge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBjb2xvcjogIzBjMzhjZTtcbiAgLS1wYWRkaW5nLWVuZDogMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICB3aWR0aDogNjBweCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDYwcHg7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgLmlvbi10ZXh0LWVuZCAuYnRuLXRyYW5zcGFyZW50IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAzNXB4O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIC5pb24tdGV4dC1lbmQgLmJ0bi13aGl0ZSB7XG4gIC0tYmFja2dyb3VuZDogI2ZmZjtcbiAgY29sb3I6ICM1MTc2ZjM7XG4gIC0tcGFkZGluZy1lbmQ6IDA7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgd2lkdGg6IDYwcHggIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA2MHB4O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIC5pb24tdGV4dC1lbmQgLmJ0bi13aGl0ZSBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMzVweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/configuration/pinconfirmation/pinconfirmation.page.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/configuration/pinconfirmation/pinconfirmation.page.ts ***!
    \***********************************************************************/

  /*! exports provided: PinconfirmationPage */

  /***/
  function srcAppConfigurationPinconfirmationPinconfirmationPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PinconfirmationPage", function () {
      return PinconfirmationPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var PinconfirmationPage = /*#__PURE__*/function () {
      function PinconfirmationPage(router, menuCtrl) {
        _classCallCheck(this, PinconfirmationPage);

        this.router = router;
        this.menuCtrl = menuCtrl;
      }

      _createClass(PinconfirmationPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "PageRoute",
        value: function PageRoute(urlSlug) {
          this.router.navigateByUrl('/' + urlSlug);
        }
      }]);

      return PinconfirmationPage;
    }();

    PinconfirmationPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    PinconfirmationPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-pinconfirmation',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./pinconfirmation.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/pinconfirmation/pinconfirmation.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./pinconfirmation.page.scss */
      "./src/app/configuration/pinconfirmation/pinconfirmation.page.scss"))["default"]]
    })], PinconfirmationPage);
    /***/
  }
}]);
//# sourceMappingURL=configuration-pinconfirmation-pinconfirmation-module-es5.js.map