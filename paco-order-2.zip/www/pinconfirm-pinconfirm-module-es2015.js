(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pinconfirm-pinconfirm-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pinconfirm/pinconfirm.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pinconfirm/pinconfirm.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Confirma tu PIN</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"help-circle-outline\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <p>Usarás esta clave para confirmar transacciones.</p>\n    <ion-list>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n    </ion-list>\n    <div class=\"ion-text-end\">\n      <ion-button class=\"btn-white\" (click)=\"onboardslider()\"><ion-icon name=\"checkmark-outline\"></ion-icon></ion-button>\n    </div>\n  </div>\n</ion-content>\n\n");

/***/ }),

/***/ "./src/app/pinconfirm/pinconfirm-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pinconfirm/pinconfirm-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: PinconfirmPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PinconfirmPageRoutingModule", function() { return PinconfirmPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _pinconfirm_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pinconfirm.page */ "./src/app/pinconfirm/pinconfirm.page.ts");




const routes = [
    {
        path: '',
        component: _pinconfirm_page__WEBPACK_IMPORTED_MODULE_3__["PinconfirmPage"]
    }
];
let PinconfirmPageRoutingModule = class PinconfirmPageRoutingModule {
};
PinconfirmPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PinconfirmPageRoutingModule);



/***/ }),

/***/ "./src/app/pinconfirm/pinconfirm.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pinconfirm/pinconfirm.module.ts ***!
  \*************************************************/
/*! exports provided: PinconfirmPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PinconfirmPageModule", function() { return PinconfirmPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _pinconfirm_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pinconfirm-routing.module */ "./src/app/pinconfirm/pinconfirm-routing.module.ts");
/* harmony import */ var _pinconfirm_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pinconfirm.page */ "./src/app/pinconfirm/pinconfirm.page.ts");







let PinconfirmPageModule = class PinconfirmPageModule {
};
PinconfirmPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _pinconfirm_routing_module__WEBPACK_IMPORTED_MODULE_5__["PinconfirmPageRoutingModule"]
        ],
        declarations: [_pinconfirm_page__WEBPACK_IMPORTED_MODULE_6__["PinconfirmPage"]]
    })
], PinconfirmPageModule);



/***/ }),

/***/ "./src/app/pinconfirm/pinconfirm.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pinconfirm/pinconfirm.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header .btn-right ion-icon {\n  font-size: 24px;\n}\n\nion-content {\n  --background: #5176f3;\n}\n\nion-content .ion-padding {\n  text-align: center;\n}\n\nion-content .ion-padding p {\n  color: #fff;\n  font-size: 15px;\n  line-height: 23px;\n  margin-top: 30px;\n}\n\nion-content .ion-padding ion-list {\n  margin: 30px 10px 5px;\n  background: transparent;\n}\n\nion-content .ion-padding ion-list ion-item {\n  --background: #fff;\n  --border-color: transparent;\n  border-radius: 5px;\n  display: inline-block;\n  width: 50px;\n  margin: 0 5px;\n}\n\nion-content .ion-padding ion-list ion-item ion-input {\n  font-size: 15px;\n  color: #fff;\n  --padding-start: 14px;\n}\n\nion-content .ion-padding ion-list ion-item ion-input::-moz-placeholder {\n  color: #fff;\n}\n\nion-content .ion-padding ion-list ion-item ion-input::-ms-input-placeholder {\n  color: #fff;\n}\n\nion-content .ion-padding ion-list ion-item ion-input::placeholder {\n  color: #fff;\n}\n\nion-content .ion-padding .ion-text-end {\n  padding: 40px 20px 0;\n}\n\nion-content .ion-padding .ion-text-end .btn-white {\n  --background: #fff;\n  color: #5176f3;\n  --padding-end: 0;\n  --padding-start: 0;\n  width: 60px !important;\n  height: 60px;\n}\n\nion-content .ion-padding .ion-text-end .btn-white ion-icon {\n  font-size: 35px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGluY29uZmlybS9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXHBpbmNvbmZpcm1cXHBpbmNvbmZpcm0ucGFnZS5zY3NzIiwic3JjL2FwcC9waW5jb25maXJtL3BpbmNvbmZpcm0ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQ0UsZUFBQTtBQ0ROOztBREtBO0VBQ0UscUJBQUE7QUNGRjs7QURHRTtFQUNFLGtCQUFBO0FDREo7O0FERUk7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUNBTjs7QURFSTtFQUNFLHFCQUFBO0VBQ0EsdUJBQUE7QUNBTjs7QURDTTtFQUNFLGtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7QUNDUjs7QURBUTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7QUNFVjs7QUREVTtFQUNFLFdBQUE7QUNHWjs7QURKVTtFQUNFLFdBQUE7QUNHWjs7QURKVTtFQUNFLFdBQUE7QUNHWjs7QURFSTtFQUNFLG9CQUFBO0FDQU47O0FEQ007RUFDRSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0FDQ1I7O0FEQVE7RUFDRSxlQUFBO0FDRVYiLCJmaWxlIjoic3JjL2FwcC9waW5jb25maXJtL3BpbmNvbmZpcm0ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgLmJ0bi1yaWdodCB7XHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMjRweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcclxuICAuaW9uLXBhZGRpbmcge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcCB7XHJcbiAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgIGxpbmUtaGVpZ2h0OiAyM3B4O1xyXG4gICAgICBtYXJnaW4tdG9wOiAzMHB4O1xyXG4gICAgfVxyXG4gICAgaW9uLWxpc3Qge1xyXG4gICAgICBtYXJnaW46IDMwcHggMTBweCA1cHg7XHJcbiAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICBpb24taXRlbSB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgICAgIG1hcmdpbjogMCA1cHg7XHJcbiAgICAgICAgaW9uLWlucHV0IHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxNHB4O1xyXG4gICAgICAgICAgJjo6cGxhY2Vob2xkZXIge1xyXG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5pb24tdGV4dC1lbmQge1xyXG4gICAgICBwYWRkaW5nOiA0MHB4IDIwcHggMDtcclxuICAgICAgLmJ0bi13aGl0ZSB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgICAgIGNvbG9yOiAjNTE3NmYzO1xyXG4gICAgICAgIC0tcGFkZGluZy1lbmQ6IDA7XHJcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xyXG4gICAgICAgIHdpZHRoOiA2MHB4IWltcG9ydGFudDtcclxuICAgICAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgZm9udC1zaXplOiAzNXB4O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufSIsImlvbi1oZWFkZXIgLmJ0bi1yaWdodCBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjRweDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgcCB7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LXNpemU6IDE1cHg7XG4gIGxpbmUtaGVpZ2h0OiAyM3B4O1xuICBtYXJnaW4tdG9wOiAzMHB4O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIGlvbi1saXN0IHtcbiAgbWFyZ2luOiAzMHB4IDEwcHggNXB4O1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyBpb24tbGlzdCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogI2ZmZjtcbiAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgd2lkdGg6IDUwcHg7XG4gIG1hcmdpbjogMCA1cHg7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgaW9uLWxpc3QgaW9uLWl0ZW0gaW9uLWlucHV0IHtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBjb2xvcjogI2ZmZjtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNHB4O1xufVxuaW9uLWNvbnRlbnQgLmlvbi1wYWRkaW5nIGlvbi1saXN0IGlvbi1pdGVtIGlvbi1pbnB1dDo6cGxhY2Vob2xkZXIge1xuICBjb2xvcjogI2ZmZjtcbn1cbmlvbi1jb250ZW50IC5pb24tcGFkZGluZyAuaW9uLXRleHQtZW5kIHtcbiAgcGFkZGluZzogNDBweCAyMHB4IDA7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgLmlvbi10ZXh0LWVuZCAuYnRuLXdoaXRlIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmO1xuICBjb2xvcjogIzUxNzZmMztcbiAgLS1wYWRkaW5nLWVuZDogMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICB3aWR0aDogNjBweCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDYwcHg7XG59XG5pb24tY29udGVudCAuaW9uLXBhZGRpbmcgLmlvbi10ZXh0LWVuZCAuYnRuLXdoaXRlIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAzNXB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pinconfirm/pinconfirm.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pinconfirm/pinconfirm.page.ts ***!
  \***********************************************/
/*! exports provided: PinconfirmPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PinconfirmPage", function() { return PinconfirmPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let PinconfirmPage = class PinconfirmPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    onboardslider() {
        this.router.navigateByUrl('/onboardslider');
    }
};
PinconfirmPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
PinconfirmPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-pinconfirm',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./pinconfirm.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pinconfirm/pinconfirm.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./pinconfirm.page.scss */ "./src/app/pinconfirm/pinconfirm.page.scss")).default]
    })
], PinconfirmPage);



/***/ })

}]);
//# sourceMappingURL=pinconfirm-pinconfirm-module-es2015.js.map