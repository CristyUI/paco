(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cupones-servicios-servicios-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cupones/servicios/servicios.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cupones/servicios/servicios.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"term-content\">\n    <img src=\"assets/imgs/cupon/cupon-2.png\" alt=\"\">\n    <h5>-10% en tu siguiente transacción</h5>\n    <p>Vivamus sit amet diam rhoncus, porttitor ex a, semper arcu. Pellentesque imperdiet turpis quis lectus gravida rutrum quis sit amet leo.\n      Etiam id tincidunt diam, eleifend pretium dolor. Cras sed tincidunt felis.</p>\n    <div class=\"btn-wrap\">\n      <ion-button (click)=\"PageRoute('home')\">Aceptar</ion-button>\n    </div>\n  </div>\n</ion-content>\n\n");

/***/ }),

/***/ "./src/app/cupones/servicios/servicios-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/cupones/servicios/servicios-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: ServiciosPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServiciosPageRoutingModule", function() { return ServiciosPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _servicios_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./servicios.page */ "./src/app/cupones/servicios/servicios.page.ts");




const routes = [
    {
        path: '',
        component: _servicios_page__WEBPACK_IMPORTED_MODULE_3__["ServiciosPage"]
    }
];
let ServiciosPageRoutingModule = class ServiciosPageRoutingModule {
};
ServiciosPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ServiciosPageRoutingModule);



/***/ }),

/***/ "./src/app/cupones/servicios/servicios.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/cupones/servicios/servicios.module.ts ***!
  \*******************************************************/
/*! exports provided: ServiciosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServiciosPageModule", function() { return ServiciosPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _servicios_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./servicios-routing.module */ "./src/app/cupones/servicios/servicios-routing.module.ts");
/* harmony import */ var _servicios_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./servicios.page */ "./src/app/cupones/servicios/servicios.page.ts");







let ServiciosPageModule = class ServiciosPageModule {
};
ServiciosPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _servicios_routing_module__WEBPACK_IMPORTED_MODULE_5__["ServiciosPageRoutingModule"]
        ],
        declarations: [_servicios_page__WEBPACK_IMPORTED_MODULE_6__["ServiciosPage"]]
    })
], ServiciosPageModule);



/***/ }),

/***/ "./src/app/cupones/servicios/servicios.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/cupones/servicios/servicios.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #5176f3;\n}\nion-content .term-content {\n  background: #fff;\n  padding: 20px 22px;\n  margin: 8px 20px 20px;\n  text-align: center;\n  border-radius: 20px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\nion-content .term-content img {\n  width: 200px;\n}\nion-content .term-content h5 {\n  font-size: 18px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n}\nion-content .term-content p {\n  margin-bottom: 12px;\n}\nion-content .term-content .btn-wrap ion-button {\n  width: 44% !important;\n  height: 3.2rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3Vwb25lcy9zZXJ2aWNpb3MvRzpcXGlvbmljXFxGSVZFUlJcXHBhbnRhbGxhcy1wYWNvL3NyY1xcYXBwXFxjdXBvbmVzXFxzZXJ2aWNpb3NcXHNlcnZpY2lvcy5wYWdlLnNjc3MiLCJzcmMvYXBwL2N1cG9uZXMvc2VydmljaW9zL3NlcnZpY2lvcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtBQ0NGO0FEQUU7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsK0NBQUE7QUNFSjtBRERJO0VBQ0UsWUFBQTtBQ0dOO0FEREk7RUFDRSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQ0dOO0FEREk7RUFDRSxtQkFBQTtBQ0dOO0FEQU07RUFDRSxxQkFBQTtFQUNBLGNBQUE7QUNFUiIsImZpbGUiOiJzcmMvYXBwL2N1cG9uZXMvc2VydmljaW9zL3NlcnZpY2lvcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gIC50ZXJtLWNvbnRlbnQge1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIHBhZGRpbmc6IDIwcHggMjJweDtcclxuICAgIG1hcmdpbjogOHB4IDIwcHggMjBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcclxuICAgIGltZyB7XHJcbiAgICAgIHdpZHRoOiAyMDBweDtcclxuICAgIH1cclxuICAgIGg1IHtcclxuICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICBtYXJnaW4tdG9wOiA2cHg7XHJcbiAgICAgIGNvbG9yOiAjMmM1NWUwO1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgfVxyXG4gICAgcCB7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDEycHg7XHJcbiAgICB9XHJcbiAgICAuYnRuLXdyYXAge1xyXG4gICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICB3aWR0aDogNDQlIWltcG9ydGFudDtcclxuICAgICAgICBoZWlnaHQ6IDMuMnJlbTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufSIsImlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHBhZGRpbmc6IDIwcHggMjJweDtcbiAgbWFyZ2luOiA4cHggMjBweCAyMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIGJveC1zaGFkb3c6IDAgN3B4IDE2cHggLTdweCByZ2JhKDAsIDAsIDAsIDAuNjkpO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBpbWcge1xuICB3aWR0aDogMjAwcHg7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGg1IHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBtYXJnaW4tdG9wOiA2cHg7XG4gIGNvbG9yOiAjMmM1NWUwO1xuICBmb250LXdlaWdodDogNzAwO1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBwIHtcbiAgbWFyZ2luLWJvdHRvbTogMTJweDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgLmJ0bi13cmFwIGlvbi1idXR0b24ge1xuICB3aWR0aDogNDQlICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogMy4ycmVtO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/cupones/servicios/servicios.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/cupones/servicios/servicios.page.ts ***!
  \*****************************************************/
/*! exports provided: ServiciosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServiciosPage", function() { return ServiciosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let ServiciosPage = class ServiciosPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
};
ServiciosPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
ServiciosPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-servicios',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./servicios.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cupones/servicios/servicios.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./servicios.page.scss */ "./src/app/cupones/servicios/servicios.page.scss")).default]
    })
], ServiciosPage);



/***/ })

}]);
//# sourceMappingURL=cupones-servicios-servicios-module-es2015.js.map