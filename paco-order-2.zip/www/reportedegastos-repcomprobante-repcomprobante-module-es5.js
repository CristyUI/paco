function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["reportedegastos-repcomprobante-repcomprobante-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/reportedegastos/repcomprobante/repcomprobante.page.html":
  /*!***************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/reportedegastos/repcomprobante/repcomprobante.page.html ***!
    \***************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppReportedegastosRepcomprobanteRepcomprobantePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"comprob-wrap\">\n    <h4>Comprobante de pago</h4>\n    <table>\n      <thead>\n      <tr>\n        <th>Fecha de pago</th>\n        <th>No. de Operación</th>\n      </tr>\n      </thead>\n      <tbody>\n      <tr>\n        <td>18:24  2 de octubre, 2019</td>\n        <td>#2788-2039</td>\n      </tr>\n      </tbody>\n    </table>\n    <h5>Desglose</h5>\n    <ul>\n      <li>A recibir<span>$ 300.00</span></li>\n      <li>Comisión<span>+ $ 10.00</span></li>\n      <li>Total<span>$ 300.00</span></li>\n    </ul>\n    <p>Si tienes alguna duda, contáctanos por correo en\n      <span>ayuda@paco.com</span> o llámanos a <span>55 9807 4539</span>.</p>\n    <div class=\"btn-bottom\">\n      <ion-button class=\"full-btn\" (click)=\"PageRoute('home')\">Compartir</ion-button>\n    </div>\n  </div>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/reportedegastos/repcomprobante/repcomprobante-routing.module.ts":
  /*!*********************************************************************************!*\
    !*** ./src/app/reportedegastos/repcomprobante/repcomprobante-routing.module.ts ***!
    \*********************************************************************************/

  /*! exports provided: RepcomprobantePageRoutingModule */

  /***/
  function srcAppReportedegastosRepcomprobanteRepcomprobanteRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RepcomprobantePageRoutingModule", function () {
      return RepcomprobantePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _repcomprobante_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./repcomprobante.page */
    "./src/app/reportedegastos/repcomprobante/repcomprobante.page.ts");

    var routes = [{
      path: '',
      component: _repcomprobante_page__WEBPACK_IMPORTED_MODULE_3__["RepcomprobantePage"]
    }];

    var RepcomprobantePageRoutingModule = function RepcomprobantePageRoutingModule() {
      _classCallCheck(this, RepcomprobantePageRoutingModule);
    };

    RepcomprobantePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], RepcomprobantePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/reportedegastos/repcomprobante/repcomprobante.module.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/reportedegastos/repcomprobante/repcomprobante.module.ts ***!
    \*************************************************************************/

  /*! exports provided: RepcomprobantePageModule */

  /***/
  function srcAppReportedegastosRepcomprobanteRepcomprobanteModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RepcomprobantePageModule", function () {
      return RepcomprobantePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _repcomprobante_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./repcomprobante-routing.module */
    "./src/app/reportedegastos/repcomprobante/repcomprobante-routing.module.ts");
    /* harmony import */


    var _repcomprobante_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./repcomprobante.page */
    "./src/app/reportedegastos/repcomprobante/repcomprobante.page.ts");

    var RepcomprobantePageModule = function RepcomprobantePageModule() {
      _classCallCheck(this, RepcomprobantePageModule);
    };

    RepcomprobantePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _repcomprobante_routing_module__WEBPACK_IMPORTED_MODULE_5__["RepcomprobantePageRoutingModule"]],
      declarations: [_repcomprobante_page__WEBPACK_IMPORTED_MODULE_6__["RepcomprobantePage"]]
    })], RepcomprobantePageModule);
    /***/
  },

  /***/
  "./src/app/reportedegastos/repcomprobante/repcomprobante.page.scss":
  /*!*************************************************************************!*\
    !*** ./src/app/reportedegastos/repcomprobante/repcomprobante.page.scss ***!
    \*************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppReportedegastosRepcomprobanteRepcomprobantePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-content {\n  --background: #5176f3;\n}\nion-content .comprob-wrap {\n  background: #fff;\n  padding: 10px 20px 20px 20px;\n  position: absolute;\n  bottom: 0;\n  border-radius: 30px 30px 0 0;\n}\nion-content .comprob-wrap:before {\n  content: \"\";\n  background: rgba(255, 255, 255, 0.58);\n  top: -30px;\n  display: block;\n  height: 9px;\n  width: 60px;\n  position: relative;\n  text-align: center;\n  margin: 0 auto;\n  border-radius: 30px;\n}\nion-content .comprob-wrap h4 {\n  font-size: 18px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n  margin-bottom: 40px;\n}\nion-content .comprob-wrap table {\n  width: 100%;\n}\nion-content .comprob-wrap table thead tr th {\n  color: #777;\n  font-weight: 100;\n  font-size: 15px;\n}\nion-content .comprob-wrap table thead tr th:nth-child(1) {\n  text-align: left;\n}\nion-content .comprob-wrap table thead tr th:nth-child(2) {\n  text-align: right;\n}\nion-content .comprob-wrap table tbody tr td {\n  padding: 7px 0;\n}\nion-content .comprob-wrap table tbody tr td:nth-child(1) {\n  text-align: left;\n}\nion-content .comprob-wrap table tbody tr td:nth-child(2) {\n  text-align: right;\n}\nion-content .comprob-wrap h5 {\n  font-size: 17px;\n  font-weight: 700;\n}\nion-content .comprob-wrap ul {\n  padding-left: 0;\n}\nion-content .comprob-wrap ul li {\n  list-style-type: none;\n  padding: 5px 0;\n}\nion-content .comprob-wrap ul li span {\n  float: right;\n}\nion-content .comprob-wrap ul li:nth-child(1) span {\n  background: #5176f3;\n  color: #fff;\n  padding: 3px 13px;\n  border-radius: 30px;\n}\nion-content .comprob-wrap ul li:nth-child(3) span {\n  color: #2246bf;\n}\nion-content .comprob-wrap p {\n  color: #949494;\n  margin-bottom: 5px;\n}\nion-content .comprob-wrap p span {\n  color: #5176f3;\n}\nion-content .comprob-wrap .btn-bottom {\n  padding-top: 12px;\n  text-align: right;\n}\nion-content .comprob-wrap .btn-bottom .full-btn {\n  margin-top: 5px;\n  height: 3.2rem;\n  width: 44% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVwb3J0ZWRlZ2FzdG9zL3JlcGNvbXByb2JhbnRlL0c6XFxpb25pY1xcRklWRVJSXFxwYW50YWxsYXMtcGFjby9zcmNcXGFwcFxccmVwb3J0ZWRlZ2FzdG9zXFxyZXBjb21wcm9iYW50ZVxccmVwY29tcHJvYmFudGUucGFnZS5zY3NzIiwic3JjL2FwcC9yZXBvcnRlZGVnYXN0b3MvcmVwY29tcHJvYmFudGUvcmVwY29tcHJvYmFudGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQUE7QUNDRjtBREFFO0VBQ0UsZ0JBQUE7RUFDQSw0QkFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLDRCQUFBO0FDRUo7QURESTtFQUNFLFdBQUE7RUFDQSxxQ0FBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0FDR047QURESTtFQUNFLGVBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUNHTjtBRERJO0VBQ0UsV0FBQTtBQ0dOO0FEQVU7RUFDRSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDRVo7QUREWTtFQUNFLGdCQUFBO0FDR2Q7QUREWTtFQUNFLGlCQUFBO0FDR2Q7QURJVTtFQUNFLGNBQUE7QUNGWjtBREdZO0VBQ0UsZ0JBQUE7QUNEZDtBREdZO0VBQ0UsaUJBQUE7QUNEZDtBRE9JO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FDTE47QURPSTtFQUNFLGVBQUE7QUNMTjtBRE1NO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0FDSlI7QURLUTtFQUNFLFlBQUE7QUNIVjtBRE1VO0VBQ0UsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQ0paO0FEUVU7RUFDRSxjQUFBO0FDTlo7QURXSTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtBQ1ROO0FEVU07RUFDRSxjQUFBO0FDUlI7QURXSTtFQUNFLGlCQUFBO0VBQ0EsaUJBQUE7QUNUTjtBRFVNO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxxQkFBQTtBQ1JSIiwiZmlsZSI6InNyYy9hcHAvcmVwb3J0ZWRlZ2FzdG9zL3JlcGNvbXByb2JhbnRlL3JlcGNvbXByb2JhbnRlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XHJcbiAgLmNvbXByb2Itd3JhcCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgcGFkZGluZzogMTBweCAyMHB4IDIwcHggMjBweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHggMzBweCAwIDA7XHJcbiAgICAmOmJlZm9yZSB7XHJcbiAgICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICAgIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC41OCk7XHJcbiAgICAgIHRvcDogLTMwcHg7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICBoZWlnaHQ6IDlweDtcclxuICAgICAgd2lkdGg6IDYwcHg7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICBtYXJnaW46IDAgYXV0bztcclxuICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIH1cclxuICAgIGg0IHtcclxuICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICBtYXJnaW4tdG9wOiA2cHg7XHJcbiAgICAgIGNvbG9yOiAjMmM1NWUwO1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiA0MHB4O1xyXG4gICAgfVxyXG4gICAgdGFibGUge1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgdGhlYWQge1xyXG4gICAgICAgIHRyIHtcclxuICAgICAgICAgIHRoIHtcclxuICAgICAgICAgICAgY29sb3I6ICM3Nzc7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiAxMDA7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgICAgICAgJjpudGgtY2hpbGQoMSkge1xyXG4gICAgICAgICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgJjpudGgtY2hpbGQoMikge1xyXG4gICAgICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIHRib2R5IHtcclxuICAgICAgICB0ciB7XHJcbiAgICAgICAgICB0ZCB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDdweCAwO1xyXG4gICAgICAgICAgICAmOm50aC1jaGlsZCgxKSB7XHJcbiAgICAgICAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAmOm50aC1jaGlsZCgyKSB7XHJcbiAgICAgICAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGg1IHtcclxuICAgICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgfVxyXG4gICAgdWwge1xyXG4gICAgICBwYWRkaW5nLWxlZnQ6IDA7XHJcbiAgICAgIGxpIHtcclxuICAgICAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XHJcbiAgICAgICAgcGFkZGluZzogNXB4IDA7XHJcbiAgICAgICAgc3BhbiB7XHJcbiAgICAgICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICY6bnRoLWNoaWxkKDEpIHtcclxuICAgICAgICAgIHNwYW4ge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICAgICAgcGFkZGluZzogM3B4IDEzcHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgICY6bnRoLWNoaWxkKDMpIHtcclxuICAgICAgICAgIHNwYW4ge1xyXG4gICAgICAgICAgICBjb2xvcjogIzIyNDZiZjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHAge1xyXG4gICAgICBjb2xvcjogIzk0OTQ5NDtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG4gICAgICBzcGFuIHtcclxuICAgICAgICBjb2xvcjogIzUxNzZmMztcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmJ0bi1ib3R0b20ge1xyXG4gICAgICBwYWRkaW5nLXRvcDogMTJweDtcclxuICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICAgIC5mdWxsLWJ0biB7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgICAgIGhlaWdodDogMy4ycmVtO1xyXG4gICAgICAgIHdpZHRoOiA0NCUhaW1wb3J0YW50O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59IiwiaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwIHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgcGFkZGluZzogMTBweCAyMHB4IDIwcHggMjBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDA7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHggMzBweCAwIDA7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwOmJlZm9yZSB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC41OCk7XG4gIHRvcDogLTMwcHg7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBoZWlnaHQ6IDlweDtcbiAgd2lkdGg6IDYwcHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDAgYXV0bztcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgaDQge1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbi10b3A6IDZweDtcbiAgY29sb3I6ICMyYzU1ZTA7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIG1hcmdpbi1ib3R0b206IDQwcHg7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwIHRhYmxlIHtcbiAgd2lkdGg6IDEwMCU7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwIHRhYmxlIHRoZWFkIHRyIHRoIHtcbiAgY29sb3I6ICM3Nzc7XG4gIGZvbnQtd2VpZ2h0OiAxMDA7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgdGFibGUgdGhlYWQgdHIgdGg6bnRoLWNoaWxkKDEpIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgdGFibGUgdGhlYWQgdHIgdGg6bnRoLWNoaWxkKDIpIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwIHRhYmxlIHRib2R5IHRyIHRkIHtcbiAgcGFkZGluZzogN3B4IDA7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwIHRhYmxlIHRib2R5IHRyIHRkOm50aC1jaGlsZCgxKSB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwIHRhYmxlIHRib2R5IHRyIHRkOm50aC1jaGlsZCgyKSB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuaW9uLWNvbnRlbnQgLmNvbXByb2Itd3JhcCBoNSB7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgdWwge1xuICBwYWRkaW5nLWxlZnQ6IDA7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwIHVsIGxpIHtcbiAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xuICBwYWRkaW5nOiA1cHggMDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgdWwgbGkgc3BhbiB7XG4gIGZsb2F0OiByaWdodDtcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgdWwgbGk6bnRoLWNoaWxkKDEpIHNwYW4ge1xuICBiYWNrZ3JvdW5kOiAjNTE3NmYzO1xuICBjb2xvcjogI2ZmZjtcbiAgcGFkZGluZzogM3B4IDEzcHg7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwIHVsIGxpOm50aC1jaGlsZCgzKSBzcGFuIHtcbiAgY29sb3I6ICMyMjQ2YmY7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwIHAge1xuICBjb2xvcjogIzk0OTQ5NDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xufVxuaW9uLWNvbnRlbnQgLmNvbXByb2Itd3JhcCBwIHNwYW4ge1xuICBjb2xvcjogIzUxNzZmMztcbn1cbmlvbi1jb250ZW50IC5jb21wcm9iLXdyYXAgLmJ0bi1ib3R0b20ge1xuICBwYWRkaW5nLXRvcDogMTJweDtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5pb24tY29udGVudCAuY29tcHJvYi13cmFwIC5idG4tYm90dG9tIC5mdWxsLWJ0biB7XG4gIG1hcmdpbi10b3A6IDVweDtcbiAgaGVpZ2h0OiAzLjJyZW07XG4gIHdpZHRoOiA0NCUgIWltcG9ydGFudDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/reportedegastos/repcomprobante/repcomprobante.page.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/reportedegastos/repcomprobante/repcomprobante.page.ts ***!
    \***********************************************************************/

  /*! exports provided: RepcomprobantePage */

  /***/
  function srcAppReportedegastosRepcomprobanteRepcomprobantePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RepcomprobantePage", function () {
      return RepcomprobantePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var RepcomprobantePage = /*#__PURE__*/function () {
      function RepcomprobantePage(router, menuCtrl) {
        _classCallCheck(this, RepcomprobantePage);

        this.router = router;
        this.menuCtrl = menuCtrl;
      }

      _createClass(RepcomprobantePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(false);
        }
      }, {
        key: "ionViewDidLeave",
        value: function ionViewDidLeave() {
          this.menuCtrl.enable(true);
        }
      }, {
        key: "PageRoute",
        value: function PageRoute(urlSlug) {
          this.router.navigateByUrl('/' + urlSlug);
        }
      }]);

      return RepcomprobantePage;
    }();

    RepcomprobantePage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }];
    };

    RepcomprobantePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-repcomprobante',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./repcomprobante.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/reportedegastos/repcomprobante/repcomprobante.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./repcomprobante.page.scss */
      "./src/app/reportedegastos/repcomprobante/repcomprobante.page.scss"))["default"]]
    })], RepcomprobantePage);
    /***/
  }
}]);
//# sourceMappingURL=reportedegastos-repcomprobante-repcomprobante-module-es5.js.map