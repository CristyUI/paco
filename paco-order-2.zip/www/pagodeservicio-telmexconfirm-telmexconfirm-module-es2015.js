(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pagodeservicio-telmexconfirm-telmexconfirm-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/telmexconfirm/telmexconfirm.page.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/telmexconfirm/telmexconfirm.page.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"telmex-content\">\n    <h6>Confirmación</h6>\n    <ion-list>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n      <ion-item class=\"ion-no-padding\">\n        <ion-input type=\"text\"></ion-input>\n      </ion-item>\n    </ion-list>\n    <div class=\"btn-bottom\">\n      <ion-row>\n        <ion-col size=\"6\">\n          <ion-button class=\"btn-transparent\" (click)=\"PageRoute('telmex')\">Anterior</ion-button>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-end\">\n          <ion-button class=\"btn-round\" (click)=\"PageRoute('comprobante')\"><ion-icon name=\"checkmark-sharp\"></ion-icon></ion-button>\n        </ion-col>\n      </ion-row>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pagodeservicio/telmexconfirm/telmexconfirm-routing.module.ts":
/*!******************************************************************************!*\
  !*** ./src/app/pagodeservicio/telmexconfirm/telmexconfirm-routing.module.ts ***!
  \******************************************************************************/
/*! exports provided: TelmexconfirmPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TelmexconfirmPageRoutingModule", function() { return TelmexconfirmPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _telmexconfirm_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./telmexconfirm.page */ "./src/app/pagodeservicio/telmexconfirm/telmexconfirm.page.ts");




const routes = [
    {
        path: '',
        component: _telmexconfirm_page__WEBPACK_IMPORTED_MODULE_3__["TelmexconfirmPage"]
    }
];
let TelmexconfirmPageRoutingModule = class TelmexconfirmPageRoutingModule {
};
TelmexconfirmPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TelmexconfirmPageRoutingModule);



/***/ }),

/***/ "./src/app/pagodeservicio/telmexconfirm/telmexconfirm.module.ts":
/*!**********************************************************************!*\
  !*** ./src/app/pagodeservicio/telmexconfirm/telmexconfirm.module.ts ***!
  \**********************************************************************/
/*! exports provided: TelmexconfirmPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TelmexconfirmPageModule", function() { return TelmexconfirmPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _telmexconfirm_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./telmexconfirm-routing.module */ "./src/app/pagodeservicio/telmexconfirm/telmexconfirm-routing.module.ts");
/* harmony import */ var _telmexconfirm_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./telmexconfirm.page */ "./src/app/pagodeservicio/telmexconfirm/telmexconfirm.page.ts");







let TelmexconfirmPageModule = class TelmexconfirmPageModule {
};
TelmexconfirmPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _telmexconfirm_routing_module__WEBPACK_IMPORTED_MODULE_5__["TelmexconfirmPageRoutingModule"]
        ],
        declarations: [_telmexconfirm_page__WEBPACK_IMPORTED_MODULE_6__["TelmexconfirmPage"]]
    })
], TelmexconfirmPageModule);



/***/ }),

/***/ "./src/app/pagodeservicio/telmexconfirm/telmexconfirm.page.scss":
/*!**********************************************************************!*\
  !*** ./src/app/pagodeservicio/telmexconfirm/telmexconfirm.page.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #5176f3;\n}\nion-content .telmex-content {\n  background: #fff;\n  padding: 20px 25px;\n  margin: 10px 20px 20px;\n  border-radius: 20px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\nion-content .telmex-content h6 {\n  text-align: center;\n  font-size: 17px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n}\nion-content .telmex-content ion-list {\n  margin: 30px 10px 5px;\n  background: transparent;\n}\nion-content .telmex-content ion-list ion-item {\n  --background: transparent;\n  --border-color: transparent;\n  border-radius: 5px;\n  display: inline-block;\n  width: 52px;\n  height: 52px;\n  margin: 0 5px;\n  box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.2588235294);\n}\nion-content .telmex-content ion-list ion-item ion-input {\n  font-size: 15px;\n  color: #fff;\n  --padding-start: 14px;\n}\nion-content .telmex-content ion-list ion-item ion-input::-moz-placeholder {\n  color: #fff;\n}\nion-content .telmex-content ion-list ion-item ion-input::-ms-input-placeholder {\n  color: #fff;\n}\nion-content .telmex-content ion-list ion-item ion-input::placeholder {\n  color: #fff;\n}\nion-content .telmex-content .btn-bottom .btn-transparent {\n  color: #2246bf;\n  height: 1.6rem;\n  margin-bottom: 15px !important;\n  --box-shadow: none!important;\n  margin-top: 12px !important;\n  --padding-end: 4px;\n  font-weight: 700;\n  text-transform: capitalize;\n  --padding-start: 4px;\n  width: auto !important;\n  --border-radius: none!important;\n  margin-left: 10px;\n}\nion-content .telmex-content .btn-bottom .btn-round {\n  --background: #c7d4ff;\n  color: #ffffff;\n  --padding-end: 0;\n  --padding-start: 0;\n  width: 62px !important;\n  height: 62px;\n  margin-top: 5px;\n  --box-shadow: 0;\n}\nion-content .telmex-content .btn-bottom .btn-round ion-icon {\n  font-size: 35px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnb2Rlc2VydmljaW8vdGVsbWV4Y29uZmlybS9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXHBhZ29kZXNlcnZpY2lvXFx0ZWxtZXhjb25maXJtXFx0ZWxtZXhjb25maXJtLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnb2Rlc2VydmljaW8vdGVsbWV4Y29uZmlybS90ZWxtZXhjb25maXJtLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FDQ0Y7QURBRTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsK0NBQUE7QUNFSjtBRERJO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQ0dOO0FEREk7RUFDRSxxQkFBQTtFQUNBLHVCQUFBO0FDR047QURGTTtFQUNFLHlCQUFBO0VBQ0EsMkJBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esd0RBQUE7QUNJUjtBREhRO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxxQkFBQTtBQ0tWO0FESlU7RUFDRSxXQUFBO0FDTVo7QURQVTtFQUNFLFdBQUE7QUNNWjtBRFBVO0VBQ0UsV0FBQTtBQ01aO0FEQU07RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLDhCQUFBO0VBQ0EsNEJBQUE7RUFDQSwyQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSwwQkFBQTtFQUNBLG9CQUFBO0VBQ0Esc0JBQUE7RUFDQSwrQkFBQTtFQUNBLGlCQUFBO0FDRVI7QURBTTtFQUNFLHFCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtBQ0VSO0FERFE7RUFDRSxlQUFBO0FDR1YiLCJmaWxlIjoic3JjL2FwcC9wYWdvZGVzZXJ2aWNpby90ZWxtZXhjb25maXJtL3RlbG1leGNvbmZpcm0ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcclxuICAudGVsbWV4LWNvbnRlbnQge1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIHBhZGRpbmc6IDIwcHggMjVweDtcclxuICAgIG1hcmdpbjogMTBweCAyMHB4IDIwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgYm94LXNoYWRvdzogMCA3cHggMTZweCAtN3B4IHJnYmEoMCwgMCwgMCwgMC42OSk7XHJcbiAgICBoNiB7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgICBtYXJnaW4tdG9wOiA2cHg7XHJcbiAgICAgIGNvbG9yOiAjMmM1NWUwO1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgfVxyXG4gICAgaW9uLWxpc3Qge1xyXG4gICAgICBtYXJnaW46IDMwcHggMTBweCA1cHg7XHJcbiAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICBpb24taXRlbSB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgICAtLWJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICB3aWR0aDogNTJweDtcclxuICAgICAgICBoZWlnaHQ6IDUycHg7XHJcbiAgICAgICAgbWFyZ2luOiAwIDVweDtcclxuICAgICAgICBib3gtc2hhZG93OiBpbnNldCAwIDJweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4yNTg4MjM1Mjk0MTE3NjQ3Myk7XHJcbiAgICAgICAgaW9uLWlucHV0IHtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAxNHB4O1xyXG4gICAgICAgICAgJjo6cGxhY2Vob2xkZXIge1xyXG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5idG4tYm90dG9tIHtcclxuICAgICAgLmJ0bi10cmFuc3BhcmVudCB7XHJcbiAgICAgICAgY29sb3I6ICMyMjQ2YmY7XHJcbiAgICAgICAgaGVpZ2h0OiAxLjZyZW07XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMTVweCFpbXBvcnRhbnQ7XHJcbiAgICAgICAgLS1ib3gtc2hhZG93OiBub25lIWltcG9ydGFudDtcclxuICAgICAgICBtYXJnaW4tdG9wOiAxMnB4IWltcG9ydGFudDtcclxuICAgICAgICAtLXBhZGRpbmctZW5kOiA0cHg7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgICAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcclxuICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDRweDtcclxuICAgICAgICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xyXG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogbm9uZSFpbXBvcnRhbnQ7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICAgIH1cclxuICAgICAgLmJ0bi1yb3VuZCB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjYzdkNGZmO1xyXG4gICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgIC0tcGFkZGluZy1lbmQ6IDA7XHJcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xyXG4gICAgICAgIHdpZHRoOiA2MnB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgaGVpZ2h0OiA2MnB4O1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDVweDtcclxuICAgICAgICAtLWJveC1zaGFkb3c6IDA7XHJcbiAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgZm9udC1zaXplOiAzNXB4O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufSIsImlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xufVxuaW9uLWNvbnRlbnQgLnRlbG1leC1jb250ZW50IHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgcGFkZGluZzogMjBweCAyNXB4O1xuICBtYXJnaW46IDEwcHggMjBweCAyMHB4O1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCBoNiB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBtYXJnaW4tdG9wOiA2cHg7XG4gIGNvbG9yOiAjMmM1NWUwO1xuICBmb250LXdlaWdodDogNzAwO1xufVxuaW9uLWNvbnRlbnQgLnRlbG1leC1jb250ZW50IGlvbi1saXN0IHtcbiAgbWFyZ2luOiAzMHB4IDEwcHggNXB4O1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCBpb24tbGlzdCBpb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiA1MnB4O1xuICBoZWlnaHQ6IDUycHg7XG4gIG1hcmdpbjogMCA1cHg7XG4gIGJveC1zaGFkb3c6IGluc2V0IDAgMnB4IDEwcHggcmdiYSgwLCAwLCAwLCAwLjI1ODgyMzUyOTQpO1xufVxuaW9uLWNvbnRlbnQgLnRlbG1leC1jb250ZW50IGlvbi1saXN0IGlvbi1pdGVtIGlvbi1pbnB1dCB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgY29sb3I6ICNmZmY7XG4gIC0tcGFkZGluZy1zdGFydDogMTRweDtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCBpb24tbGlzdCBpb24taXRlbSBpb24taW5wdXQ6OnBsYWNlaG9sZGVyIHtcbiAgY29sb3I6ICNmZmY7XG59XG5pb24tY29udGVudCAudGVsbWV4LWNvbnRlbnQgLmJ0bi1ib3R0b20gLmJ0bi10cmFuc3BhcmVudCB7XG4gIGNvbG9yOiAjMjI0NmJmO1xuICBoZWlnaHQ6IDEuNnJlbTtcbiAgbWFyZ2luLWJvdHRvbTogMTVweCAhaW1wb3J0YW50O1xuICAtLWJveC1zaGFkb3c6IG5vbmUhaW1wb3J0YW50O1xuICBtYXJnaW4tdG9wOiAxMnB4ICFpbXBvcnRhbnQ7XG4gIC0tcGFkZGluZy1lbmQ6IDRweDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gIC0tcGFkZGluZy1zdGFydDogNHB4O1xuICB3aWR0aDogYXV0byAhaW1wb3J0YW50O1xuICAtLWJvcmRlci1yYWRpdXM6IG5vbmUhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cbmlvbi1jb250ZW50IC50ZWxtZXgtY29udGVudCAuYnRuLWJvdHRvbSAuYnRuLXJvdW5kIHtcbiAgLS1iYWNrZ3JvdW5kOiAjYzdkNGZmO1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgLS1wYWRkaW5nLWVuZDogMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICB3aWR0aDogNjJweCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDYycHg7XG4gIG1hcmdpbi10b3A6IDVweDtcbiAgLS1ib3gtc2hhZG93OiAwO1xufVxuaW9uLWNvbnRlbnQgLnRlbG1leC1jb250ZW50IC5idG4tYm90dG9tIC5idG4tcm91bmQgaW9uLWljb24ge1xuICBmb250LXNpemU6IDM1cHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/pagodeservicio/telmexconfirm/telmexconfirm.page.ts":
/*!********************************************************************!*\
  !*** ./src/app/pagodeservicio/telmexconfirm/telmexconfirm.page.ts ***!
  \********************************************************************/
/*! exports provided: TelmexconfirmPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TelmexconfirmPage", function() { return TelmexconfirmPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let TelmexconfirmPage = class TelmexconfirmPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
};
TelmexconfirmPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
TelmexconfirmPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-telmexconfirm',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./telmexconfirm.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pagodeservicio/telmexconfirm/telmexconfirm.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./telmexconfirm.page.scss */ "./src/app/pagodeservicio/telmexconfirm/telmexconfirm.page.scss")).default]
    })
], TelmexconfirmPage);



/***/ })

}]);
//# sourceMappingURL=pagodeservicio-telmexconfirm-telmexconfirm-module-es2015.js.map