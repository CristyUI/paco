(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["encuestas-multichoicefour-multichoicefour-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/encuestas/multichoicefour/multichoicefour.page.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/encuestas/multichoicefour/multichoicefour.page.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\" (click)=\"PageRoute('encumain')\">\n      <ion-icon name=\"close\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n  <div class=\"term-content\">\n    <h5>Pregunta 4 de 6</h5>\n    <h6>¿Sagittis ultricies quam nisl?</h6>\n    <p>Urna fames nunc, nisl at. Vel luctus velit massa amet.</p>\n    <ion-progress-bar color=\"primary\" value=\"0.6\"></ion-progress-bar>\n    <ion-list>\n      <ion-radio-group allow-empty-selection=\"true\" (ionChange)=\"radioGroupChange($event)\" >\n        <ion-item class=\"ion-no-padding\" [ngClass]=\"{'active': (SelectedData == 'b1alt')}\">\n          <ion-radio value=\"b1alt\" ></ion-radio>\n          <ion-label >B1-Alt</ion-label>\n        </ion-item>\n\n        <ion-item  class=\"ion-no-padding\" [ngClass]=\"{'active': (SelectedData == 'b2alt')}\">\n          <ion-radio value=\"b2alt\"></ion-radio>\n          <ion-label>B2-Alt</ion-label>\n        </ion-item>\n\n        <ion-item  class=\"ion-no-padding\" [ngClass]=\"{'active': (SelectedData == 'b3alt')}\">\n          <ion-radio value=\"b3alt\"></ion-radio>\n          <ion-label>B3-Alt</ion-label>\n        </ion-item>\n        <ion-item  class=\"ion-no-padding\" [ngClass]=\"{'active': (SelectedData == 'b4alt')}\">\n          <ion-radio value=\"b4alt\"></ion-radio>\n          <ion-label>B4-Alt</ion-label>\n        </ion-item>\n        <ion-item  class=\"ion-no-padding\" [ngClass]=\"{'active': (SelectedData == 'b5alt')}\">\n          <ion-radio value=\"b5alt\"></ion-radio>\n          <ion-label>B5-Alt</ion-label>\n        </ion-item>\n      </ion-radio-group>\n    </ion-list>\n\n    <div class=\"btn-bottom\">\n      <ion-row>\n        <ion-col size=\"6\">\n          <ion-button class=\"btn-transparent\" (click)=\"PageRoute('multichoicethree')\">Anterior</ion-button>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-button (click)=\"PageRoute('multichoicefive')\">Continuar</ion-button>\n        </ion-col>\n      </ion-row>\n    </div>\n\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/encuestas/multichoicefour/multichoicefour-routing.module.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/encuestas/multichoicefour/multichoicefour-routing.module.ts ***!
  \*****************************************************************************/
/*! exports provided: MultichoicefourPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultichoicefourPageRoutingModule", function() { return MultichoicefourPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _multichoicefour_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./multichoicefour.page */ "./src/app/encuestas/multichoicefour/multichoicefour.page.ts");




const routes = [
    {
        path: '',
        component: _multichoicefour_page__WEBPACK_IMPORTED_MODULE_3__["MultichoicefourPage"]
    }
];
let MultichoicefourPageRoutingModule = class MultichoicefourPageRoutingModule {
};
MultichoicefourPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MultichoicefourPageRoutingModule);



/***/ }),

/***/ "./src/app/encuestas/multichoicefour/multichoicefour.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/encuestas/multichoicefour/multichoicefour.module.ts ***!
  \*********************************************************************/
/*! exports provided: MultichoicefourPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultichoicefourPageModule", function() { return MultichoicefourPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _multichoicefour_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./multichoicefour-routing.module */ "./src/app/encuestas/multichoicefour/multichoicefour-routing.module.ts");
/* harmony import */ var _multichoicefour_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./multichoicefour.page */ "./src/app/encuestas/multichoicefour/multichoicefour.page.ts");







let MultichoicefourPageModule = class MultichoicefourPageModule {
};
MultichoicefourPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _multichoicefour_routing_module__WEBPACK_IMPORTED_MODULE_5__["MultichoicefourPageRoutingModule"]
        ],
        declarations: [_multichoicefour_page__WEBPACK_IMPORTED_MODULE_6__["MultichoicefourPage"]]
    })
], MultichoicefourPageModule);



/***/ }),

/***/ "./src/app/encuestas/multichoicefour/multichoicefour.page.scss":
/*!*********************************************************************!*\
  !*** ./src/app/encuestas/multichoicefour/multichoicefour.page.scss ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-buttons {\n  margin-left: 20px;\n}\n\nion-content {\n  --background: #5176f3;\n}\n\nion-content .term-content {\n  background: #fff;\n  padding: 20px 25px;\n  margin: 16px 20px 20px;\n  text-align: center;\n  border-radius: 30px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\n\nion-content .term-content h5 {\n  font-size: 17px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n  text-align: left;\n}\n\nion-content .term-content h6 {\n  text-align: left;\n  font-size: 15px;\n  font-weight: 700;\n}\n\nion-content .term-content p {\n  text-align: left;\n  font-size: 14px;\n  line-height: 20px;\n  color: #808080;\n  margin-bottom: 2px;\n}\n\nion-content .term-content ion-progress-bar {\n  margin: 15px 0 8px;\n  height: 9px;\n  border-radius: 20px;\n}\n\nion-content .term-content ion-list ion-item {\n  --border-color: transparent;\n  font-size: 15px;\n  color: #2c55e0;\n  border: 1px solid #2c55e0;\n  --min-height: 32px;\n  padding: 4px 14px;\n  margin: 12px 0;\n  border-radius: 30px;\n  font-weight: 600;\n}\n\nion-content .term-content ion-list ion-item ion-radio {\n  width: 28px;\n  height: 28px;\n  margin: 4px 12px 4px 0;\n}\n\nion-content .term-content ion-list .active {\n  --background: transparent;\n  background: #5176f3;\n  color: #fff;\n}\n\nion-content .term-content ion-list .active ion-radio {\n  --color: #fff;\n  --color-checked: #ffffff;\n}\n\nion-content .term-content .btn-bottom .btn-transparent {\n  color: #2c55e0;\n}\n\nion-content .term-content .btn-bottom ion-button {\n  margin-top: 10px;\n  width: 100% !important;\n  height: 3rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZW5jdWVzdGFzL211bHRpY2hvaWNlZm91ci9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXGVuY3Vlc3Rhc1xcbXVsdGljaG9pY2Vmb3VyXFxtdWx0aWNob2ljZWZvdXIucGFnZS5zY3NzIiwic3JjL2FwcC9lbmN1ZXN0YXMvbXVsdGljaG9pY2Vmb3VyL211bHRpY2hvaWNlZm91ci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxpQkFBQTtBQ0FKOztBREdBO0VBQ0UscUJBQUE7QUNBRjs7QURDRTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSwrQ0FBQTtBQ0NKOztBREFJO0VBQ0UsZUFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ0VOOztBREFJO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNFTjs7QURBSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FDRU47O0FEQUk7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtBQ0VOOztBRENNO0VBQ0UsMkJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FDQ1I7O0FEQVE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0FDRVY7O0FEQ007RUFDRSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQ0NSOztBREFRO0VBQ0UsYUFBQTtFQUNBLHdCQUFBO0FDRVY7O0FESU07RUFDRSxjQUFBO0FDRlI7O0FESU07RUFDRSxnQkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtBQ0ZSIiwiZmlsZSI6InNyYy9hcHAvZW5jdWVzdGFzL211bHRpY2hvaWNlZm91ci9tdWx0aWNob2ljZWZvdXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgaW9uLWJ1dHRvbnMge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgfVxyXG59XHJcbmlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XHJcbiAgLnRlcm0tY29udGVudCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgcGFkZGluZzogMjBweCAyNXB4O1xyXG4gICAgbWFyZ2luOiAxNnB4IDIwcHggMjBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcclxuICAgIGg1IHtcclxuICAgICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgICBtYXJnaW4tdG9wOiA2cHg7XHJcbiAgICAgIGNvbG9yOiAjMmM1NWUwO1xyXG4gICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgfVxyXG4gICAgaDYge1xyXG4gICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICB9XHJcbiAgICBwIHtcclxuICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICBsaW5lLWhlaWdodDogMjBweDtcclxuICAgICAgY29sb3I6ICM4MDgwODA7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDJweDtcclxuICAgIH1cclxuICAgIGlvbi1wcm9ncmVzcy1iYXIge1xyXG4gICAgICBtYXJnaW46IDE1cHggMCA4cHg7XHJcbiAgICAgIGhlaWdodDogOXB4O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgfVxyXG4gICAgaW9uLWxpc3Qge1xyXG4gICAgICBpb24taXRlbSB7XHJcbiAgICAgICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgICBjb2xvcjogIzJjNTVlMDtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjMmM1NWUwO1xyXG4gICAgICAgIC0tbWluLWhlaWdodDogMzJweDtcclxuICAgICAgICBwYWRkaW5nOiA0cHggMTRweDtcclxuICAgICAgICBtYXJnaW46IDEycHggMDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgaW9uLXJhZGlvIHtcclxuICAgICAgICAgIHdpZHRoOiAyOHB4O1xyXG4gICAgICAgICAgaGVpZ2h0OiAyOHB4O1xyXG4gICAgICAgICAgbWFyZ2luOiA0cHggMTJweCA0cHggMDtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgLmFjdGl2ZSB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgIGlvbi1yYWRpbyB7XHJcbiAgICAgICAgICAtLWNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgLS1jb2xvci1jaGVja2VkOiAjZmZmZmZmO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5idG4tYm90dG9tIHtcclxuICAgICAgLmJ0bi10cmFuc3BhcmVudCB7XHJcbiAgICAgICAgY29sb3I6ICMyYzU1ZTA7XHJcbiAgICAgIH1cclxuICAgICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgICB3aWR0aDogMTAwJSFpbXBvcnRhbnQ7XHJcbiAgICAgICAgaGVpZ2h0OiAzcmVtO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59IiwiaW9uLWhlYWRlciBpb24tYnV0dG9ucyB7XG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogIzUxNzZmMztcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBwYWRkaW5nOiAyMHB4IDI1cHg7XG4gIG1hcmdpbjogMTZweCAyMHB4IDIwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgYm94LXNoYWRvdzogMCA3cHggMTZweCAtN3B4IHJnYmEoMCwgMCwgMCwgMC42OSk7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGg1IHtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBtYXJnaW4tdG9wOiA2cHg7XG4gIGNvbG9yOiAjMmM1NWUwO1xuICBmb250LXdlaWdodDogNzAwO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBoNiB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgcCB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgbGluZS1oZWlnaHQ6IDIwcHg7XG4gIGNvbG9yOiAjODA4MDgwO1xuICBtYXJnaW4tYm90dG9tOiAycHg7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGlvbi1wcm9ncmVzcy1iYXIge1xuICBtYXJnaW46IDE1cHggMCA4cHg7XG4gIGhlaWdodDogOXB4O1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBpb24tbGlzdCBpb24taXRlbSB7XG4gIC0tYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBjb2xvcjogIzJjNTVlMDtcbiAgYm9yZGVyOiAxcHggc29saWQgIzJjNTVlMDtcbiAgLS1taW4taGVpZ2h0OiAzMnB4O1xuICBwYWRkaW5nOiA0cHggMTRweDtcbiAgbWFyZ2luOiAxMnB4IDA7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGlvbi1saXN0IGlvbi1pdGVtIGlvbi1yYWRpbyB7XG4gIHdpZHRoOiAyOHB4O1xuICBoZWlnaHQ6IDI4cHg7XG4gIG1hcmdpbjogNHB4IDEycHggNHB4IDA7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGlvbi1saXN0IC5hY3RpdmUge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBiYWNrZ3JvdW5kOiAjNTE3NmYzO1xuICBjb2xvcjogI2ZmZjtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgaW9uLWxpc3QgLmFjdGl2ZSBpb24tcmFkaW8ge1xuICAtLWNvbG9yOiAjZmZmO1xuICAtLWNvbG9yLWNoZWNrZWQ6ICNmZmZmZmY7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IC5idG4tYm90dG9tIC5idG4tdHJhbnNwYXJlbnQge1xuICBjb2xvcjogIzJjNTVlMDtcbn1cbmlvbi1jb250ZW50IC50ZXJtLWNvbnRlbnQgLmJ0bi1ib3R0b20gaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogM3JlbTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/encuestas/multichoicefour/multichoicefour.page.ts":
/*!*******************************************************************!*\
  !*** ./src/app/encuestas/multichoicefour/multichoicefour.page.ts ***!
  \*******************************************************************/
/*! exports provided: MultichoicefourPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultichoicefourPage", function() { return MultichoicefourPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let MultichoicefourPage = class MultichoicefourPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
    radioGroupChange(event) {
        this.SelectedData = event.detail.value;
    }
};
MultichoicefourPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
MultichoicefourPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-multichoicefour',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./multichoicefour.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/encuestas/multichoicefour/multichoicefour.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./multichoicefour.page.scss */ "./src/app/encuestas/multichoicefour/multichoicefour.page.scss")).default]
    })
], MultichoicefourPage);



/***/ })

}]);
//# sourceMappingURL=encuestas-multichoicefour-multichoicefour-module-es2015.js.map