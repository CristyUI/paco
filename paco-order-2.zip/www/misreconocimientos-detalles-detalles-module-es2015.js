(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["misreconocimientos-detalles-detalles-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/misreconocimientos/detalles/detalles.page.html":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/misreconocimientos/detalles/detalles.page.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back-outline\" color=\"secondary\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Reconocimiento</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <div class=\"top-link\">\n      <img src=\"assets/imgs/misrecon/6.png\" alt=\"\">\n      <div class=\"rate-view\">\n        <ion-icon name=\"star\"></ion-icon>\n        <ion-icon name=\"star\"></ion-icon>\n        <ion-icon name=\"star\"></ion-icon>\n        <ion-icon name=\"star\"></ion-icon>\n        <ion-icon name=\"star-outline\"></ion-icon>\n      </div>\n      <h2>Lorem Ipsum</h2>\n      <p>Vivamus sit amet diam rhoncus, porttitor ex a, semper arcu. Pellentesque imperdiet.</p>\n    </div>\n    <h4>Otorgado por:</h4>\n    <div class=\"filter-area\" (click)=\"sortby()\">\n      <p>Ordenar por<span><ion-icon name=\"chevron-down-outline\"></ion-icon></span></p>\n    </div>\n\n    <div class=\"listing-area\">\n      <ul>\n        <li (click)=\"PageRoute('otorgado')\"><img src=\"assets/imgs/misrecon/user.png\" alt=\"\">Hannelore N. Underwood</li>\n        <li (click)=\"PageRoute('otorgado')\"><img src=\"assets/imgs/misrecon/user.png\" alt=\"\">Hannelore N. Underwood</li>\n        <li (click)=\"PageRoute('otorgado')\"><img src=\"assets/imgs/misrecon/user.png\" alt=\"\">Hannelore N. Underwood</li>\n        <li (click)=\"PageRoute('otorgado')\"><img src=\"assets/imgs/misrecon/user.png\" alt=\"\">Hannelore N. Underwood</li>\n      </ul>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/misreconocimientos/detalles/detalles-routing.module.ts":
/*!************************************************************************!*\
  !*** ./src/app/misreconocimientos/detalles/detalles-routing.module.ts ***!
  \************************************************************************/
/*! exports provided: DetallesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetallesPageRoutingModule", function() { return DetallesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _detalles_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./detalles.page */ "./src/app/misreconocimientos/detalles/detalles.page.ts");




const routes = [
    {
        path: '',
        component: _detalles_page__WEBPACK_IMPORTED_MODULE_3__["DetallesPage"]
    }
];
let DetallesPageRoutingModule = class DetallesPageRoutingModule {
};
DetallesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], DetallesPageRoutingModule);



/***/ }),

/***/ "./src/app/misreconocimientos/detalles/detalles.module.ts":
/*!****************************************************************!*\
  !*** ./src/app/misreconocimientos/detalles/detalles.module.ts ***!
  \****************************************************************/
/*! exports provided: DetallesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetallesPageModule", function() { return DetallesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _detalles_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./detalles-routing.module */ "./src/app/misreconocimientos/detalles/detalles-routing.module.ts");
/* harmony import */ var _detalles_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./detalles.page */ "./src/app/misreconocimientos/detalles/detalles.page.ts");







let DetallesPageModule = class DetallesPageModule {
};
DetallesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _detalles_routing_module__WEBPACK_IMPORTED_MODULE_5__["DetallesPageRoutingModule"]
        ],
        declarations: [_detalles_page__WEBPACK_IMPORTED_MODULE_6__["DetallesPage"]]
    })
], DetallesPageModule);



/***/ }),

/***/ "./src/app/misreconocimientos/detalles/detalles.page.scss":
/*!****************************************************************!*\
  !*** ./src/app/misreconocimientos/detalles/detalles.page.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-title {\n  font-weight: 600;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.ion-padding {\n  padding: 16px 20px;\n}\n.top-link {\n  text-align: center;\n}\n.top-link img {\n  width: 180px;\n}\n.top-link h2 {\n  margin-top: 14px;\n  font-size: 21px;\n  font-weight: 600;\n  color: #2d5eb7;\n}\n.top-link .rate-view {\n  margin-top: 10px;\n}\n.top-link .rate-view ion-icon {\n  color: #2d5eb7;\n  margin: 0 5px;\n  font-size: 19px;\n}\nh4 {\n  font-size: 17px;\n  font-weight: 600;\n  margin: 22px 0 0 5px;\n}\n.filter-area {\n  padding: 16px 0 5px;\n}\n.filter-area p {\n  border: 1px solid #7995f3;\n  padding: 12px 20px;\n  margin: 0;\n  border-radius: 30px;\n  width: 50%;\n  color: #797979;\n}\n.filter-area p span {\n  float: right;\n  font-size: 17px;\n  position: relative;\n  top: 2px;\n  color: #2d5eb7;\n}\n.listing-area ul {\n  padding-left: 0;\n}\n.listing-area ul li {\n  list-style-type: none;\n  border: 2px solid #7995f3;\n  border-radius: 30px;\n  padding: 6px;\n  margin-bottom: 8px;\n}\n.listing-area ul li img {\n  width: 42px;\n  vertical-align: middle;\n  margin-right: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWlzcmVjb25vY2ltaWVudG9zL2RldGFsbGVzL0c6XFxpb25pY1xcRklWRVJSXFxwYW50YWxsYXMtcGFjby9zcmNcXGFwcFxcbWlzcmVjb25vY2ltaWVudG9zXFxkZXRhbGxlc1xcZGV0YWxsZXMucGFnZS5zY3NzIiwic3JjL2FwcC9taXNyZWNvbm9jaW1pZW50b3MvZGV0YWxsZXMvZGV0YWxsZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UsZ0JBQUE7QUNBSjtBREdJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNETjtBREtBO0VBQ0Usa0JBQUE7QUNGRjtBRElBO0VBQ0Msa0JBQUE7QUNERDtBREVFO0VBQ0UsWUFBQTtBQ0FKO0FERUU7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUNBSjtBREVFO0VBQ0UsZ0JBQUE7QUNBSjtBRENJO0VBQ0UsY0FBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FDQ047QURHQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0FDQUY7QURFQTtFQUNFLG1CQUFBO0FDQ0Y7QURBRTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsbUJBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtBQ0VKO0FEREk7RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLGNBQUE7QUNHTjtBREVFO0VBQ0UsZUFBQTtBQ0NKO0FEQUk7RUFDRSxxQkFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUNFTjtBRERNO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7QUNHUiIsImZpbGUiOiJzcmMvYXBwL21pc3JlY29ub2NpbWllbnRvcy9kZXRhbGxlcy9kZXRhbGxlcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tdGl0bGUge1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB9XHJcbiAgLmJ0bi1yaWdodCB7XHJcbiAgICAuYWxlcnQtdGFnIHtcclxuICAgICAgd2lkdGg6IDEycHg7XHJcbiAgICAgIGhlaWdodDogMTJweDtcclxuICAgICAgYmFja2dyb3VuZDogI2ZiNGYzMztcclxuICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICByaWdodDogLTNweDtcclxuICAgICAgYm90dG9tOiAtMnB4O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4uaW9uLXBhZGRpbmcge1xyXG4gIHBhZGRpbmc6IDE2cHggMjBweDtcclxufVxyXG4udG9wLWxpbmsge1xyXG4gdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGltZyB7XHJcbiAgICB3aWR0aDogMTgwcHg7XHJcbiAgfVxyXG4gIGgyIHtcclxuICAgIG1hcmdpbi10b3A6IDE0cHg7XHJcbiAgICBmb250LXNpemU6IDIxcHg7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgY29sb3I6ICMyZDVlYjc7XHJcbiAgfVxyXG4gIC5yYXRlLXZpZXcge1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIGlvbi1pY29uIHtcclxuICAgICAgY29sb3I6ICMyZDVlYjc7XHJcbiAgICAgIG1hcmdpbjogMCA1cHg7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTlweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuaDQge1xyXG4gIGZvbnQtc2l6ZTogMTdweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIG1hcmdpbjogMjJweCAwIDAgNXB4O1xyXG59XHJcbi5maWx0ZXItYXJlYSB7XHJcbiAgcGFkZGluZzogMTZweCAwIDVweDtcclxuICBwIHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICM3OTk1ZjM7XHJcbiAgICBwYWRkaW5nOiAxMnB4IDIwcHg7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgd2lkdGg6IDUwJTtcclxuICAgIGNvbG9yOiAjNzk3OTc5O1xyXG4gICAgc3BhbiB7XHJcbiAgICAgIGZsb2F0OiByaWdodDtcclxuICAgICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIHRvcDogMnB4O1xyXG4gICAgICBjb2xvcjogIzJkNWViNztcclxuICAgIH1cclxuICB9XHJcbn1cclxuLmxpc3RpbmctYXJlYSB7XHJcbiAgdWwge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAwO1xyXG4gICAgbGkge1xyXG4gICAgICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XHJcbiAgICAgIGJvcmRlcjogMnB4IHNvbGlkICM3OTk1ZjM7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICAgIHBhZGRpbmc6IDZweDtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogOHB4O1xyXG4gICAgICBpbWcge1xyXG4gICAgICAgIHdpZHRoOiA0MnB4O1xyXG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59IiwiaW9uLWhlYWRlciBpb24tdGl0bGUge1xuICBmb250LXdlaWdodDogNjAwO1xufVxuaW9uLWhlYWRlciAuYnRuLXJpZ2h0IC5hbGVydC10YWcge1xuICB3aWR0aDogMTJweDtcbiAgaGVpZ2h0OiAxMnB4O1xuICBiYWNrZ3JvdW5kOiAjZmI0ZjMzO1xuICBkaXNwbGF5OiBibG9jaztcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAtM3B4O1xuICBib3R0b206IC0ycHg7XG59XG5cbi5pb24tcGFkZGluZyB7XG4gIHBhZGRpbmc6IDE2cHggMjBweDtcbn1cblxuLnRvcC1saW5rIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLnRvcC1saW5rIGltZyB7XG4gIHdpZHRoOiAxODBweDtcbn1cbi50b3AtbGluayBoMiB7XG4gIG1hcmdpbi10b3A6IDE0cHg7XG4gIGZvbnQtc2l6ZTogMjFweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6ICMyZDVlYjc7XG59XG4udG9wLWxpbmsgLnJhdGUtdmlldyB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG4udG9wLWxpbmsgLnJhdGUtdmlldyBpb24taWNvbiB7XG4gIGNvbG9yOiAjMmQ1ZWI3O1xuICBtYXJnaW46IDAgNXB4O1xuICBmb250LXNpemU6IDE5cHg7XG59XG5cbmg0IHtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBtYXJnaW46IDIycHggMCAwIDVweDtcbn1cblxuLmZpbHRlci1hcmVhIHtcbiAgcGFkZGluZzogMTZweCAwIDVweDtcbn1cbi5maWx0ZXItYXJlYSBwIHtcbiAgYm9yZGVyOiAxcHggc29saWQgIzc5OTVmMztcbiAgcGFkZGluZzogMTJweCAyMHB4O1xuICBtYXJnaW46IDA7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIHdpZHRoOiA1MCU7XG4gIGNvbG9yOiAjNzk3OTc5O1xufVxuLmZpbHRlci1hcmVhIHAgc3BhbiB7XG4gIGZsb2F0OiByaWdodDtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogMnB4O1xuICBjb2xvcjogIzJkNWViNztcbn1cblxuLmxpc3RpbmctYXJlYSB1bCB7XG4gIHBhZGRpbmctbGVmdDogMDtcbn1cbi5saXN0aW5nLWFyZWEgdWwgbGkge1xuICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XG4gIGJvcmRlcjogMnB4IHNvbGlkICM3OTk1ZjM7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIHBhZGRpbmc6IDZweDtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufVxuLmxpc3RpbmctYXJlYSB1bCBsaSBpbWcge1xuICB3aWR0aDogNDJweDtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/misreconocimientos/detalles/detalles.page.ts":
/*!**************************************************************!*\
  !*** ./src/app/misreconocimientos/detalles/detalles.page.ts ***!
  \**************************************************************/
/*! exports provided: DetallesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetallesPage", function() { return DetallesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");





let DetallesPage = class DetallesPage {
    constructor(router, menuCtrl, actionSheetController) {
        this.router = router;
        this.menuCtrl = menuCtrl;
        this.actionSheetController = actionSheetController;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
    sortby() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: 'Sort By',
                mode: 'ios',
                buttons: [{
                        text: 'Oldest',
                        handler: () => {
                            console.log('Oldest clicked');
                        }
                    }, {
                        text: 'Newest',
                        handler: () => {
                            console.log('Newest clicked');
                        }
                    }, {
                        text: 'Recently Viewed',
                        handler: () => {
                            console.log('Recently Viewed clicked');
                        }
                    },
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        }
                    },]
            });
            yield actionSheet.present();
        });
    }
};
DetallesPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"] }
];
DetallesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-detalles',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./detalles.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/misreconocimientos/detalles/detalles.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./detalles.page.scss */ "./src/app/misreconocimientos/detalles/detalles.page.scss")).default]
    })
], DetallesPage);



/***/ })

}]);
//# sourceMappingURL=misreconocimientos-detalles-detalles-module-es2015.js.map