(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["misreconocimientos-misremain-misremain-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/misreconocimientos/misremain/misremain.page.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/misreconocimientos/misremain/misremain.page.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\" (click)=\"PageRoute('home')\">\n      <ion-icon name=\"chevron-back-outline\" color=\"secondary\" style=\"margin-top: 4px;\"></ion-icon>\n    </ion-buttons>\n    <ion-title color=\"secondary\">Mis reconocimientos</ion-title>\n    <ion-buttons slot=\"end\" class=\"btn-right\">\n      <ion-icon name=\"notifications-outline\" color=\"secondary\"></ion-icon>\n      <span class=\"alert-tag\"></span>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"ion-padding\">\n    <div class=\"filter-area\" (click)=\"sortby()\">\n      <p>Ordenar por<span><ion-icon name=\"chevron-down-outline\"></ion-icon></span></p>\n    </div>\n\n    <div class=\"card-wrap\">\n      <ion-row>\n        <ion-col size=\"6\">\n          <div class=\"item-card\" (click)=\"PageRoute('detalles')\">\n            <img src=\"assets/imgs/misrecon/1.png\" alt=\"\">\n            <div class=\"rate-view\">\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star-outline\"></ion-icon>\n            </div>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\">\n          <div class=\"item-card\" (click)=\"PageRoute('detalles')\">\n            <img src=\"assets/imgs/misrecon/2.png\" alt=\"\">\n            <div class=\"rate-view\">\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star-outline\"></ion-icon>\n            </div>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\">\n          <div class=\"item-card\" (click)=\"PageRoute('detalles')\">\n            <img src=\"assets/imgs/misrecon/3.png\" alt=\"\">\n            <div class=\"rate-view\">\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star-outline\"></ion-icon>\n            </div>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\">\n          <div class=\"item-card\" (click)=\"PageRoute('detalles')\">\n            <img src=\"assets/imgs/misrecon/4.png\" alt=\"\">\n            <div class=\"rate-view\">\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star-outline\"></ion-icon>\n            </div>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\">\n          <div class=\"item-card\" (click)=\"PageRoute('detalles')\">\n            <img src=\"assets/imgs/misrecon/5.png\" alt=\"\">\n            <div class=\"rate-view\">\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star-outline\"></ion-icon>\n            </div>\n          </div>\n        </ion-col>\n        <ion-col size=\"6\">\n          <div class=\"item-card\" (click)=\"PageRoute('detalles')\">\n            <img src=\"assets/imgs/misrecon/6.png\" alt=\"\">\n            <div class=\"rate-view\">\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star\"></ion-icon>\n              <ion-icon name=\"star-outline\"></ion-icon>\n            </div>\n          </div>\n        </ion-col>\n      </ion-row>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/misreconocimientos/misremain/misremain-routing.module.ts":
/*!**************************************************************************!*\
  !*** ./src/app/misreconocimientos/misremain/misremain-routing.module.ts ***!
  \**************************************************************************/
/*! exports provided: MisremainPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MisremainPageRoutingModule", function() { return MisremainPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _misremain_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./misremain.page */ "./src/app/misreconocimientos/misremain/misremain.page.ts");




const routes = [
    {
        path: '',
        component: _misremain_page__WEBPACK_IMPORTED_MODULE_3__["MisremainPage"]
    }
];
let MisremainPageRoutingModule = class MisremainPageRoutingModule {
};
MisremainPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MisremainPageRoutingModule);



/***/ }),

/***/ "./src/app/misreconocimientos/misremain/misremain.module.ts":
/*!******************************************************************!*\
  !*** ./src/app/misreconocimientos/misremain/misremain.module.ts ***!
  \******************************************************************/
/*! exports provided: MisremainPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MisremainPageModule", function() { return MisremainPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _misremain_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./misremain-routing.module */ "./src/app/misreconocimientos/misremain/misremain-routing.module.ts");
/* harmony import */ var _misremain_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./misremain.page */ "./src/app/misreconocimientos/misremain/misremain.page.ts");







let MisremainPageModule = class MisremainPageModule {
};
MisremainPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _misremain_routing_module__WEBPACK_IMPORTED_MODULE_5__["MisremainPageRoutingModule"]
        ],
        declarations: [_misremain_page__WEBPACK_IMPORTED_MODULE_6__["MisremainPage"]]
    })
], MisremainPageModule);



/***/ }),

/***/ "./src/app/misreconocimientos/misremain/misremain.page.scss":
/*!******************************************************************!*\
  !*** ./src/app/misreconocimientos/misremain/misremain.page.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-title {\n  font-weight: 600;\n}\nion-header ion-buttons {\n  margin-left: 20px;\n}\nion-header .btn-right .alert-tag {\n  width: 12px;\n  height: 12px;\n  background: #fb4f33;\n  display: block;\n  border-radius: 50%;\n  position: absolute;\n  right: -3px;\n  bottom: -2px;\n}\n.filter-area {\n  padding: 5px 0;\n}\n.filter-area p {\n  border: 1px solid #7995f3;\n  padding: 12px 20px;\n  margin: 0;\n  border-radius: 30px;\n  width: 50%;\n  color: #797979;\n}\n.filter-area p span {\n  float: right;\n  font-size: 17px;\n  position: relative;\n  top: 2px;\n  color: #2d5eb7;\n}\n.card-wrap {\n  margin-top: 20px;\n}\n.card-wrap .item-card {\n  padding: 6px;\n  text-align: center;\n}\n.card-wrap .item-card .rate-view {\n  margin-top: 10px;\n}\n.card-wrap .item-card .rate-view ion-icon {\n  color: #2d5eb7;\n  margin: 0 3px;\n  font-size: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWlzcmVjb25vY2ltaWVudG9zL21pc3JlbWFpbi9HOlxcaW9uaWNcXEZJVkVSUlxccGFudGFsbGFzLXBhY28vc3JjXFxhcHBcXG1pc3JlY29ub2NpbWllbnRvc1xcbWlzcmVtYWluXFxtaXNyZW1haW4ucGFnZS5zY3NzIiwic3JjL2FwcC9taXNyZWNvbm9jaW1pZW50b3MvbWlzcmVtYWluL21pc3JlbWFpbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxnQkFBQTtBQ0FKO0FERUU7RUFDRSxpQkFBQTtBQ0FKO0FER0k7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQ0ROO0FETUE7RUFDRSxjQUFBO0FDSEY7QURJRTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsbUJBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtBQ0ZKO0FER0k7RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLGNBQUE7QUNETjtBREtBO0VBQ0UsZ0JBQUE7QUNGRjtBREdFO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0FDREo7QURFSTtFQUNFLGdCQUFBO0FDQU47QURDTTtFQUNFLGNBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ0NSIiwiZmlsZSI6InNyYy9hcHAvbWlzcmVjb25vY2ltaWVudG9zL21pc3JlbWFpbi9taXNyZW1haW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgaW9uLXRpdGxlIHtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgfVxyXG4gIGlvbi1idXR0b25zIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gIH1cclxuICAuYnRuLXJpZ2h0IHtcclxuICAgIC5hbGVydC10YWcge1xyXG4gICAgICB3aWR0aDogMTJweDtcclxuICAgICAgaGVpZ2h0OiAxMnB4O1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjZmI0ZjMzO1xyXG4gICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgIHJpZ2h0OiAtM3B4O1xyXG4gICAgICBib3R0b206IC0ycHg7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG4uZmlsdGVyLWFyZWEge1xyXG4gIHBhZGRpbmc6IDVweCAwO1xyXG4gIHAge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgIzc5OTVmMztcclxuICAgIHBhZGRpbmc6IDEycHggMjBweDtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICB3aWR0aDogNTAlO1xyXG4gICAgY29sb3I6ICM3OTc5Nzk7XHJcbiAgICBzcGFuIHtcclxuICAgICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgdG9wOiAycHg7XHJcbiAgICAgIGNvbG9yOiAjMmQ1ZWI3O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4uY2FyZC13cmFwIHtcclxuICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gIC5pdGVtLWNhcmQge1xyXG4gICAgcGFkZGluZzogNnB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgLnJhdGUtdmlldyB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICBjb2xvcjogIzJkNWViNztcclxuICAgICAgICBtYXJnaW46IDAgM3B4O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufSIsImlvbi1oZWFkZXIgaW9uLXRpdGxlIHtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbmlvbi1oZWFkZXIgaW9uLWJ1dHRvbnMge1xuICBtYXJnaW4tbGVmdDogMjBweDtcbn1cbmlvbi1oZWFkZXIgLmJ0bi1yaWdodCAuYWxlcnQtdGFnIHtcbiAgd2lkdGg6IDEycHg7XG4gIGhlaWdodDogMTJweDtcbiAgYmFja2dyb3VuZDogI2ZiNGYzMztcbiAgZGlzcGxheTogYmxvY2s7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogLTNweDtcbiAgYm90dG9tOiAtMnB4O1xufVxuXG4uZmlsdGVyLWFyZWEge1xuICBwYWRkaW5nOiA1cHggMDtcbn1cbi5maWx0ZXItYXJlYSBwIHtcbiAgYm9yZGVyOiAxcHggc29saWQgIzc5OTVmMztcbiAgcGFkZGluZzogMTJweCAyMHB4O1xuICBtYXJnaW46IDA7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG4gIHdpZHRoOiA1MCU7XG4gIGNvbG9yOiAjNzk3OTc5O1xufVxuLmZpbHRlci1hcmVhIHAgc3BhbiB7XG4gIGZsb2F0OiByaWdodDtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogMnB4O1xuICBjb2xvcjogIzJkNWViNztcbn1cblxuLmNhcmQtd3JhcCB7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG4uY2FyZC13cmFwIC5pdGVtLWNhcmQge1xuICBwYWRkaW5nOiA2cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5jYXJkLXdyYXAgLml0ZW0tY2FyZCAucmF0ZS12aWV3IHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cbi5jYXJkLXdyYXAgLml0ZW0tY2FyZCAucmF0ZS12aWV3IGlvbi1pY29uIHtcbiAgY29sb3I6ICMyZDVlYjc7XG4gIG1hcmdpbjogMCAzcHg7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/misreconocimientos/misremain/misremain.page.ts":
/*!****************************************************************!*\
  !*** ./src/app/misreconocimientos/misremain/misremain.page.ts ***!
  \****************************************************************/
/*! exports provided: MisremainPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MisremainPage", function() { return MisremainPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");





let MisremainPage = class MisremainPage {
    constructor(router, menuCtrl, actionSheetController) {
        this.router = router;
        this.menuCtrl = menuCtrl;
        this.actionSheetController = actionSheetController;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    PageRoute(urlSlug) {
        this.router.navigateByUrl('/' + urlSlug);
    }
    sortby() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: 'Sort By',
                mode: 'ios',
                buttons: [{
                        text: 'Oldest',
                        handler: () => {
                            console.log('Oldest clicked');
                        }
                    }, {
                        text: 'Newest',
                        handler: () => {
                            console.log('Newest clicked');
                        }
                    }, {
                        text: 'Recently Viewed',
                        handler: () => {
                            console.log('Recently Viewed clicked');
                        }
                    },
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        }
                    },]
            });
            yield actionSheet.present();
        });
    }
};
MisremainPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"] }
];
MisremainPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-misremain',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./misremain.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/misreconocimientos/misremain/misremain.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./misremain.page.scss */ "./src/app/misreconocimientos/misremain/misremain.page.scss")).default]
    })
], MisremainPage);



/***/ })

}]);
//# sourceMappingURL=misreconocimientos-misremain-misremain-module-es2015.js.map