(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["configuration-modificado-modificado-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/modificado/modificado.page.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/modificado/modificado.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"close\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"term-content\">\n    <img src=\"assets/imgs/configuration/lock.png\" alt=\"\">\n    <h5>Pin modificado</h5>\n    <p>Lorem ipsum dolor sit amet, consectetur 20% adipiscing elit. Mauris ultricies lacus ut turpis venenatis posuere.</p>\n    <div class=\"btn-wrap\">\n      <ion-button (click)=\"home()\">Aceptar</ion-button>\n    </div>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/configuration/modificado/modificado-routing.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/configuration/modificado/modificado-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: ModificadoPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModificadoPageRoutingModule", function() { return ModificadoPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _modificado_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./modificado.page */ "./src/app/configuration/modificado/modificado.page.ts");




const routes = [
    {
        path: '',
        component: _modificado_page__WEBPACK_IMPORTED_MODULE_3__["ModificadoPage"]
    }
];
let ModificadoPageRoutingModule = class ModificadoPageRoutingModule {
};
ModificadoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ModificadoPageRoutingModule);



/***/ }),

/***/ "./src/app/configuration/modificado/modificado.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/configuration/modificado/modificado.module.ts ***!
  \***************************************************************/
/*! exports provided: ModificadoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModificadoPageModule", function() { return ModificadoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _modificado_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./modificado-routing.module */ "./src/app/configuration/modificado/modificado-routing.module.ts");
/* harmony import */ var _modificado_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./modificado.page */ "./src/app/configuration/modificado/modificado.page.ts");







let ModificadoPageModule = class ModificadoPageModule {
};
ModificadoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _modificado_routing_module__WEBPACK_IMPORTED_MODULE_5__["ModificadoPageRoutingModule"]
        ],
        declarations: [_modificado_page__WEBPACK_IMPORTED_MODULE_6__["ModificadoPage"]]
    })
], ModificadoPageModule);



/***/ }),

/***/ "./src/app/configuration/modificado/modificado.page.scss":
/*!***************************************************************!*\
  !*** ./src/app/configuration/modificado/modificado.page.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #5176f3;\n}\nion-content .term-content {\n  background: #fff;\n  padding: 20px 25px;\n  margin: 20px;\n  text-align: center;\n  border-radius: 20px;\n  box-shadow: 0 7px 16px -7px rgba(0, 0, 0, 0.69);\n}\nion-content .term-content img {\n  width: 105px;\n  margin: 0 0 6px;\n}\nion-content .term-content h5 {\n  font-size: 17px;\n  margin-top: 6px;\n  color: #2c55e0;\n  font-weight: 700;\n}\nion-content .btn-wrap ion-button {\n  width: 44% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29uZmlndXJhdGlvbi9tb2RpZmljYWRvL0c6XFxpb25pY1xcRklWRVJSXFxwYW50YWxsYXMtcGFjby9zcmNcXGFwcFxcY29uZmlndXJhdGlvblxcbW9kaWZpY2Fkb1xcbW9kaWZpY2Fkby5wYWdlLnNjc3MiLCJzcmMvYXBwL2NvbmZpZ3VyYXRpb24vbW9kaWZpY2Fkby9tb2RpZmljYWRvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FDQ0Y7QURBRTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLCtDQUFBO0FDRUo7QURESTtFQUNFLFlBQUE7RUFDQSxlQUFBO0FDR047QURESTtFQUNFLGVBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDR047QURDSTtFQUNFLHFCQUFBO0FDQ04iLCJmaWxlIjoic3JjL2FwcC9jb25maWd1cmF0aW9uL21vZGlmaWNhZG8vbW9kaWZpY2Fkby5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjNTE3NmYzO1xyXG4gIC50ZXJtLWNvbnRlbnQge1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIHBhZGRpbmc6IDIwcHggMjVweDtcclxuICAgIG1hcmdpbjogMjBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwIDdweCAxNnB4IC03cHggcmdiYSgwLCAwLCAwLCAwLjY5KTtcclxuICAgIGltZyB7XHJcbiAgICAgIHdpZHRoOiAxMDVweDtcclxuICAgICAgbWFyZ2luOiAwIDAgNnB4O1xyXG4gICAgfVxyXG4gICAgaDUge1xyXG4gICAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDZweDtcclxuICAgICAgY29sb3I6ICMyYzU1ZTA7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC5idG4td3JhcCB7XHJcbiAgICBpb24tYnV0dG9uIHtcclxuICAgICAgd2lkdGg6IDQ0JSFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgfVxyXG59IiwiaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICM1MTc2ZjM7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IHtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgcGFkZGluZzogMjBweCAyNXB4O1xuICBtYXJnaW46IDIwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcbiAgYm94LXNoYWRvdzogMCA3cHggMTZweCAtN3B4IHJnYmEoMCwgMCwgMCwgMC42OSk7XG59XG5pb24tY29udGVudCAudGVybS1jb250ZW50IGltZyB7XG4gIHdpZHRoOiAxMDVweDtcbiAgbWFyZ2luOiAwIDAgNnB4O1xufVxuaW9uLWNvbnRlbnQgLnRlcm0tY29udGVudCBoNSB7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBjb2xvcjogIzJjNTVlMDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cbmlvbi1jb250ZW50IC5idG4td3JhcCBpb24tYnV0dG9uIHtcbiAgd2lkdGg6IDQ0JSAhaW1wb3J0YW50O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/configuration/modificado/modificado.page.ts":
/*!*************************************************************!*\
  !*** ./src/app/configuration/modificado/modificado.page.ts ***!
  \*************************************************************/
/*! exports provided: ModificadoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModificadoPage", function() { return ModificadoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let ModificadoPage = class ModificadoPage {
    constructor(router, menuCtrl) {
        this.router = router;
        this.menuCtrl = menuCtrl;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
    ionViewDidLeave() {
        this.menuCtrl.enable(true);
    }
    home() {
        this.router.navigateByUrl('/home');
    }
};
ModificadoPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"] }
];
ModificadoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-modificado',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./modificado.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/configuration/modificado/modificado.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./modificado.page.scss */ "./src/app/configuration/modificado/modificado.page.scss")).default]
    })
], ModificadoPage);



/***/ })

}]);
//# sourceMappingURL=configuration-modificado-modificado-module-es2015.js.map